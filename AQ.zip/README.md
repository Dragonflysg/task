# Q&A Console

Light-themed web UI that captures question/answer pairs into a single Word document via a Flask API.

## Layout

```
QA/
├── backend/
│   ├── app.py              # Flask routes
│   ├── docx_service.py     # docx read/write logic
│   └── requirements.txt
└── frontend/
    ├── index.html
    ├── styles.css
    └── app.js
```

On the first save, three mirrored files are created next to `app.py`:

- `QuestionAndAnswer.json` — **source of truth**. Pairs carry a stable UUID, `created_at`, and `updated_at`. The only file the API reads back.
- `QuestionAndAnswer.docx` — the human-facing Word document. Regenerated on every write.
- `QuestionAndAnswer.txt` — markdown content with a `.txt` extension, intended for RAG ingestion. Each pair is written as `## Question` / `## Answer` sections separated by `---`. Regenerated on every write.

If a `.docx` already exists from an earlier version but no `.json` exists yet, the backend bootstraps `.json` once by parsing the docx.

## Run the backend

From a PowerShell prompt:

```powershell
cd C:\PROJECTS\QA\backend
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python app.py
```

Flask listens on `http://127.0.0.1:5000`.

## Open the frontend

Open `C:\PROJECTS\QA\frontend\index.html` directly in a browser (double-click, or `Start-Process .\frontend\index.html`). CORS is enabled on the API so the static page can talk to Flask.

## API

| Method | Path           | Body                       | Result                                                   |
|--------|----------------|----------------------------|----------------------------------------------------------|
| GET    | `/api/health`  | —                          | `{"status":"ok"}`                                        |
| GET    | `/api/qa`      | —                          | List of `{id, question, answer, created_at, updated_at}` |
| POST   | `/api/qa`      | `{question, answer}`       | Adds a pair, returns updated list                        |
| PUT    | `/api/qa/<id>` | `{question, answer}`       | Updates the pair with that UUID                          |
| DELETE | `/api/qa/<id>` | —                          | Removes the pair with that UUID                          |

`<id>` is the stable UUID from each pair in the JSON store.
