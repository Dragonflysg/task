/* global $, Toastify */

const API_BASE = "http://127.0.0.1:5000/api";

const state = {
  pairs: [],          // doc order; each item has stable string id
  editingId: null,    // UUID string when editing; null otherwise
  pageSize: 5,        // number or "all"
  currentPage: 1,
  searchQuery: "",
};

let searchTimer;

$(function () {
  bindEvents();
  ping();
  loadPairs();
});

/* ---------- Network ---------- */

function ping() {
  $.ajax({ url: `${API_BASE}/health`, timeout: 4000 })
    .done(() => setStatus("online", "online"))
    .fail(() => setStatus("error", "offline"));
}

function loadPairs() {
  showLoading(true);
  $.ajax({ url: `${API_BASE}/qa`, dataType: "json" })
    .done((data) => {
      state.pairs = Array.isArray(data) ? data : [];
      renderCards();
    })
    .fail((xhr) => {
      toast(`Failed to load entries (${xhr.status || "network"})`, "error");
      state.pairs = [];
      renderCards();
    })
    .always(() => showLoading(false));
}

function submitPair(question, answer) {
  const editingId = state.editingId;
  const isEdit = editingId !== null;
  const url = isEdit ? `${API_BASE}/qa/${encodeURIComponent(editingId)}` : `${API_BASE}/qa`;
  const method = isEdit ? "PUT" : "POST";

  setSubmitting(true);
  $.ajax({
    url,
    method,
    contentType: "application/json",
    data: JSON.stringify({ question, answer }),
    dataType: "json",
  })
    .done((data) => {
      state.pairs = Array.isArray(data) ? data : [];
      // Edit: stay on current page. Add: jump to page 1 (where newest lands).
      if (!isEdit) state.currentPage = 1;
      resetForm();
      renderCards();
      toast(isEdit ? "Entry updated" : "Entry saved", "success");
    })
    .fail((xhr) => {
      const msg = (xhr.responseJSON && xhr.responseJSON.error) || "Save failed";
      toast(msg, "error");
    })
    .always(() => setSubmitting(false));
}

function deletePair(id) {
  if (!confirm("Delete this Q&A pair? This cannot be undone.")) return;
  $.ajax({
    url: `${API_BASE}/qa/${encodeURIComponent(id)}`,
    method: "DELETE",
    dataType: "json",
  })
    .done((data) => {
      state.pairs = Array.isArray(data) ? data : [];
      if (state.editingId === id) resetForm();
      renderCards(); // currentPage clamps automatically if it overshoots
      toast("Entry deleted", "success");
    })
    .fail((xhr) => {
      const msg = (xhr.responseJSON && xhr.responseJSON.error) || "Delete failed";
      toast(msg, "error");
    });
}

/* ---------- UI events ---------- */

function bindEvents() {
  $("#qa-form").on("submit", function (e) {
    e.preventDefault();
    const question = $("#question").val().trim();
    const answer = $("#answer").val().trim();
    if (!question || !answer) {
      toast("Both fields are required", "error");
      return;
    }
    submitPair(question, answer);
  });

  $("#cancel-edit").on("click", function () {
    resetForm();
  });

  $("#cards").on("click", ".icon-btn--edit", function () {
    const id = $(this).closest(".card").attr("data-id");
    startEdit(id);
  });

  $("#cards").on("click", ".icon-btn--delete", function () {
    const id = $(this).closest(".card").attr("data-id");
    deletePair(id);
  });

  $("#page-size").on("change", function () {
    const v = $(this).val();
    state.pageSize = v === "all" ? "all" : parseInt(v, 10);
    state.currentPage = 1;
    renderCards();
  });

  $("#search-input").on("input", function () {
    const value = $(this).val();
    clearTimeout(searchTimer);
    searchTimer = setTimeout(() => {
      state.searchQuery = value.trim().toLowerCase();
      state.currentPage = 1;
      renderCards();
    }, 150);
  });

  $("#prev-btn").on("click", function () {
    if (state.currentPage > 1) {
      state.currentPage--;
      renderCards();
      scrollCardsIntoView();
    }
  });

  $("#next-btn").on("click", function () {
    state.currentPage++;
    renderCards();
    scrollCardsIntoView();
  });
}

/* ---------- Render ---------- */

function renderCards() {
  const $cards = $("#cards").empty();
  const q = state.searchQuery;

  // Keep original doc-order index for the "#NN" label.
  const annotated = state.pairs.map((p, i) => ({ ...p, _docIndex: i }));

  const filtered = q
    ? annotated.filter(
        (p) =>
          (p.question || "").toLowerCase().includes(q) ||
          (p.answer || "").toLowerCase().includes(q)
      )
    : annotated;

  // Newest first.
  const displayList = filtered.slice().reverse();
  const total = displayList.length;

  const pageSize =
    state.pageSize === "all" ? Math.max(total, 1) : state.pageSize;
  const totalPages = Math.max(1, Math.ceil(total / pageSize));

  if (state.currentPage > totalPages) state.currentPage = totalPages;
  if (state.currentPage < 1) state.currentPage = 1;

  const start = (state.currentPage - 1) * pageSize;
  const end = start + pageSize;
  const pageItems = displayList.slice(start, end);

  if (total === 0) {
    const $empty = $("#empty-state").prop("hidden", false);
    $empty.find("p").text(
      q
        ? `No results for "${state.searchQuery}".`
        : "No Q&A pairs yet. Add one above to get started."
    );
    updatePagination(0, 0, 0, 1);
    return;
  }
  $("#empty-state").prop("hidden", true);

  const tpl = document.getElementById("card-template");
  pageItems.forEach((p) => {
    const frag = tpl.content.cloneNode(true);
    const $card = $(frag.querySelector(".card"));
    $card.attr("data-id", p.id);
    $card
      .find(".card__index")
      .text(`#${String(p._docIndex + 1).padStart(2, "0")}`);

    if (q) {
      $card.find(".card__question").html(highlight(p.question, q));
      $card.find(".card__answer").html(highlight(p.answer, q));
    } else {
      $card.find(".card__question").text(p.question);
      $card.find(".card__answer").text(p.answer);
    }

    if (state.editingId === p.id) $card.addClass("is-editing");
    $cards.append($card);
  });

  updatePagination(start + 1, start + pageItems.length, total, totalPages);
}

function updatePagination(from, to, total, totalPages) {
  const $pag = $("#pagination");
  if (total === 0) {
    $pag.prop("hidden", true);
    return;
  }
  $pag.prop("hidden", false);
  $("#pagination-status").text(`Showing ${from}–${to} of ${total}`);
  $("#pagination-page").text(`Page ${state.currentPage} / ${totalPages}`);

  const showButtons = state.pageSize !== "all" && totalPages > 1;
  $("#pagination-buttons").toggle(showButtons);
  $("#prev-btn").prop("disabled", state.currentPage <= 1);
  $("#next-btn").prop("disabled", state.currentPage >= totalPages);
}

function highlight(text, query) {
  if (!text) return "";
  const safe = escapeHtml(text);
  if (!query) return safe;
  const re = new RegExp(`(${escapeRegex(query)})`, "ig");
  return safe.replace(re, "<mark>$1</mark>");
}

function escapeHtml(s) {
  return String(s)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function escapeRegex(s) {
  return String(s).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function scrollCardsIntoView() {
  const $cards = $("#cards");
  if (!$cards.length) return;
  $("html, body").animate(
    { scrollTop: $cards.offset().top - 16 },
    200
  );
}

function startEdit(id) {
  const pair = state.pairs.find((p) => p.id === id);
  if (!pair) return;

  state.editingId = id;
  const docIndex = state.pairs.indexOf(pair) + 1;

  $("#question").val(pair.question);
  $("#answer").val(pair.answer);
  $("#form-title").text(`Editing entry #${String(docIndex).padStart(2, "0")}`);
  $("#submit-btn span").text("UPDATE");
  $("#submit-btn i").removeClass("fa-paper-plane").addClass("fa-floppy-disk");
  $("#cancel-edit").prop("hidden", false);
  $("#form-panel").addClass("is-editing");

  renderCards();

  $("html, body").animate(
    { scrollTop: $("#form-panel").offset().top - 16 },
    250
  );
  $("#question").trigger("focus");
}

function resetForm() {
  state.editingId = null;
  $("#qa-form")[0].reset();
  $("#form-title").text("New entry");
  $("#submit-btn span").text("SUBMIT");
  $("#submit-btn i").removeClass("fa-floppy-disk").addClass("fa-paper-plane");
  $("#cancel-edit").prop("hidden", true);
  $("#form-panel").removeClass("is-editing");
}

function setSubmitting(isSubmitting) {
  const $btn = $("#submit-btn");
  $btn.prop("disabled", isSubmitting);
  $("#saving-indicator").prop("hidden", !isSubmitting);
  if (isSubmitting) {
    $btn.find("i").removeClass().addClass("fa-solid fa-circle-notch fa-spin");
  } else {
    const icon = state.editingId !== null ? "fa-floppy-disk" : "fa-paper-plane";
    $btn.find("i").removeClass().addClass(`fa-solid ${icon}`);
  }
}

function showLoading(isLoading) {
  $("#loading-state").toggle(isLoading);
  if (isLoading) $("#empty-state").prop("hidden", true);
}

function setStatus(kind, text) {
  const $s = $("#status").removeClass("is-online is-error");
  if (kind === "online") $s.addClass("is-online");
  if (kind === "error") $s.addClass("is-error");
  $s.find(".status__text").text(text);
}

/* ---------- Toast helper ---------- */

function toast(message, kind) {
  const palette = {
    success: "linear-gradient(135deg, #16a34a, #22c55e)",
    error: "linear-gradient(135deg, #dc2626, #ef4444)",
    info: "linear-gradient(135deg, #2563eb, #6366f1)",
  };
  Toastify({
    text: message,
    duration: 3000,
    gravity: "bottom",
    position: "right",
    style: { background: palette[kind] || palette.info },
  }).showToast();
}
