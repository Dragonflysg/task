"""Storage logic for the Q&A app.

QuestionAndAnswer.json is the source of truth. Each pair is:

    {
      "id":         "<uuid4 hex>",
      "question":   "...",
      "answer":     "...",
      "created_at": "<iso8601 utc>",
      "updated_at": "<iso8601 utc>"
    }

QuestionAndAnswer.docx and QuestionAndAnswer.txt are regenerated from the
JSON on every mutation so the three files cannot drift:

  - .docx — human-facing Word document.
  - .txt  — markdown content for RAG ingestion.
  - .json — structured store, the only file we read back.

If JSON is missing but a docx exists from an earlier version, we bootstrap
JSON once by parsing the docx.
"""

import json
import os
import uuid
from datetime import datetime, timezone

from docx import Document

_DIR = os.path.dirname(os.path.abspath(__file__))
DOCX_FILE = os.path.join(_DIR, "QuestionAndAnswer.docx")
MARKDOWN_FILE = os.path.join(_DIR, "QuestionAndAnswer.txt")
JSON_FILE = os.path.join(_DIR, "QuestionAndAnswer.json")


def _now():
    return datetime.now(timezone.utc).isoformat()


def _new_id():
    return uuid.uuid4().hex


def read_pairs():
    return _load_pairs()


def add_pair(question, answer):
    pairs = _load_pairs()
    now = _now()
    pairs.append(
        {
            "id": _new_id(),
            "question": question,
            "answer": answer,
            "created_at": now,
            "updated_at": now,
        }
    )
    _write_all(pairs)
    return pairs


def update_pair(pair_id, question, answer):
    pairs = _load_pairs()
    for p in pairs:
        if p.get("id") == pair_id:
            p["question"] = question
            p["answer"] = answer
            p["updated_at"] = _now()
            _write_all(pairs)
            return pairs
    return None


def delete_pair(pair_id):
    pairs = _load_pairs()
    remaining = [p for p in pairs if p.get("id") != pair_id]
    if len(remaining) == len(pairs):
        return None
    _write_all(remaining)
    return remaining


# ---------- internals ----------

def _load_pairs():
    if os.path.exists(JSON_FILE):
        try:
            with open(JSON_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, list):
                return data
        except (json.JSONDecodeError, OSError):
            pass
        return []
    return _bootstrap_from_docx()


def _bootstrap_from_docx():
    if not os.path.exists(DOCX_FILE):
        return []
    doc = Document(DOCX_FILE)
    pairs = []
    current_q = None
    answer_lines = []

    def flush():
        nonlocal current_q, answer_lines
        if current_q is not None:
            now = _now()
            pairs.append(
                {
                    "id": _new_id(),
                    "question": current_q,
                    "answer": "\n".join(answer_lines).strip(),
                    "created_at": now,
                    "updated_at": now,
                }
            )
        current_q = None
        answer_lines = []

    for para in doc.paragraphs:
        text = para.text.strip()
        style_name = para.style.name if para.style else ""
        if style_name.startswith("Heading"):
            flush()
            if text:
                current_q = text
        else:
            if current_q is not None and text:
                answer_lines.append(text)
    flush()

    if pairs:
        _write_all(pairs)
    return pairs


def _write_all(pairs):
    _write_json(pairs)
    _write_docx(pairs)
    _write_markdown(pairs)


def _write_json(pairs):
    tmp = JSON_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(pairs, f, ensure_ascii=False, indent=2)
    os.replace(tmp, JSON_FILE)


def _write_docx(pairs):
    doc = Document()
    for p in pairs:
        doc.add_heading(p["question"], level=2)
        for line in p["answer"].split("\n"):
            doc.add_paragraph(line)
    doc.save(DOCX_FILE)


def _write_markdown(pairs):
    blocks = [
        f"## Question\n{p['question']}\n\n## Answer\n{p['answer']}"
        for p in pairs
    ]
    content = "\n\n---\n\n".join(blocks)
    if content:
        content += "\n"
    with open(MARKDOWN_FILE, "w", encoding="utf-8", newline="\n") as f:
        f.write(content)
