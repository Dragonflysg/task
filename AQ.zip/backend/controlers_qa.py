"""Request handlers for the Q&A API.

Pure functions — no Flask routing here. Route bindings live in app.py.
Storage logic lives in docx_service.py.
"""

from flask import jsonify, request

import docx_service


def health():
    return jsonify({"status": "ok"})


def list_pairs():
    return jsonify(docx_service.read_pairs())


def create_pair():
    data = request.get_json(silent=True) or {}
    question = (data.get("question") or "").strip()
    answer = (data.get("answer") or "").strip()
    if not question or not answer:
        return jsonify({"error": "question and answer are required"}), 400
    pairs = docx_service.add_pair(question, answer)
    return jsonify(pairs), 201


def update_pair(pair_id):
    data = request.get_json(silent=True) or {}
    question = (data.get("question") or "").strip()
    answer = (data.get("answer") or "").strip()
    if not question or not answer:
        return jsonify({"error": "question and answer are required"}), 400
    pairs = docx_service.update_pair(pair_id, question, answer)
    if pairs is None:
        return jsonify({"error": "pair not found"}), 404
    return jsonify(pairs)


def delete_pair(pair_id):
    pairs = docx_service.delete_pair(pair_id)
    if pairs is None:
        return jsonify({"error": "pair not found"}), 404
    return jsonify(pairs)
