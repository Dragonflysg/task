"""Flask app bootstrap and route table.

This file only wires URLs to handler functions. The handlers themselves live
in controlers_qa.py, and storage logic lives in docx_service.py.
"""

from flask import Flask
from flask_cors import CORS

import controlers_qa

app = Flask(__name__)
CORS(app)

# URL                       handler                          methods
app.add_url_rule("/api/health",        view_func=controlers_qa.health,       methods=["GET"])
app.add_url_rule("/api/qa",            view_func=controlers_qa.list_pairs,   methods=["GET"])
app.add_url_rule("/api/qa",            view_func=controlers_qa.create_pair,  methods=["POST"])
app.add_url_rule("/api/qa/<pair_id>",  view_func=controlers_qa.update_pair,  methods=["PUT"])
app.add_url_rule("/api/qa/<pair_id>",  view_func=controlers_qa.delete_pair,  methods=["DELETE"])


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)
