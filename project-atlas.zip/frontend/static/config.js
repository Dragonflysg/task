// Set to the public HTTPS address of your Flask API server (no /api suffix).
// Leave empty only when frontend and API share the same origin (local development).
window.IES_CONFIG = { apiBaseUrl: '' };
