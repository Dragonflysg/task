/* Shared URL builder for API requests, photos, downloads, and JSON exports. */
window.iesApiUrl = function(path) {
  if (!path) return path;
  const base = (window.IES_CONFIG?.apiBaseUrl || '').replace(/\/+$/, '');
  return base + '/' + path.replace(/^\/+/, '');
};
