"""Single JSON mapping; atomic writes and serialized access for the local server."""
import json
import os
import sqlite3
import threading
import uuid
from contextlib import contextmanager


class InventoryStore:
    def __init__(self, root, seed):
        self.path = root / 'inventory.json'
        self.lock = threading.RLock()
        if not self.path.exists():
            legacy = root / 'inventory.sqlite3'
            if legacy.exists():
                conn = sqlite3.connect(f'{legacy.as_uri()}?mode=ro', uri=True)
                conn.row_factory = sqlite3.Row
                try:
                    data = {'schema_version': 1, 'categories': []}
                    for row in conn.execute('SELECT * FROM categories ORDER BY rowid'):
                        cat = dict(row)
                        cat['folder'] = cat['id']
                        cat['functions'] = []
                        for row in conn.execute('SELECT * FROM functions WHERE category=? ORDER BY rowid', (cat['id'],)):
                            fn = dict(row)
                            fn['files'] = [dict(f) for f in conn.execute('SELECT * FROM files WHERE function_id=? ORDER BY rowid', (fn['id'],))]
                            cat['functions'].append(fn)
                        data['categories'].append(cat)
                finally:
                    conn.close()
            else:
                data = seed()
            self.write(data)

    def read(self):
        with self.path.open(encoding='utf-8') as stream:
            return json.load(stream)

    def write(self, data):
        temporary = self.path.with_name('.inventory-' + uuid.uuid4().hex + '.tmp')
        try:
            with temporary.open('x', encoding='utf-8') as stream:
                json.dump(data, stream, ensure_ascii=False, indent=2)
                stream.write('\n')
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, self.path)
        finally:
            temporary.unlink(missing_ok=True)

    @contextmanager
    def edit(self):
        with self.lock:
            data = self.read()
            yield data
            self.write(data)
