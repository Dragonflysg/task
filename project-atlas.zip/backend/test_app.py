import io
import tempfile
import unittest
import json
import sqlite3
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from PIL import Image
from app import create_app

class InventoryTest(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.app = create_app(self.temp.name)
        self.client = self.app.test_client()
        self.headers = {'X-Atlas-Request': '1'}

    def tearDown(self):
        self.temp.cleanup()

    def test_response_helpers_and_cors(self):
        origin='https://frontend.example'
        self.app.config['CORS_ALLOWED_ORIGINS']=(origin,)
        headers={'Origin':origin,'Access-Control-Request-Method':'POST',
                 'Access-Control-Request-Headers':'Content-Type, X-Atlas-Request'}
        response=self.client.options('/api/categories',headers=headers)
        self.assertEqual(response.status_code,200)
        self.assertEqual(response.headers['Access-Control-Allow-Origin'],origin)
        self.assertIn('POST',response.headers['Access-Control-Allow-Methods'])
        self.assertIn('X-Atlas-Request',response.headers['Access-Control-Allow-Headers'])
        response=self.client.get('/api/inventory',headers={'Origin':origin})
        self.assertEqual(response.headers['Access-Control-Allow-Origin'],origin)
        self.assertIn('categories',response.json)
        response=self.client.post('/api/categories',json={'name':'blocked'},headers={'Origin':origin})
        self.assertEqual(response.status_code,403)
        self.assertEqual(response.headers['Access-Control-Allow-Origin'],origin)
        self.assertIn('error',response.json)
        self.assertEqual(self.client.options('/api/categories',headers={**headers,'Origin':'https://unknown.example'}).status_code,403)
        self.assertEqual(self.client.options('/api/categories',headers={**headers,'Access-Control-Request-Method':'DELETE'}).status_code,405)
        self.assertEqual(self.client.options('/api/categories',headers={**headers,'Access-Control-Request-Headers':'X-Unknown'}).status_code,400)
        self.assertEqual(self.client.options('/missing',headers=headers).status_code,404)
        for method in ('GET','DELETE'):
            self.assertEqual(self.client.options('/api/files/example',headers={**headers,'Access-Control-Request-Method':method}).status_code,200)
        with tempfile.TemporaryDirectory() as other:
            other_client=create_app(other).test_client()
            self.client.post('/api/categories',json={'name':'Only this app'},headers=self.headers)
            self.assertEqual(len(other_client.get('/api/inventory').json['categories']),2)

    def test_separate_frontend_deployment(self):
        self.app.config['CORS_ALLOWED_ORIGINS']=('https://web.example.com',)
        origin={'Origin':'https://web.example.com'}
        preflight=self.client.options('/api/functions/system-1/files/srw',headers={**origin,'Access-Control-Request-Method':'POST','Access-Control-Request-Headers':'X-Atlas-Request'})
        self.assertEqual(preflight.status_code,200)
        upload=self.client.post('/api/functions/system-1/files/srw',data={'files':(io.BytesIO(b'window source'),'remote.srw')},headers={**origin,**self.headers})
        self.assertEqual(upload.headers['Access-Control-Allow-Origin'],origin['Origin'])
        file=self.client.get('/api/inventory',headers=origin).json['categories'][0]['functions'][0]['files'][0]
        response=self.client.get('/api/files/'+file['id'],headers=origin)
        self.assertEqual(response.data,b'window source')
        self.assertEqual(response.headers['Access-Control-Allow-Origin'],origin['Origin'])
        response.close()
        self.assertEqual(self.client.get('/api/inventory/export',headers=origin).headers['Access-Control-Allow-Origin'],origin['Origin'])
        self.app.template_folder=str(Path(self.temp.name)/'absent-frontend')
        self.assertEqual(self.client.get('/').json['status'],'ok')

    def test_json_migration_takes_priority_and_sqlite_stays_live(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory)
            expected=self.app.extensions['inventory_store'].read()
            expected['custom']={'future':['preserved']}
            expected['categories'][0]['comment']='Latest JSON notes'
            source=root/'inventory.json'
            source.write_text(json.dumps(expected),encoding='utf-8')
            legacy=root/'inventory.sqlite3'
            legacy.write_bytes(b'old database must not be read or modified')
            app=create_app(directory)
            self.assertEqual(app.extensions['inventory_store'].read(),expected)
            app.test_client().put('/api/categories/Main-System/comment',json={'comment':'SQLite notes'},headers=self.headers)
            self.assertEqual(json.loads(source.read_text()),expected)
            self.assertEqual(legacy.read_bytes(),b'old database must not be read or modified')
            reopened=create_app(directory)
            self.assertEqual(reopened.extensions['inventory_store'].read()['categories'][0]['comment'],'SQLite notes')
            with sqlite3.connect(root/'inventory-live.sqlite3') as conn:
                self.assertEqual(conn.execute('PRAGMA integrity_check').fetchone()[0],'ok')
                self.assertEqual(conn.execute('PRAGMA foreign_key_check').fetchall(),[])
            conn.close()

    def test_sqlite_transactions_across_app_instances(self):
        clients=[create_app(self.temp.name).test_client() for _ in range(4)]
        with ThreadPoolExecutor(max_workers=4) as pool:
            results=list(pool.map(lambda n:clients[n].post('/api/categories',json={'name':f'Independent {n}'},headers=self.headers).status_code,range(4)))
        self.assertEqual(results,[201]*4)
        store=self.app.extensions['inventory_store']
        before=store.read()
        with self.assertRaises(RuntimeError):
            with store.edit() as data:
                data['categories'].clear()
                raise RuntimeError('rollback')
        self.assertEqual(store.read(),before)
        self.assertEqual(len(before['categories']),6)

    def test_json_export_import_validation_and_backup(self):
        exported=self.client.get('/api/inventory/export')
        self.assertIn('attachment',exported.headers['Content-Disposition'])
        original=exported.json
        data=json.loads(json.dumps(original))
        data['categories'][0]['comment']='Imported notes'
        data['custom_field']={'keep':True}
        self.assertEqual(self.client.post('/api/inventory/import',json=data).status_code,403)
        result=self.client.post('/api/inventory/import',json=data,headers=self.headers)
        self.assertEqual(result.status_code,200)
        self.assertEqual(self.client.get('/api/inventory/export').json,data)
        self.assertEqual(json.loads((Path(self.temp.name)/result.json['backup']).read_text(encoding='utf-8')),original)
        for invalid in (None,{}, {'schema_version':2,'categories':[]}):
            self.assertEqual(self.client.post('/api/inventory/import',json=invalid,headers=self.headers).status_code,400)
        for mutate in ('traversal','duplicate','missing'):
            bad=json.loads(json.dumps(data))
            if mutate=='traversal':bad['categories'][0]['folder']='../escape'
            elif mutate=='duplicate':bad['categories'].append(bad['categories'][0])
            else:bad['categories'][0]['photo']='missing.jpg'
            self.assertEqual(self.client.post('/api/inventory/import',json=bad,headers=self.headers).status_code,400)
            self.assertEqual(self.client.get('/api/inventory/export').json,data)

    def test_categories_and_extensible_json(self):
        store=self.app.extensions['inventory_store']
        data=store.read()
        data['future_setting']={'keep':True}
        data['categories'][0]['custom']=['preserve me']
        store.write(data)
        with ThreadPoolExecutor(max_workers=4) as pool:
            results=list(pool.map(lambda n:self.app.test_client().post('/api/categories',json={'name':f'New category {n}'},headers=self.headers).status_code,range(6)))
        self.assertEqual(results,[201]*6)
        response=self.client.post('/api/categories',json={'name':'  new CATEGORY 0 '},headers=self.headers)
        self.assertEqual(response.status_code,409)
        self.assertEqual(self.client.post('/api/categories',json={'name':' '},headers=self.headers).status_code,400)
        data=store.read()
        self.assertTrue(data['future_setting']['keep'])
        self.assertEqual(data['categories'][0]['custom'],['preserve me'])
        self.assertEqual(len(data['categories']),8)
        cat=data['categories'][-1]
        self.assertTrue((Path(self.temp.name)/cat['folder']/'_photos').is_dir())
        fn=self.client.post(f"/api/categories/{cat['id']}/functions",json={'name':'Example'},headers=self.headers).json
        self.assertEqual(self.client.post(f"/api/functions/{fn['id']}/files/srd",data={'files':(io.BytesIO(b'datawindow'),'example.srd')},headers=self.headers).status_code,201)
        reopened=create_app(self.temp.name).test_client().get('/api/inventory').json
        self.assertEqual(reopened['categories'][-1]['functions'][0]['files'][0]['name'],'example.srd')

    def test_function_photo_and_notes_are_isolated(self):
        self.assertEqual(self.client.get('/api/functions/system-1/photo').status_code,404)
        for color in ['red','blue']:
            photo=io.BytesIO();Image.new('RGB',(12,12),color).save(photo,format='PNG');photo.seek(0)
            self.assertEqual(self.client.post('/api/functions/system-1/photo',data={'photo':(photo,'screen.png')},headers=self.headers).status_code,200)
        self.client.put('/api/functions/system-1/comment',json={'comment':'First function only'},headers=self.headers)
        self.client.put('/api/categories/Main-System/comment',json={'comment':'Category stays separate'},headers=self.headers)
        data=create_app(self.temp.name).test_client().get('/api/inventory').json
        cat=data['categories'][0];first,second=cat['functions'][:2]
        self.assertIsNotNone(first['photo_url'])
        self.assertEqual(len(first['photo_history']),1)
        self.assertEqual(first['comment'],'First function only')
        self.assertIsNone(second['photo_url'])
        self.assertEqual(second['comment'],'')
        self.assertEqual(cat['comment'],'Category stays separate')
        self.assertIsNone(cat['photo_url'])
        response=self.client.get(first['photo_url']);self.assertEqual(response.status_code,200);response.close()
        self.assertTrue((Path(self.temp.name)/cat['folder']/first['folder']/'_photos'/first['photo']).exists())

    def test_photo_gallery_preserves_existing_and_replaces_selected(self):
        def image(color):
            stream=io.BytesIO()
            Image.new('RGB',(12,12),color).save(stream,format='PNG')
            stream.seek(0)
            return (stream,'screen.png')
        self.client.post('/api/functions/system-1/photo',data={'photo':image('red')},headers=self.headers)
        def current():
            return create_app(self.temp.name).test_client().get('/api/inventory').json['categories'][0]['functions'][0]
        original=current()['photo_items'][0]['id']
        response=self.client.post('/api/functions/system-1/photos',data={'photos':[image('blue'),image('green')]},headers=self.headers)
        self.assertEqual(response.status_code,201)
        first=current()
        self.assertEqual(len(first['photo_items']),3)
        self.assertEqual(first['photos'][0],original)
        second=first['photos'][1]
        response=self.client.post('/api/functions/system-1/photos',data={'photos':image('white'),'replace':second},headers=self.headers)
        self.assertEqual(response.status_code,201)
        updated=current()
        self.assertEqual(updated['photos'],[original,response.json['selected'],first['photos'][2]])
        self.assertIn(second,updated['photo_history'])
        folder=Path(self.temp.name)/'Main-System'/updated['folder']/'_photos'
        self.assertTrue((folder/second).exists())
        for photo in updated['photo_items']:
            response=self.client.get(photo['url'])
            self.assertEqual(response.status_code,200)
            response.close()
        self.assertEqual(self.client.get('/api/functions/system-2/photos/'+original).status_code,404)
        before=set(folder.iterdir())
        response=self.client.post('/api/functions/system-1/photos',data={'photos':[image('black'),(io.BytesIO(b'bad'),'fake.png')]},headers=self.headers)
        self.assertEqual(response.status_code,400)
        self.assertEqual(set(folder.iterdir()),before)
        self.assertEqual(current()['photos'],updated['photos'])
        self.assertEqual(self.client.post('/api/functions/system-1/photos').status_code,403)
        for photo in updated['photo_items']:
            self.assertEqual(self.client.delete(photo['url']).status_code,403)
            self.assertEqual(self.client.delete(photo['url'],headers=self.headers).status_code,200)
            self.assertTrue((folder/photo['id']).exists())
            self.assertEqual(self.client.get(photo['url']).status_code,404)
        self.assertEqual(current()['photo_items'],[])
        self.assertIsNone(current()['photo'])
        self.assertIsNone(current()['photo_url'])

    def test_detach_preserves_file_and_record(self):
        self.client.post('/api/functions/system-1/files/srw',data={'files':[(io.BytesIO(b'keep this source'),'keep.srw'),(io.BytesIO(b'other'),'other.srw')]},headers=self.headers)
        data=self.client.get('/api/inventory').json
        cat=data['categories'][0];fn=cat['functions'][0];file=fn['files'][0]
        path=Path(self.temp.name)/cat['folder']/fn['folder']/'srw'/file['name']
        self.assertEqual(self.client.delete('/api/files/'+file['id']).status_code,403)
        response=self.client.delete('/api/files/'+file['id'],headers=self.headers)
        self.assertEqual(response.status_code,200)
        self.assertTrue(response.json['file_preserved'])
        self.assertEqual(path.read_bytes(),b'keep this source')
        fn=create_app(self.temp.name).test_client().get('/api/inventory').json['categories'][0]['functions'][0]
        self.assertEqual([f['name'] for f in fn['files']],['other.srw'])
        self.assertEqual(fn['detached_files'],[file])
        self.assertEqual(self.client.delete('/api/files/'+file['id'],headers=self.headers).status_code,200)
        self.assertEqual(self.client.delete('/api/files/nonexistent',headers=self.headers).status_code,404)

    def test_sqlite_migration(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory)
            with sqlite3.connect(root/'inventory.sqlite3') as conn:
                conn.executescript("CREATE TABLE categories(id,name,comment,photo); CREATE TABLE functions(id,category,name,folder,comment); CREATE TABLE files(id,function_id,type,name,size);")
                conn.execute('INSERT INTO categories VALUES (?,?,?,?)',('existing','Existing','notes','image.jpg'))
                conn.execute('INSERT INTO functions VALUES (?,?,?,?,?)',('f','existing','Function','Function','function notes'))
                conn.execute('INSERT INTO files VALUES (?,?,?,?,?)',('file','f','srw','window.srw',4))
            conn.close()
            data=create_app(directory).test_client().get('/api/inventory').json
            self.assertEqual(len(data['categories']),1)
            self.assertEqual(data['categories'][0]['comment'],'notes')
            self.assertEqual(data['categories'][0]['functions'][0]['files'][0]['id'],'file')
            self.assertTrue((root/'inventory.sqlite3').exists())

    def test_workflow_persistence_and_validation(self):
        self.assertEqual(self.client.get('/').status_code, 200)
        data = self.client.get('/api/inventory').json
        self.assertEqual(len(data['categories'][0]['functions']), 8)
        self.assertEqual(len(data['categories'][1]['functions']), 0)
        self.assertEqual(self.client.put('/api/categories/Main-System/comment', json={'comment':'blocked'}).status_code, 403)
        response = self.client.put('/api/categories/Main-System/comment', json={'comment':'My notes'}, headers=self.headers)
        self.assertEqual(response.status_code, 200)
        for _ in range(2):
            response = self.client.post('/api/functions/system-1/files/srw', data={'files':[(io.BytesIO(b'window source'),'w_invoice.srw'),(io.BytesIO(b'other'),'other.srw')]},headers=self.headers)
            self.assertEqual(response.status_code,201)
        rows = self.client.get('/api/inventory').json['categories'][0]['functions'][0]['files']
        self.assertEqual(len(rows),4)
        self.assertEqual(len({r['name'] for r in rows}),4)
        response=self.client.get('/api/files/'+rows[0]['id'])
        self.assertEqual(response.data,b'window source')
        self.assertIn('attachment',response.headers['Content-Disposition'])
        response.close()
        response=self.client.post('/api/functions/system-1/files/srw',data={'files':[(io.BytesIO(b'ok'),'valid.srw'),(io.BytesIO(b'bad'),'bad.exe')]},headers=self.headers)
        self.assertEqual(response.status_code,400)
        self.assertEqual(len(self.client.get('/api/inventory').json['categories'][0]['functions'][0]['files']),4)
        response=self.client.post('/api/functions/system-1/files/srw',data={'files':(io.BytesIO(b'test'),'../../safe.srw')},headers=self.headers)
        self.assertEqual(response.status_code,201)
        self.assertFalse((Path(self.temp.name).parent/'safe.srw').exists())
        photo=io.BytesIO();Image.new('RGB',(20,20),'white').save(photo,format='PNG');photo.seek(0)
        self.assertEqual(self.client.post('/api/categories/Main-System/photo',data={'photo':(photo,'photo.png')},headers=self.headers).status_code,200)
        response=self.client.get('/api/categories/Main-System/photo');self.assertEqual(response.mimetype,'image/jpeg');response.close()
        self.assertEqual(self.client.post('/api/categories/Main-System/photo',data={'photo':(io.BytesIO(b'not image'),'fake.png')},headers=self.headers).status_code,400)
        added=self.client.post('/api/categories/Main-Invoices/functions',json={'name':'New function'},headers=self.headers)
        self.assertEqual(added.status_code,201)
        self.assertEqual(self.client.post('/api/categories/Main-Invoices/functions',json={'name':'New function'},headers=self.headers).status_code,409)
        self.assertEqual(self.client.get('/api/functions/missing/files/srw').status_code,405)
        reloaded=create_app(self.temp.name).test_client().get('/api/inventory').json
        self.assertEqual(reloaded['categories'][0]['comment'],'My notes')
        self.assertEqual(len(reloaded['categories'][1]['functions']),1)
        self.assertTrue(reloaded['categories'][0]['photo_url'])

if __name__=='__main__':
    unittest.main()
