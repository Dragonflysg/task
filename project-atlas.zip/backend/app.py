"""HTTP endpoints and server entry point. Run: python app.py"""
from flask import Flask
from pathlib import Path
import os
from werkzeug.exceptions import HTTPException
import controllers_server as controllers


def create_app(data_dir=None):
    frontend = Path(__file__).resolve().parent.parent / 'frontend'
    app = Flask(__name__, template_folder=str(frontend), static_folder=str(frontend / 'static'), static_url_path='/static')
    controllers.initialize(app, data_dir)
    app.before_request(controllers.local_write_guard)
    app.after_request(controllers.headers)
    app.register_error_handler(HTTPException, controllers.http_error)

    # URL -> handler: all request processing lives in controllers_server.py.
    app.add_url_rule('/', view_func=controllers.index, methods=['GET'])
    app.add_url_rule('/api/inventory', view_func=controllers.inventory, methods=['GET'])
    app.add_url_rule('/api/inventory/export', view_func=controllers.export_inventory, methods=['GET'])
    app.add_url_rule('/api/inventory/import', view_func=controllers.import_inventory, methods=['POST'])
    app.add_url_rule('/api/categories', view_func=controllers.add_category, methods=['POST'])
    app.add_url_rule('/api/categories/<ident>/comment', view_func=controllers.save_comment, methods=['PUT'])
    app.add_url_rule('/api/functions/<ident>/comment', view_func=controllers.save_comment, methods=['PUT'])
    app.add_url_rule('/api/categories/<ident>/photo', view_func=controllers.upload_photo, methods=['POST'])
    app.add_url_rule('/api/functions/<ident>/photo', view_func=controllers.upload_photo, methods=['POST'])
    app.add_url_rule('/api/functions/<ident>/photos', view_func=controllers.upload_gallery, methods=['POST'])
    app.add_url_rule('/api/functions/<ident>/photos/<name>', view_func=controllers.gallery_photo, methods=['GET'])
    app.add_url_rule('/api/functions/<ident>/photos/<name>', view_func=controllers.remove_photo, methods=['DELETE'])
    app.add_url_rule('/api/functions/<ident>/photo', view_func=controllers.function_photo, methods=['GET'])
    app.add_url_rule('/api/categories/<ident>/photo', view_func=controllers.photo, methods=['GET'])
    app.add_url_rule('/api/categories/<ident>/functions', view_func=controllers.add_function, methods=['POST'])
    app.add_url_rule('/api/functions/<ident>/files/<ext>', view_func=controllers.upload_files, methods=['POST'])
    app.add_url_rule('/api/files/<ident>', view_func=controllers.detach_file, methods=['DELETE'])
    app.add_url_rule('/api/files/<ident>', view_func=controllers.download, methods=['GET'])
    return app


if __name__ == '__main__':
    create_app().run(host=os.environ.get('ATLAS_HOST', '127.0.0.1'), port=int(os.environ.get('ATLAS_PORT', '5055')), debug=False)
