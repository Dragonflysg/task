"""Request handlers and application logic for the IES inventory."""
from pathlib import Path
from io import BytesIO
import os
import uuid
import json
from flask import current_app, jsonify, render_template, request, send_from_directory, abort
from werkzeug.utils import secure_filename
from PIL import Image, UnidentifiedImageError
from storage import InventoryStore, validate_inventory

BASE = Path(__file__).resolve().parent
TYPES = {'srw': 'Windows', 'srf': 'Functions', 'srd': 'DataWindows', 'sru': 'User objects', 'srm': 'Menus', 'srs': 'Structures', 'sra': 'Application', 'srq': 'Queries', 'srj': 'Projects'}
FUNCTIONS = ['Invoice Search (New, Amend, Delete, Search)', 'Invoice Transfer', 'Invoice Printing → Customer Invoice', 'Invoice Printing → TW: Print Commercial Invoices', 'Invoice Printing → TW: Print Local Language Invoices', 'Invoice Printing → TW: Print & Assign GUI Invoices', 'Invoice Printing → Invoice Deletion History', 'Invoice Repository Search']

def initialize(app, data_dir=None):
    """Create storage for this app instance; tests can use an isolated folder."""
    app.config['MAX_CONTENT_LENGTH'] = 32 * 1024 * 1024
    app.config.setdefault('CORS_ALLOWED_ORIGINS', tuple(
        origin.strip() for origin in os.environ.get('ATLAS_CORS_ORIGINS', '').split(',') if origin.strip()
    ))
    root = Path(data_dir or os.environ.get('ATLAS_DATA_DIR', BASE / 'workspace')).resolve()
    root.mkdir(parents=True, exist_ok=True)
    store = InventoryStore(root, seed)
    app.extensions['inventory_store'] = store
    app.extensions['inventory_root'] = root
    app.config['INVENTORY_PATH'] = str(store.path)
    for cat in store.read()['categories']:
        (root / cat['folder'] / '_photos').mkdir(parents=True, exist_ok=True)
        for fn in cat['functions']:
            for ext in TYPES:
                (root / cat['folder'] / fn['folder'] / ext).mkdir(parents=True, exist_ok=True)


def get_store():
    return current_app.extensions['inventory_store']


def get_root():
    return current_app.extensions['inventory_root']


def _cors_headers(response):
    origin = request.headers.get('Origin')
    response.vary.add('Origin')
    if origin and (origin == request.host_url.rstrip('/') or origin in current_app.config['CORS_ALLOWED_ORIGINS']):
        response.headers['Access-Control-Allow-Origin'] = origin
    return response


def build_response(JSONDATA=None, status=200, **fields):
    """Build a JSON response without changing the API's payload format."""
    response = jsonify(fields if JSONDATA is None else JSONDATA)
    response.status_code = status
    return _cors_headers(response)


def _build_cors_preflight_response():
    """Answer OPTIONS using the methods registered for the requested route."""
    response = current_app.make_default_options_response()
    if request.headers.get('Origin'):
        _cors_headers(response)
        if 'Access-Control-Allow-Origin' not in response.headers:
            abort(403, 'Origin is not allowed.')
        method = request.headers.get('Access-Control-Request-Method')
        if method and method not in response.headers['Allow'].replace(' ', '').split(','):
            abort(405)
        allowed_headers = {'content-type', 'x-atlas-request'}
        requested = {h.strip().lower() for h in request.headers.get('Access-Control-Request-Headers', '').split(',') if h.strip()}
        if not requested.issubset(allowed_headers):
            abort(400, 'Requested header is not allowed.')
        response.headers['Access-Control-Allow-Methods'] = response.headers['Allow']
        response.headers['Access-Control-Allow-Headers'] = 'Content-Type, X-Atlas-Request'
    return response


def seed():
    categories = [{'id': name, 'name': name, 'folder': name, 'comment': '', 'photo': None, 'functions': []} for name in ('Main-System', 'Main-Invoices')]
    for n, name in enumerate(FUNCTIONS):
        categories[0]['functions'].append({'id': f'system-{n+1}', 'category': 'Main-System', 'name': name, 'folder': secure_filename(name.replace('→', '-')), 'comment': '', 'files': []})
    return {'schema_version': 1, 'categories': categories}

def category(ident, data=None):
    for cat in (data if data is not None else get_store().read())['categories']:
        if cat['id'] == ident:
            return cat
    abort(404, 'Category not found.')

def function(ident, data=None):
    for cat in (data if data is not None else get_store().read())['categories']:
        for fn in cat['functions']:
            if fn['id'] == ident:
                return fn
    abort(404, 'Function not found.')

def category_folder(cat):
    return get_root() / cat['folder']

def photo_names(fn):
    return fn.get('photos', [fn['photo']] if fn.get('photo') else [])

def local_write_guard():
    if request.method == 'OPTIONS' and request.url_rule is not None:
        return _build_cors_preflight_response()
    if request.method in ('POST', 'PUT', 'PATCH', 'DELETE') and request.headers.get('X-Atlas-Request') != '1':
        abort(403, 'Please submit changes through the application.')

def headers(response):
    _cors_headers(response)
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['X-Frame-Options'] = 'DENY'
    return response

def http_error(error):
    return build_response(error=error.description), error.code

def index():
    if not (Path(current_app.template_folder) / 'index.html').exists():
        return build_response({'service':'Files - Functions and Relationships API', 'status':'ok'})
    return render_template('index.html')

def export_inventory():
    response = build_response(get_store().read())
    response.headers['Content-Disposition'] = 'attachment; filename="inventory-export.json"'
    return response


def import_inventory():
    data = request.get_json(silent=True)
    try:
        validate_inventory(data)
        # Import metadata only; active references must already exist in this workspace.
        root = get_root()
        paths = []
        for cat in data['categories']:
            base = root / cat['folder']
            if cat.get('photo'):
                paths.append(base / '_photos' / cat['photo'])
            for fn in cat['functions']:
                folder = base / fn['folder']
                paths.extend(folder / '_photos' / name for name in photo_names(fn))
                paths.extend(folder / file['type'] / file['name'] for file in fn.get('files', []))
        for path in paths:
            if not path.resolve().is_relative_to(root) or not path.is_file():
                raise ValueError('A referenced image or source file is missing from this workspace: ' + path.name)
    except ValueError as error:
        abort(400, str(error))
    backup = get_root() / 'backups' / ('before-import-' + uuid.uuid4().hex + '.json')
    backup.parent.mkdir(exist_ok=True)
    with get_store().edit() as current:
        with backup.open('x', encoding='utf-8') as stream:
            json.dump(current, stream, ensure_ascii=False, indent=2)
            stream.flush()
            os.fsync(stream.fileno())
        current.clear()
        current.update(data)
    for cat in data['categories']:
        (get_root() / cat['folder'] / '_photos').mkdir(parents=True, exist_ok=True)
        for fn in cat['functions']:
            for ext in TYPES:
                (get_root() / cat['folder'] / fn['folder'] / ext).mkdir(parents=True, exist_ok=True)
    return build_response(imported=True, backup=str(backup.relative_to(get_root())))


def inventory():
    data = get_store().read()
    for cat in data['categories']:
        cat['photo_url'] = f"/api/categories/{cat['id']}/photo?v={cat['photo']}" if cat.get('photo') else None
        for fn in cat['functions']:
            fn['photo_url'] = f"/api/functions/{fn['id']}/photo?v={fn['photo']}" if fn.get('photo') else None
            fn['photo_items'] = [{'id': name, 'url': f"/api/functions/{fn['id']}/photos/{name}"} for name in photo_names(fn)]
    return build_response({**data, 'types': TYPES})

def add_category():
    name = (request.get_json(silent=True) or {}).get('name', '')
    if not isinstance(name, str) or not name.strip() or len(name) > 160:
        abort(400, 'Enter a category name of 1–160 characters.')
    name = name.strip()
    ident = uuid.uuid4().hex
    folder = (secure_filename(name)[:80] or 'category') + '-' + ident[:8]
    with get_store().edit() as data:
        if any(c['name'].casefold() == name.casefold() for c in data['categories']):
            abort(409, 'That category already exists.')
        (get_root() / folder / '_photos').mkdir(parents=True, exist_ok=True)
        data['categories'].append({'id': ident, 'name': name, 'folder': folder, 'comment': '', 'photo': None, 'functions': []})
    return build_response(id=ident), 201

def save_comment(ident):
    table = 'categories' if '/categories/' in request.path else 'functions'
    (category if table == 'categories' else function)(ident)
    text = (request.get_json(silent=True) or {}).get('comment')
    if not isinstance(text, str) or len(text) > 20000:
        abort(400, 'Comments must be text, up to 20,000 characters.')
    with get_store().edit() as data:
        (category if table == 'categories' else function)(ident, data)['comment'] = text
    return build_response(saved=True)

def upload_photo(ident):
    is_function = '/functions/' in request.path
    owner = function(ident) if is_function else category(ident)
    cat = category(owner['category']) if is_function else owner
    photo_folder = category_folder(cat) / owner['folder'] / '_photos' if is_function else category_folder(cat) / '_photos'
    upload = request.files.get('photo')
    if not upload or not upload.filename:
        abort(400, 'Choose a PNG, JPEG or WebP image.')
    try:
        image = Image.open(BytesIO(upload.read()))
        if image.format not in ('PNG', 'JPEG', 'WEBP') or image.width * image.height > 30000000:
            abort(400, 'Use a PNG, JPEG or WebP image under 30 megapixels.')
        image.load()
        image = image.convert('RGB')
    except (UnidentifiedImageError, OSError, Image.DecompressionBombError):
        abort(400, 'This file is not a valid supported image.')
    name = uuid.uuid4().hex + '.jpg'
    photo_folder.mkdir(parents=True, exist_ok=True)
    image.save(photo_folder / name, 'JPEG', quality=92)
    with get_store().edit() as data:
        target = function(ident, data) if is_function else category(ident, data)
        if target.get('photo'):
            target.setdefault('photo_history', []).append(target['photo'])
        target['photo'] = name
        if is_function and 'photos' in target:
            if target['photos']:
                target['photos'][0] = name
            else:
                target['photos'].append(name)
    return build_response(saved=True)

def upload_gallery(ident):
    fn = function(ident)
    uploads = request.files.getlist('photos')
    replace = request.form.get('replace')
    if not uploads or len(uploads) > 20 or (replace and len(uploads) != 1):
        abort(400, 'Choose 1–20 photos, or one image when replacing a photo.')
    if replace and replace not in photo_names(fn):
        abort(404, 'The photo to replace was not found.')
    folder = category_folder(category(fn['category'])) / fn['folder'] / '_photos'
    folder.mkdir(parents=True, exist_ok=True)
    written = []
    try:
        for upload in uploads:
            try:
                with Image.open(upload.stream) as image:
                    if image.format not in ('PNG', 'JPEG', 'WEBP') or image.width * image.height > 30000000:
                        abort(400, 'Use PNG, JPEG or WebP images under 30 megapixels.')
                    image.load()
                    name = uuid.uuid4().hex + '.jpg'
                    path = folder / name
                    written.append(path)
                    image.convert('RGB').save(path, 'JPEG', quality=92)
            except (UnidentifiedImageError, OSError, Image.DecompressionBombError):
                abort(400, 'An image could not be read. No photos were added.')
        with get_store().edit() as data:
            target = function(ident, data)
            names = list(photo_names(target))
            if replace:
                if replace not in names:
                    abort(409, 'That photo has changed. Refresh and try again.')
                names[names.index(replace)] = written[0].name
                target.setdefault('photo_history', []).append(replace)
            else:
                names.extend(path.name for path in written)
            target['photos'] = names
            target['photo'] = names[0]
    except Exception:
        for path in written:
            path.unlink(missing_ok=True)
        raise
    return build_response(saved=len(written), selected=written[0].name), 201

def remove_photo(ident, name):
    """Detach a gallery image while retaining its original file on disk."""
    with get_store().edit() as data:
        target = function(ident, data)
        names = list(photo_names(target))
        if name not in names:
            abort(404, 'Photo not found.')
        names.remove(name)
        target.setdefault('photo_history', []).append(name)
        target['photos'] = names
        target['photo'] = names[0] if names else None
    return build_response(removed=True, file_preserved=True)


def gallery_photo(ident, name):
    fn = function(ident)
    if name not in photo_names(fn):
        abort(404)
    return send_from_directory(category_folder(category(fn['category'])) / fn['folder'] / '_photos', name, mimetype='image/jpeg')

def function_photo(ident):
    fn = function(ident)
    if not fn.get('photo'):
        abort(404)
    return send_from_directory(category_folder(category(fn['category'])) / fn['folder'] / '_photos', fn['photo'], mimetype='image/jpeg')

def photo(ident):
    cat = category(ident)
    if not cat['photo']:
        abort(404)
    return send_from_directory(category_folder(cat) / '_photos', cat['photo'], mimetype='image/jpeg')

def add_function(ident):
    cat = category(ident)
    name = (request.get_json(silent=True) or {}).get('name', '')
    if not isinstance(name, str) or not name.strip() or len(name) > 160:
        abort(400, 'Enter a function name of 1–160 characters.')
    name = name.strip()
    fid = uuid.uuid4().hex
    folder = (secure_filename(name)[:80] or 'function') + '-' + fid[:8]
    with get_store().edit() as data:
        target = category(ident, data)
        if any(f['name'].casefold() == name.casefold() for f in target['functions']):
            abort(409, 'That function already exists in this category.')
        for ext in TYPES:
            (category_folder(cat) / folder / ext).mkdir(parents=True, exist_ok=True)
        target['functions'].append({'id': fid, 'category': ident, 'name': name, 'folder': folder, 'comment': '', 'files': []})
    return build_response(id=fid), 201

def upload_files(ident, ext):
    fn = function(ident)
    if ext not in TYPES:
        abort(400, 'Unknown file type.')
    uploads = request.files.getlist('files')
    if not uploads or len(uploads) > 50:
        abort(400, 'Choose between 1 and 50 files per upload.')
    names = []
    for upload in uploads:
        name = secure_filename(upload.filename or '')
        if not name or Path(name).suffix.lower() != '.' + ext:
            abort(400, f'Every file in this folder must have the .{ext} extension. Nothing was uploaded.')
        names.append(name)
    folder = category_folder(category(fn['category'])) / fn['folder'] / ext
    written = []
    try:
        with get_store().edit() as data:
            target_function = function(ident, data)
            for upload, name in zip(uploads, names):
                target = folder / name
                counter = 2
                while True:
                    try:
                        stream = target.open('xb')
                        break
                    except FileExistsError:
                        target = folder / f'{Path(name).stem} ({counter}){Path(name).suffix}'
                        counter += 1
                written.append(target)
                with stream:
                    upload.save(stream)
                target_function['files'].append({'id': uuid.uuid4().hex, 'function_id': ident, 'type': ext, 'name': target.name, 'size': target.stat().st_size})
    except Exception:
        for target in written:
            target.unlink(missing_ok=True)
        raise
    return build_response(saved=len(written)), 201

def detach_file(ident):
    # Remove the active association only; never delete or move the source file.
    with get_store().edit() as data:
        for cat in data['categories']:
            for fn in cat['functions']:
                for index, file in enumerate(fn['files']):
                    if file['id'] == ident:
                        fn.setdefault('detached_files', []).append(fn['files'].pop(index))
                        return build_response(removed=True, file_preserved=True)
                if any(file['id'] == ident for file in fn.get('detached_files', [])):
                    return build_response(removed=True, file_preserved=True)
        abort(404, 'File not found.')

def download(ident):
    for cat in get_store().read()['categories']:
        for fn in cat['functions']:
            for file in fn['files']:
                if file['id'] == ident:
                    return send_from_directory(category_folder(cat) / fn['folder'] / file['type'], file['name'], as_attachment=True)
    abort(404)
