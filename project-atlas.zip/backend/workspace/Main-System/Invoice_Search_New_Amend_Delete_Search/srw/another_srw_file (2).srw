POWERBUILDER SCREENSHOT TRANSCRIPTION
Sources: SRF.jpg and SRW.jpg. Transcribed from the supplied photographs.
Editor line numbers and surrounding editor/desktop UI are excluded.
Whitespace is normalized; source spelling and identifiers are retained.
SRF line 9 ends at the photograph's right edge after "This function calculate".
The missing continuation is NOT reconstructed. This is a transcription, not a
verified importable or compilable PowerBuilder export.

===== SRF.jpg | f_calc_prorate_mth_by_mth.srf =====
$PBExportHeader$f_calc_prorate_mth_by_mth.srf
global type f_calc_prorate_mth_by_mth from function_object
end type

forward prototypes
global function decimal f_calc_prorate_mth_by_mth (datetime adt_sdate, datetime adt_edate)
end prototypes

global function decimal f_calc_prorate_mth_by_mth (datetime adt_sdate, datetime adt_edate);//* This function calculate
//e.g. 15 Feb to 10 Apr -> 14/28 + 31/31 + 10/30
integer li_no_of_mth, i_cnt
decimal ldec_prorate_factor
integer li_last_day, li_day_in_calc_month
date ld_calc_start_date, ld_calc_end_date, ld_calc_month

ldec_prorate_factor = 0

li_no_of_mth = integer(f_calc_otc_period_span(adt_sdate, adt_edate))
//**ld_calc_month store the last day of the month
ld_calc_month = f_lastday_of_month(date(adt_sdate))
ld_calc_start_date = date(adt_sdate)

For i_cnt = 1 to li_no_of_mth
    //get calc current month period
    if i_cnt = li_no_of_mth then
        ld_calc_end_date= date(adt_edate)
    else
        ld_calc_end_date= ld_calc_month
    end if

    li_day_in_calc_month = DaysAfter ( ld_calc_start_date, ld_calc_end_date ) + 1
    li_last_day = f_days_in_month(month(ld_calc_month), year(ld_calc_month))

    ldec_prorate_factor = ldec_prorate_factor + li_day_in_calc_month / li_last_day

    ld_calc_start_date = RelativeDate(ld_calc_month,1)
    ld_calc_month = f_lastday_of_month(ld_calc_start_date)
next
return ldec_prorate_factor
end function

===== SRW.jpg | w_master_sheet.srw =====
$PBExportHeader$w_master_sheet.srw
$PBExportComments$Main MDI Sheet with a window heading. It change the window heading to the window title. It contains the characteristics which are common to all work sheets opened.
forward
global type w_master_sheet from Window
end type
type st_title from statictext within w_master_sheet
end type
end forward
global type w_master_sheet from Window
int X=22
int Y=3
int Width=2893
int Height=1894
boolean TitleBar=true
string Title="Untitled"
long BackColor=79741120
boolean ControlMenu=true
boolean MinBox=true
boolean MaxBox=true
boolean Resizable=true
st_title st_title
end type
global w_master_sheet w_master_sheet
event open;This.Title = Trim(st_title.Text)

//gnv_app.inv_security.of_SetSecurity(This)
end event

on w_master_sheet.create
this.st_title=create st_title
this.Control[]={this.st_title}
end on

on w_master_sheet.destroy
destroy(this.st_title)
end on

type st_title from statictext within w_master_sheet
int X=110
int Y=29
int Width=1181
int Height=70
boolean Enabled=false
string Text="Title"
boolean FocusRectangle=false
long TextColor=33554432
long BackColor=67108864
int TextSize=-10
int Weight=400
string FaceName="Times New Roman"
boolean Underline=true
FontFamily FontFamily=Roman!
FontPitch FontPitch=Variable!
end type
