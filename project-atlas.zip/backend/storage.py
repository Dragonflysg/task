"""SQLite inventory with relational ownership and extensible JSON attributes."""
import json
import sqlite3
from contextlib import contextmanager
from pathlib import Path
from storage_json_legacy import InventoryStore as LegacyStore


def validate_inventory(data):
    """Validate relationships and safe relative disk names before import."""
    def require(condition, message):
        if not condition:
            raise ValueError(message)
    def component(value):
        require(isinstance(value, str) and value not in ('', '.', '..') and
                not any(c in value for c in '/\\:*?"<>|') and
                not any(ord(c)<32 for c in value) and not value.endswith((' ', '.')),
                'Invalid folder or filename in inventory.')
        require(value.split('.')[0].upper() not in {'CON','PRN','AUX','NUL',*[f'COM{i}' for i in range(1,10)],*[f'LPT{i}' for i in range(1,10)]}, 'Reserved disk name.')
    def object_fields(obj):
        require(isinstance(obj,dict), 'Expected an object.')
        require(isinstance(obj.get('id'),str) and bool(obj['id']), 'Every object needs an ID.')
        require(isinstance(obj.get('name'),str) and bool(obj['name']), 'Every object needs a name.')
    def photos(obj):
        for key in ('photos','photo_history'):
            require(isinstance(obj.get(key,[]),list), 'Photo references must be lists.')
            for name in obj.get(key,[]): component(name)
        if obj.get('photo'): component(obj['photo'])
        if 'photos' in obj:
            require(len(set(obj['photos']))==len(obj['photos']), 'Duplicate photo references.')
            require(obj.get('photo')==(obj['photos'][0] if obj['photos'] else None), 'Primary photo must match the gallery.')
        require(isinstance(obj.get('comment',''),str),'Comments must be text.')
    require(isinstance(data,dict) and data.get('schema_version')==1 and isinstance(data.get('categories'),list), 'Expected schema_version 1 and a categories list.')
    cats=set(); functions=set(); files=set(); folders=set(); catnames=set()
    for cat in data['categories']:
        object_fields(cat); component(cat.get('folder')); photos(cat)
        require('photo' in cat, 'Category photo field is required (use null if empty).')
        require(cat['id'] not in cats and cat['folder'].casefold() not in folders and cat['name'].casefold() not in catnames,'Duplicate category.')
        cats.add(cat['id']); folders.add(cat['folder'].casefold()); catnames.add(cat['name'].casefold())
        require(isinstance(cat.get('functions'),list),'Category functions must be a list.')
        fnfolders=set(); fnnames=set()
        for fn in cat['functions']:
            object_fields(fn); component(fn.get('folder')); photos(fn)
            require(fn['folder'].casefold() != '_photos', 'Function folder cannot be _photos.')
            require(isinstance(fn.get('files'),list), 'Function files must be a list.')
            require(fn.get('category')==cat['id'] and fn['id'] not in functions,'Invalid function ownership or duplicate ID.')
            require(fn['folder'].casefold() not in fnfolders and fn['name'].casefold() not in fnnames,'Duplicate function name or folder.')
            functions.add(fn['id']); fnfolders.add(fn['folder'].casefold()); fnnames.add(fn['name'].casefold())
            for key in ('files','detached_files'):
                require(isinstance(fn.get(key,[]),list),'Files must be a list.')
                for file in fn.get(key,[]):
                    object_fields(file); component(file['name'])
                    require(file.get('type') in ('srw','srf','srd','sru','srm','srs','sra','srq','srj'),'Unknown source file type.')
                    require(file.get('function_id')==fn['id'] and file['id'] not in files,'Invalid file ownership or duplicate ID.')
                    require(isinstance(file.get('size'),int) and file['size']>=0,'Invalid file size.')
                    files.add(file['id'])


class InventoryStore:
    def __init__(self, root, seed):
        self.root = Path(root)
        self.path = self.root / 'inventory-live.sqlite3'
        with self.connection() as conn:
            conn.executescript('''
                CREATE TABLE IF NOT EXISTS metadata (id INTEGER PRIMARY KEY CHECK(id=1), payload TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS categories (id TEXT PRIMARY KEY, position INTEGER NOT NULL, payload TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS functions (id TEXT PRIMARY KEY, category_id TEXT NOT NULL REFERENCES categories(id), position INTEGER NOT NULL, payload TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS files (id TEXT PRIMARY KEY, function_id TEXT NOT NULL REFERENCES functions(id), position INTEGER NOT NULL, payload TEXT NOT NULL);
                CREATE INDEX IF NOT EXISTS functions_category ON functions(category_id);
                CREATE INDEX IF NOT EXISTS files_function ON files(function_id);
            ''')
            conn.execute('BEGIN IMMEDIATE')
            if not conn.execute('SELECT 1 FROM metadata').fetchone():
                if (self.root/'inventory.json').exists():
                    data=json.loads((self.root/'inventory.json').read_text(encoding='utf-8-sig'))
                elif (self.root/'inventory.sqlite3').exists():
                    data=LegacyStore(self.root,seed).read()
                else:
                    data=seed()
                validate_inventory(data)
                self._write(conn,data)

    @contextmanager
    def connection(self):
        conn=sqlite3.connect(self.path,timeout=30)
        conn.execute('PRAGMA foreign_keys=ON')
        try:
            yield conn
            conn.commit()
        except BaseException:
            conn.rollback()
            raise
        finally:
            conn.close()

    def _read(self,conn):
        data=json.loads(conn.execute('SELECT payload FROM metadata WHERE id=1').fetchone()[0])
        data['categories']=[]
        for ident,payload in conn.execute('SELECT id,payload FROM categories ORDER BY position'):
            cat=json.loads(payload); cat['functions']=[]
            for fid,fpayload in conn.execute('SELECT id,payload FROM functions WHERE category_id=? ORDER BY position',(ident,)):
                fn=json.loads(fpayload)
                fn['files']=[json.loads(row[0]) for row in conn.execute('SELECT payload FROM files WHERE function_id=? ORDER BY position',(fid,))]
                cat['functions'].append(fn)
            data['categories'].append(cat)
        return data

    def read(self):
        with self.connection() as conn:
            conn.execute('BEGIN')
            return self._read(conn)

    def _write(self,conn,data):
        conn.execute('PRAGMA defer_foreign_keys=ON')
        # Update only changed rows; preserve arbitrary future attributes in payloads.
        encode=lambda obj:json.dumps(obj,ensure_ascii=False,sort_keys=True)
        wanted={'categories':{},'functions':{},'files':{}}
        for pos,cat in enumerate(data['categories']):
            wanted['categories'][cat['id']]=(pos,encode({k:v for k,v in cat.items() if k!='functions'}))
            for fpos,fn in enumerate(cat['functions']):
                wanted['functions'][fn['id']]=(cat['id'],fpos,encode({k:v for k,v in fn.items() if k!='files'}))
                for ipos,file in enumerate(fn['files']):
                    wanted['files'][file['id']]=(fn['id'],ipos,encode(file))
        existing={table:dict((row[0],row[1:]) for row in conn.execute('SELECT * FROM '+table)) for table in wanted}
        # Remove children first for foreign-key integrity.
        for table in ('files','functions','categories'):
            for ident in existing[table].keys()-wanted[table].keys():
                conn.execute('DELETE FROM '+table+' WHERE id=?',(ident,))
        for table,rows in wanted.items():
            columns={'categories':'position,payload','functions':'category_id,position,payload','files':'function_id,position,payload'}[table].split(',')
            for ident,row in rows.items():
                if existing[table].get(ident)!=row:
                    if ident in existing[table]:
                        conn.execute('UPDATE '+table+' SET '+','.join(c+'=?' for c in columns)+' WHERE id=?',(*row,ident))
                    else:
                        conn.execute('INSERT INTO '+table+' VALUES ('+','.join('?' for _ in range(len(row)+1))+')',(ident,*row))
        conn.execute('INSERT INTO metadata VALUES (1,?) ON CONFLICT(id) DO UPDATE SET payload=excluded.payload',(encode({k:v for k,v in data.items() if k!='categories'}),))

    def write(self,data):
        validate_inventory(data)
        with self.connection() as conn:
            conn.execute('BEGIN IMMEDIATE')
            self._write(conn,data)

    @contextmanager
    def edit(self):
        with self.connection() as conn:
            conn.execute('BEGIN IMMEDIATE')
            data=self._read(conn)
            yield data
            self._write(conn,data)
