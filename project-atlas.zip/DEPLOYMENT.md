# Deploy on separate servers

## What to copy

- Web server: copy the contents of `frontend/` into the website directory. It contains `index.html` and `static/` (including bundled fonts and jQuery). Serve over HTTP(S), not file://. Hosting at a subfolder such as `/files/` works; open its trailing-slash URL.
- API server: copy `backend/`, including `workspace/`. Stop the running app before copying SQLite. Never put `workspace/` or Python files in the frontend website directory. `test_app.py` and `__pycache__/` are not needed for deployment.
- Existing workspace data was moved, not duplicated. The active database remains `backend/workspace/inventory-live.sqlite3`.

## Frontend configuration

Edit `frontend/static/config.js` on the web server:

```javascript
window.IES_CONFIG = { apiBaseUrl: 'https://api.example.com' };
```

Replace the example with the API URL reachable from developers' browsers, not an internal hostname accessible only to the web server. Do not append `/api`. A proxy prefix is supported, e.g. `https://api.example.com/files-api`, if the proxy strips `/files-api` before forwarding. Configure short/no caching for `static/config.js` so URL changes are picked up after deployment.

## Backend configuration

From the backend directory, install dependencies:

```shell
python -m pip install -r requirements.txt
```

Set `ATLAS_CORS_ORIGINS` to the exact frontend origin (scheme, hostname, optional port; no path or trailing slash). Multiple origins may be comma-separated.

PowerShell example:

```powershell
$env:ATLAS_CORS_ORIGINS = 'https://web.example.com'
waitress-serve --host=127.0.0.1 --port=5055 --call app:create_app
```

Linux shell example:

```sh
export ATLAS_CORS_ORIGINS='https://web.example.com'
waitress-serve --host=127.0.0.1 --port=5055 --call app:create_app
```

These commands assume an HTTPS reverse proxy on the API server forwards requests to `127.0.0.1:5055`. Forward all `/api/` routes and OPTIONS requests, preserve the Origin header, and allow uploads up to the app's 32 MB request limit. Let Flask supply the CORS headers instead of adding duplicate headers in the proxy. The API root returns service information when the sibling frontend folder is absent.

If exposing the service directly on a private network instead, use `--host=0.0.0.0` and restrict access with the server firewall. Use HTTPS for both browser-facing servers; an HTTPS frontend cannot call an HTTP API. Clipboard features also benefit from HTTPS.

Optional: set `ATLAS_DATA_DIR` to an absolute storage directory on the API server. Otherwise the backend uses its own `workspace/` directory. Keep SQLite on the API server's local disk.

The app has no user authentication. CORS is browser access policy, not authentication; restrict this internal tool to your trusted network or put authentication/access control in front of the API before exposing it publicly.

Official production-server reference: https://flask.palletsprojects.com/en/stable/deploying/waitress/

## Local development

Keep frontend and backend as siblings. Leave `apiBaseUrl` empty, run `python app.py` from `backend/`, and open http://127.0.0.1:5055/. Flask serves the sibling frontend automatically. `ATLAS_HOST` and `ATLAS_PORT` configure this development launcher only.

To try separate local servers, set apiBaseUrl to `http://127.0.0.1:5055`, set ATLAS_CORS_ORIGINS to `http://127.0.0.1:8080`, and serve frontend via `python -m http.server 8080 --bind 127.0.0.1` from that directory. Restart the backend after changing its environment.

## Verify after deployment

Open the frontend, inspect a category and its photos, open a source file with the eye button, download a file, and export JSON. Then verify a comment save and photo upload. Import JSON is metadata-only and requires the referenced files to exist on the API server. Your personal review flags stay in local browser storage and do not automatically follow a changed frontend address.

Run backend tests with `python -m unittest -v test_app.py` from `backend/`.
