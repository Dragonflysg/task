@echo off
cd /d %~dp0
where python >nul 2>nul
if errorlevel 1 (
  echo Python not found in PATH. Please install Python 3.9+ and try again.
  pause
  exit /b 1
)
python -c "import flask" >nul 2>nul
if errorlevel 1 (
  echo Installing Flask...
  python -m pip install -r requirements.txt
)
python server.py
pause
