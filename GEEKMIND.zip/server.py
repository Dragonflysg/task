"""
Geekmind local server.
Serves index.html/style.css/app.js and a small JSON API backed by the
PROJECTS/ folder on disk. One subfolder per mindmap, holding its JSON
and any attached images.
"""

import json
import os
import re
import shutil
import uuid
from pathlib import Path

from flask import Flask, request, send_from_directory, jsonify, abort

APP_DIR = Path(__file__).parent.resolve()
PROJECTS_DIR = (APP_DIR / "PROJECTS").resolve()
PROJECTS_DIR.mkdir(exist_ok=True)

ALLOWED_IMG_EXT = {".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp", ".svg"}
NAME_RE = re.compile(r"^[\w\-\s]([\w\-\s]{0,62}[\w\-\s])?$")

app = Flask(__name__, static_folder=None)


# ---------- helpers ----------

def _valid_name(name: str) -> bool:
    if not name or len(name) > 64:
        return False
    if ".." in name or name.startswith(".") or name.endswith("."):
        return False
    return bool(NAME_RE.match(name))


def _project_dir(name: str) -> Path:
    if not _valid_name(name):
        abort(400, "Invalid project name")
    p = (PROJECTS_DIR / name).resolve()
    if p.parent != PROJECTS_DIR:
        abort(400, "Invalid path")
    return p


def _safe_file(project: Path, filename: str) -> Path:
    if "/" in filename or "\\" in filename or ".." in filename:
        abort(400)
    fp = (project / filename).resolve()
    if fp.parent != project:
        abort(400)
    return fp


def _folder_size(d: Path) -> int:
    return sum(f.stat().st_size for f in d.rglob("*") if f.is_file())


# ---------- static ----------

@app.route("/")
def index():
    return send_from_directory(APP_DIR, "index.html")


@app.route("/<path:fname>")
def static_files(fname):
    if fname in ("app.js", "style.css", "favicon.ico"):
        return send_from_directory(APP_DIR, fname)
    abort(404)


# ---------- project CRUD ----------

@app.get("/api/projects")
def list_projects():
    out = []
    for d in PROJECTS_DIR.iterdir():
        if not d.is_dir():
            continue
        json_file = d / "mindmap.json"
        meta = {
            "name": d.name,
            "modified": 0,
            "nodeCount": 0,
            "favorite": False,
        }
        if json_file.exists():
            st = json_file.stat()
            meta["modified"] = st.st_mtime
            try:
                data = json.loads(json_file.read_text(encoding="utf-8"))
                meta["nodeCount"] = len(data.get("nodes", []))
                meta["favorite"] = bool(data.get("favorite", False))
            except Exception:
                pass
        out.append(meta)
    out.sort(key=lambda x: (not x["favorite"], -x["modified"]))
    return jsonify(out)


@app.post("/api/projects")
def create_project():
    data = request.get_json(silent=True) or {}
    name = (data.get("name") or "").strip()
    if not _valid_name(name):
        return jsonify({"error": "Name must be 1-64 chars: letters, digits, spaces, dashes, underscores."}), 400
    p = PROJECTS_DIR / name
    if p.exists():
        return jsonify({"error": f"A project named '{name}' already exists."}), 409
    p.mkdir(parents=True)
    empty = {"nodes": [], "bgColor": "#dcd4f5", "viewport": {"k": 1, "x": 0, "y": 0}}
    (p / "mindmap.json").write_text(json.dumps(empty, indent=2), encoding="utf-8")
    return jsonify({"name": name}), 201


@app.get("/api/projects/<name>")
def load_project(name):
    p = _project_dir(name)
    f = p / "mindmap.json"
    if not f.exists():
        abort(404)
    return send_from_directory(p, "mindmap.json", mimetype="application/json")


@app.put("/api/projects/<name>")
def save_project(name):
    p = _project_dir(name)
    if not p.exists():
        abort(404)
    data = request.get_json(silent=True)
    if data is None:
        abort(400)
    (p / "mindmap.json").write_text(json.dumps(data, indent=2), encoding="utf-8")
    return "", 204


@app.post("/api/projects/<name>/favorite")
def set_favorite(name):
    p = _project_dir(name)
    if not p.exists():
        abort(404)
    body = request.get_json(silent=True) or {}
    fav = bool(body.get("favorite"))
    json_file = p / "mindmap.json"
    try:
        content = json.loads(json_file.read_text(encoding="utf-8"))
    except Exception:
        content = {"nodes": [], "bgColor": "#dcd4f5"}
    content["favorite"] = fav
    json_file.write_text(json.dumps(content, indent=2), encoding="utf-8")
    return jsonify({"favorite": fav})


@app.delete("/api/projects/<name>")
def delete_project(name):
    p = _project_dir(name)
    if not p.exists():
        abort(404)
    shutil.rmtree(p)
    return "", 204


# ---------- images ----------

@app.post("/api/projects/<name>/images")
def upload_image(name):
    p = _project_dir(name)
    if not p.exists():
        abort(404)
    if "file" not in request.files:
        abort(400)
    f = request.files["file"]
    ext = Path(f.filename or "").suffix.lower()
    if ext not in ALLOWED_IMG_EXT:
        ext = ".png"
    out_name = f"img_{uuid.uuid4().hex[:10]}{ext}"
    f.save(str(p / out_name))
    return jsonify({"filename": out_name})


@app.get("/api/projects/<name>/images/<fname>")
def get_image(name, fname):
    p = _project_dir(name)
    _safe_file(p, fname)
    return send_from_directory(p, fname)


# ---------- launch ----------

if __name__ == "__main__":
    host = os.environ.get("GEEKMIND_HOST", "0.0.0.0")
    port = int(os.environ.get("GEEKMIND_PORT", "5000"))
    print(f"\n  Geekmind listening on {host}:{port}")
    print(f"  Projects folder: {PROJECTS_DIR}\n")
    app.run(host=host, port=port, debug=False)
