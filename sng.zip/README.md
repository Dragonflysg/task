# Server Console

A Windows browser terminal for PM2, Python and Node commands. No SSH service or TCP port 22 is required. Python runs the console locally using pywinpty; Flask-Sock carries terminal input/output over a WebSocket. Browser assets are downloaded once during setup and served locally afterward.

## Quick start on the application server

Requires Windows with a compatible pywinpty wheel (modern Windows Server recommended), Python 3.11 or newer, and internet/package repository access during setup. Older Windows Server versions need compatibility validation. Node/PM2 must already be installed for the Windows account running this project.

1. Put this folder at `C:\PROJECTS\SSH` on the application server.
2. Open PowerShell under the account that owns your PM2 processes.
3. Run `cd C:\PROJECTS\SSH`, then `powershell -NoProfile -ExecutionPolicy Bypass -File .\setup.ps1`. This changes execution policy for that process only.
4. Choose your terminal login and password when prompted.
5. Start with `.\.venv\Scripts\python.exe app.py`.
6. Open `http://127.0.0.1:8765` on that machine and sign in.

If Python is not registered with the `py` launcher, run your Python executable with `-m venv .venv` and then the remaining setup steps manually. Setup never opens a firewall or changes Windows services.

## Access from your own PC

The default is a local pilot using Werkzeug's development server, with debugging disabled. It is not a production-hardened hosting deployment. Validate it locally first; production deployment needs a supported WebSocket-capable hosting arrangement and your organization's access controls. Do not use Waitress as a drop-in WebSocket host.

Use an internal HTTPS reverse proxy, preferably on the same server, with a dedicated hostname that forwards `/` to `http://127.0.0.1:8765`. Enable WebSocket upgrades, forward cookies, and set proxy timeouts above 30 seconds. Set `.env` `PUBLIC_ORIGIN=https://your-console-hostname` and `COOKIE_SECURE=true`. Restart the backend. The hostname must match exactly, including a nonstandard port if used. Hosting at a URL subpath is not supported by this version.

If the proxy is on another host, bind `HOST` to a private server address and restrict access to that listener to the proxy. Existing access to other Flask applications does not automatically expose this new listener. Use an approved encrypted path between hosts. Port 22 is never used.

The login grants a real shell with the backend's Windows permissions. Use a dedicated permitted operator account, protect `.env` with Windows file permissions, and avoid running the backend as Administrator. This version has one configured login, a global five-attempts-per-minute login limit, eight-hour sessions, a three-terminal cap, origin validation, and CSRF protection. It is designed for a single operator; multi-user roles, SSO/MFA and durable audit storage are not implemented.

## Terminal behavior

- Each tab opens a new console. Refresh/disconnect closes that console; there is no session reconnection or output replay.
- 30 minutes without keyboard input closes a terminal, including a logs-only session. Signing out revokes terminals belonging to that login session.
- Closing a terminal may stop foreground jobs. Use PM2 for applications that must survive disconnection. Do not depend on `python myapp.py` continuing after you close the page.
- PM2 shortcuts insert text at the current cursor; they do not execute it. Use them at a clean shell prompt, then press Enter.
- Ctrl+C interrupts the foreground command. Resize and ANSI output are supported.
- `TERMINAL_SHELL` is an executable name/path without arguments. Default: `cmd.exe`; `powershell.exe` is another option.
- `TERMINAL_CWD` sets the initial folder. Match `PM2_HOME`, PATH, and the Windows account to your existing PM2 setup. An empty `pm2 ls` often indicates a different account or PM2 home.
- Console open/close events and errors go to backend logs; command content is not recorded. Run only one backend process because login sessions are stored in memory. Restarting it signs everyone out.

## Verification

Run `.\.venv\Scripts\python.exe -m unittest discover -s tests -v` for login, CSRF, session revocation and WebSocket authorization checks. Then open a real terminal and verify `whoami`, `echo hello`, resizing, Ctrl+C, `pm2 ls`, and disconnect behavior on your target server. Do not restart a production application just to test.

## Troubleshooting

- Setup download fails: configure your approved package proxy or download the pinned browser assets and Python wheels on an approved connected machine.
- WebSocket disconnects immediately: verify login, exact `PUBLIC_ORIGIN`, proxy upgrade support, and backend error logs.
- Login will not stick: use HTTPS when `COOKIE_SECURE=true`; use the same hostname consistently.
- pywinpty fails: confirm Python/Windows compatibility and test the console interactively on that server.

References: https://flask-sock.readthedocs.io/ · https://github.com/andfoy/pywinpty · https://xtermjs.org/
