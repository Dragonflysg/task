import json
import os
import threading
import time
import unittest
from werkzeug.serving import make_server
from simple_websocket import Client
import app as module

@unittest.skipUnless(os.name == 'nt', 'Windows console integration')
class ConsoleIntegration(unittest.TestCase):
    def test_real_console_output_resize_and_logout(self):
        module.app.secret_key = 'integration-test-only-key-123456789'
        module.app.config['SESSION_COOKIE_SECURE'] = False
        client = module.app.test_client()
        with client.session_transaction() as session:
            session['token'] = 'integration-token'
            session['csrf'] = 'integration-csrf'
        module.logins['integration-token'] = time.monotonic()+60
        cookie = client.get_cookie('session').value
        server = make_server('127.0.0.1', 0, module.app, threaded=True)
        thread = threading.Thread(target=server.serve_forever,daemon=True)
        thread.start()
        old_origin = module.origin
        module.origin = f'http://127.0.0.1:{server.server_port}'
        ws = None
        try:
            ws = Client.connect(f'ws://127.0.0.1:{server.server_port}/terminal', headers={'Origin':module.origin,'Cookie':f'session={cookie}'})
            ws.send(json.dumps({'type':'resize','rows':30,'cols':100}))
            ws.send(json.dumps({'type':'input','data':'echo console-test-42\r'}))
            output = ''
            deadline = time.monotonic()+15
            while 'console-test-42' not in output and time.monotonic() < deadline:
                message=ws.receive(timeout=1)
                if message:
                    output += json.loads(message)['data']
            self.assertIn('console-test-42',output)
            client.post('/logout', data={'csrf':'integration-csrf'})
            deadline=time.monotonic()+5
            while ws.connected and time.monotonic()<deadline:
                try:
                    ws.receive(timeout=1)
                except Exception:
                    break
            self.assertFalse(ws.connected,'Logout should close existing console')
        finally:
            if ws and ws.connected:
                ws.close()
            server.shutdown()
            module.origin=old_origin
