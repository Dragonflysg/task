import os
import unittest
from unittest.mock import patch
from werkzeug.security import generate_password_hash

os.environ['SECRET_KEY'] = 'test-only-key-' * 4
os.environ['TERMINAL_PASSWORD_HASH'] = generate_password_hash('test-password-only')
os.environ['TERMINAL_USERNAME'] = 'operator'
import app as module

class SecurityTests(unittest.TestCase):
    def setUp(self):
        module.app.config['TESTING'] = True
        module.app.config['SESSION_COOKIE_SECURE'] = False
        module.logins.clear()
        module.failures.clear()
        self.client = module.app.test_client()

    def login(self):
        self.client.get('/login')
        with self.client.session_transaction() as session:
            token = session['csrf']
        return self.client.post('/login', data={'csrf': token, 'username':'operator', 'password':'test-password-only'})

    def test_terminal_page_requires_login(self):
        self.assertEqual(self.client.get('/').status_code, 302)

    def test_login_requires_csrf(self):
        self.assertEqual(self.client.post('/login', data={'username':'operator','password':'test-password-only'}).status_code,403)

    def test_login_and_logout_revoke_session(self):
        self.assertEqual(self.login().status_code,302)
        self.assertEqual(self.client.get('/').status_code,200)
        with self.client.session_transaction() as session:
            token, csrf = session['token'], session['csrf']
        self.client.post('/logout', data={'csrf':csrf})
        self.assertNotIn(token,module.logins)
        self.assertEqual(self.client.get('/').status_code,302)

    def test_expired_login_denied(self):
        self.login()
        with self.client.session_transaction() as session:
            module.logins[session['token']] = 0
        self.assertEqual(self.client.get('/').status_code,302)

    def test_global_login_throttle(self):
        self.client.get('/login')
        with self.client.session_transaction() as session:
            csrf=session['csrf']
        for _ in range(5):
            self.client.post('/login',data={'csrf':csrf,'username':'operator','password':'bad'})
        self.assertEqual(self.client.post('/login',data={'csrf':csrf}).status_code,429)

    def test_websocket_requires_origin_and_login_before_spawn(self):
        from unittest.mock import Mock
        for origin, authenticated in [('https://evil.example',True),(module.origin,False)]:
            ws=Mock()
            with module.app.test_request_context('/terminal',headers={'Origin':origin}):
                with patch.object(module,'authorized',return_value=authenticated), patch('winpty.PtyProcess.spawn') as spawn:
                    module.app.view_functions['terminal'].__wrapped__(ws)
                    spawn.assert_not_called()
                    ws.close.assert_called_once()

if __name__ == '__main__':
    unittest.main()
