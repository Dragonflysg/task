$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
py -3 -m venv .venv
if ($LASTEXITCODE -ne 0) { throw 'Install Python 3.11 or newer for Windows, then run setup again.' }
& .\.venv\Scripts\python.exe -m pip install -r requirements.txt
if ($LASTEXITCODE -ne 0) { throw 'Python dependency installation failed.' }
New-Item -ItemType Directory -Path static\vendor -Force | Out-Null
$assets = @{
    'xterm.js' = 'https://cdn.jsdelivr.net/npm/@xterm/xterm@5.5.0/lib/xterm.js'
    'xterm.css' = 'https://cdn.jsdelivr.net/npm/@xterm/xterm@5.5.0/css/xterm.css'
    'xterm-LICENSE.txt' = 'https://cdn.jsdelivr.net/npm/@xterm/xterm@5.5.0/LICENSE'
    'addon-fit.js' = 'https://cdn.jsdelivr.net/npm/@xterm/addon-fit@0.10.0/lib/addon-fit.js'
    'addon-fit-LICENSE.txt' = 'https://cdn.jsdelivr.net/npm/@xterm/addon-fit@0.10.0/LICENSE'
}
foreach ($asset in $assets.GetEnumerator()) {
    Invoke-WebRequest -Uri $asset.Value -OutFile (Join-Path 'static\vendor' $asset.Key)
}
if (!(Test-Path -LiteralPath '.env')) { & .\.venv\Scripts\python.exe configure.py }
if ($LASTEXITCODE -ne 0) { throw 'Configuration failed.' }
Write-Host 'Ready. Run: .\.venv\Scripts\python.exe app.py'
