"""Single-operator Windows browser terminal. Run one server process."""
import hmac
import json
import logging
import os
import secrets
import threading
import time
from pathlib import Path
from flask import Flask, abort, redirect, render_template, request, session, url_for
from flask_sock import Sock
from dotenv import load_dotenv
from werkzeug.security import check_password_hash

ROOT = Path(__file__).resolve().parent
load_dotenv(ROOT / '.env')
app = Flask(__name__)
app.config.update(SECRET_KEY=os.environ.get('SECRET_KEY'),
    SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE='Strict',
    SESSION_COOKIE_SECURE=os.getenv('COOKIE_SECURE', 'false').lower() == 'true',
    MAX_CONTENT_LENGTH=8192,
    SOCK_SERVER_OPTIONS={'ping_interval': 25, 'max_message_size': 16384})
sock = Sock(app)
origin = os.getenv('PUBLIC_ORIGIN', 'http://127.0.0.1:8765').rstrip('/')
logins = {}
failures = []
lock = threading.Lock()
slots = threading.BoundedSemaphore(3)

def authorized():
    with lock:
        now = time.monotonic()
        for token in list(logins):
            if logins[token] <= now:
                del logins[token]
        return session.get('token') in logins

def csrf():
    if not hmac.compare_digest(session.get('csrf', ''), request.form.get('csrf', '')) or not session.get('csrf'):
        abort(403)

@app.after_request
def headers(response):
    response.headers['Cache-Control'] = 'no-store'
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['X-Frame-Options'] = 'DENY'
    response.headers['Content-Security-Policy'] = "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'"
    return response

@app.route('/login', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        csrf()
        with lock:
            now = time.monotonic()
            failures[:] = [t for t in failures if now-t < 60]
            if len(failures) >= 5:
                return render_template('login.html', error='Too many attempts. Wait one minute.'), 429
            failures.append(now)
        valid_password = check_password_hash(os.environ['TERMINAL_PASSWORD_HASH'], request.form.get('password', ''))
        if valid_password and hmac.compare_digest(request.form.get('username', ''), os.getenv('TERMINAL_USERNAME', 'operator')):
            session.clear()
            session['token'] = secrets.token_urlsafe(32)
            session['csrf'] = secrets.token_urlsafe(32)
            with lock:
                logins[session['token']] = time.monotonic() + 8*3600
            app.logger.info('Operator logged in')
            return redirect(url_for('index'))
        error = 'Incorrect login name or password.'
    session.setdefault('csrf', secrets.token_urlsafe(32))
    return render_template('login.html', error=error)

@app.post('/logout')
def logout():
    csrf()
    with lock:
        logins.pop(session.get('token'), None)
    session.clear()
    return redirect(url_for('login'))

@app.get('/')
def index():
    if not authorized():
        return redirect(url_for('login'))
    return render_template('terminal.html', cwd=os.getenv('TERMINAL_CWD', str(ROOT)))

@sock.route('/terminal')
def terminal(ws):
    # Validate browser origin AND session before starting any process.
    if request.headers.get('Origin') != origin or not authorized():
        ws.close(reason='Unauthorized')
        return
    if not slots.acquire(blocking=False):
        ws.close(reason='Three terminals are already open')
        return
    proc = None
    stop = threading.Event()
    try:
        from winpty import PtyProcess
        proc = PtyProcess.spawn([os.getenv('TERMINAL_SHELL', 'cmd.exe')],
            cwd=os.getenv('TERMINAL_CWD', str(ROOT)), env=dict(os.environ))
        app.logger.info('Terminal opened, pid=%s', proc.pid)
        def output():
            try:
                while not stop.is_set():
                    data = proc.read(4096)
                    if data:
                        ws.send(json.dumps({'type': 'output', 'data': data}))
            except Exception:
                stop.set()
        threading.Thread(target=output, daemon=True).start()
        last_input = time.monotonic()
        while not stop.is_set() and authorized():
            if time.monotonic()-last_input > 1800:
                break
            raw = ws.receive(timeout=1)
            if raw is None:
                continue
            msg = json.loads(raw)
            if not isinstance(msg, dict):
                break
            if msg.get('type') == 'input' and isinstance(msg.get('data'), str):
                proc.write(msg['data'][:8192])
                last_input = time.monotonic()
            elif msg.get('type') == 'resize':
                rows, cols = msg.get('rows'), msg.get('cols')
                if type(rows) is int and type(cols) is int and 2 <= rows <= 300 and 2 <= cols <= 500:
                    proc.setwinsize(rows, cols)
    except Exception:
        app.logger.exception('Terminal connection ended or failed')
    finally:
        stop.set()
        if proc is not None:
            try:
                proc.close(force=True)
            except Exception:
                app.logger.exception('Console cleanup failed')
        slots.release()
        ws.close()
        app.logger.info('Terminal closed')

if __name__ == '__main__':
    if not app.secret_key or len(app.secret_key) < 32 or not os.getenv('TERMINAL_PASSWORD_HASH'):
        raise SystemExit('Run configure.py first to create your login and secret key.')
    if not (ROOT / 'static/vendor/xterm.js').exists():
        raise SystemExit('Run setup.ps1 first to install browser assets.')
    logging.basicConfig(level=logging.INFO)
    app.run(host=os.getenv('HOST', '127.0.0.1'), port=int(os.getenv('PORT', '8765')),
        debug=False, use_reloader=False, threaded=True)
