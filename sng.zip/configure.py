"""Create a local configuration without writing a plaintext password."""
import getpass
import secrets
from pathlib import Path
from werkzeug.security import generate_password_hash

root = Path(__file__).resolve().parent
target = root / '.env'
if target.exists():
    raise SystemExit('.env already exists. Edit it manually; no changes made.')
username = input('Login name [operator]: ').strip() or 'operator'
if not username.isalnum():
    raise SystemExit('Use letters and numbers for the login name.')
password = getpass.getpass('New terminal password (at least 14 characters): ')
if len(password) < 14:
    raise SystemExit('Please use at least 14 characters.')
if password != getpass.getpass('Repeat password: '):
    raise SystemExit('Passwords did not match.')
config = (root / '.env.example').read_text()
config = config.replace('TERMINAL_USERNAME=operator', f'TERMINAL_USERNAME={username}')
config = config.replace('TERMINAL_PASSWORD_HASH=', 'TERMINAL_PASSWORD_HASH=' + generate_password_hash(password))
config = config.replace('SECRET_KEY=', 'SECRET_KEY=' + secrets.token_hex(32))
config = config.replace('C:\\PROJECTS\\SSH', str(root))
target.write_text(config, encoding='utf-8')
print('Configuration saved. Start with: .\\.venv\\Scripts\\python.exe app.py')
