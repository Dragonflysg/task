'use strict';
const term = new Terminal({cursorBlink:true, fontSize:15, fontFamily:'Consolas, monospace', scrollback:5000, theme:{background:'#101722',foreground:'#e5edf7'}});
const fit = new FitAddon.FitAddon();
term.loadAddon(fit);
term.open(document.getElementById('terminal'));
let socket;
const status = document.getElementById('status');
const reconnect = document.getElementById('reconnect');
function send(data) { if (socket && socket.readyState === WebSocket.OPEN) socket.send(JSON.stringify(data)); }
function resize() { fit.fit(); send({type:'resize',rows:term.rows,cols:term.cols}); }
function connect() {
  reconnect.disabled = true;
  status.textContent = 'Connecting…';
  socket = new WebSocket(`${location.protocol === 'https:' ? 'wss:' : 'ws:'}//${location.host}/terminal`);
  socket.onopen = () => { status.textContent = '● Connected'; resize(); term.focus(); };
  socket.onmessage = event => { const message = JSON.parse(event.data); if(message.type === 'output') term.write(message.data); };
  socket.onclose = () => { status.textContent = 'Disconnected · sign in again if your session expired'; reconnect.disabled=false; };
  socket.onerror = () => { status.textContent = 'Connection failed'; };
}
term.onData(data => send({type:'input',data}));
new ResizeObserver(resize).observe(document.getElementById('terminal'));
reconnect.onclick = () => { term.reset(); connect(); };
document.getElementById('interrupt').onclick = () => { send({type:'input',data:'\x03'}); term.focus(); };
document.querySelectorAll('[data-command]').forEach(button => button.onclick = () => {send({type:'input',data:button.dataset.command}); term.focus();});
connect();
