"""
Generate realistic dummy compliance data for ~10 countries over 2 years.
Outputs to ../data/dummy_data.json
"""
import json
import random
import math
from datetime import datetime, timedelta
import calendar
import os

def patch_tuesday(year, month):
    """Return the date of Patch Tuesday (2nd Tuesday) for a given month."""
    cal = calendar.monthcalendar(year, month)
    tuesdays = [week[1] for week in cal if week[1] != 0]
    return datetime(year, month, tuesdays[1])

COUNTRIES = [
    {"code": "AUS", "name": "Australia", "region": "AP", "base_ws": 100, "profile": "good"},
    {"code": "USA", "name": "United States", "region": "AMERICA", "base_ws": 2500, "profile": "average"},
    {"code": "GBR", "name": "United Kingdom", "region": "EMEA", "base_ws": 800, "profile": "good"},
    {"code": "DEU", "name": "Germany", "region": "EMEA", "base_ws": 600, "profile": "average"},
    {"code": "JPN", "name": "Japan", "region": "AP", "base_ws": 450, "profile": "excellent"},
    {"code": "IND", "name": "India", "region": "AP", "base_ws": 1200, "profile": "struggling"},
    {"code": "SGP", "name": "Singapore", "region": "AP", "base_ws": 200, "profile": "excellent"},
    {"code": "BRA", "name": "Brazil", "region": "AMERICA", "base_ws": 350, "profile": "struggling"},
    {"code": "CAN", "name": "Canada", "region": "AMERICA", "base_ws": 500, "profile": "average"},
    {"code": "FRA", "name": "France", "region": "EMEA", "base_ws": 700, "profile": "good"},
    {"code": "NLD", "name": "Netherlands", "region": "EMEA", "base_ws": 150, "profile": "excellent"},
    {"code": "MEX", "name": "Mexico", "region": "AMERICA", "base_ws": 180, "profile": "struggling"},
    {"code": "ARE", "name": "UAE", "region": "EMEA", "base_ws": 120, "profile": "average"},
    {"code": "PHL", "name": "Philippines", "region": "AP", "base_ws": 300, "profile": "struggling"},
    {"code": "KOR", "name": "South Korea", "region": "AP", "base_ws": 280, "profile": "good"},
    {"code": "ITA", "name": "Italy", "region": "EMEA", "base_ws": 220, "profile": "average"},
    {"code": "ESP", "name": "Spain", "region": "EMEA", "base_ws": 190, "profile": "average"},
    {"code": "SWE", "name": "Sweden", "region": "EMEA", "base_ws": 130, "profile": "excellent"},
    {"code": "POL", "name": "Poland", "region": "EMEA", "base_ws": 250, "profile": "average"},
    {"code": "THA", "name": "Thailand", "region": "AP", "base_ws": 160, "profile": "struggling"},
    {"code": "ZAF", "name": "South Africa", "region": "EMEA", "base_ws": 140, "profile": "struggling"},
    {"code": "NZL", "name": "New Zealand", "region": "AP", "base_ws": 80, "profile": "good"},
    {"code": "IRL", "name": "Ireland", "region": "EMEA", "base_ws": 110, "profile": "good"},
    {"code": "CHE", "name": "Switzerland", "region": "EMEA", "base_ws": 170, "profile": "excellent"},
    {"code": "AUT", "name": "Austria", "region": "EMEA", "base_ws": 90, "profile": "average"},
    {"code": "CHL", "name": "Chile", "region": "AMERICA", "base_ws": 100, "profile": "average"},
    {"code": "COL", "name": "Colombia", "region": "AMERICA", "base_ws": 120, "profile": "struggling"},
    {"code": "MYS", "name": "Malaysia", "region": "AP", "base_ws": 200, "profile": "average"},
    {"code": "IDN", "name": "Indonesia", "region": "AP", "base_ws": 230, "profile": "struggling"},
    {"code": "HKG", "name": "Hong Kong", "region": "AP", "base_ws": 150, "profile": "good"},
    {"code": "TWN", "name": "Taiwan", "region": "AP", "base_ws": 180, "profile": "good"},
    {"code": "ARG", "name": "Argentina", "region": "AMERICA", "base_ws": 95, "profile": "struggling"},
]

# Profile determines base compliance rates for each platform
PROFILES = {
    "excellent": {
        "mecm": (0.995, 0.005),
        "sentinelone": (0.995, 0.005),
        "inventory": (0.998, 0.003),
        "mspatches": (0.985, 0.010),
        "bitlocker": (0.993, 0.005),
        "winbuild": (0.990, 0.008),
    },
    "good": {
        "mecm": (0.990, 0.008),
        "sentinelone": (0.988, 0.010),
        "inventory": (0.995, 0.005),
        "mspatches": (0.975, 0.015),
        "bitlocker": (0.985, 0.008),
        "winbuild": (0.980, 0.012),
    },
    "average": {
        "mecm": (0.980, 0.012),
        "sentinelone": (0.978, 0.015),
        "inventory": (0.988, 0.008),
        "mspatches": (0.960, 0.020),
        "bitlocker": (0.975, 0.012),
        "winbuild": (0.970, 0.018),
    },
    "struggling": {
        "mecm": (0.965, 0.018),
        "sentinelone": (0.960, 0.022),
        "inventory": (0.975, 0.012),
        "mspatches": (0.940, 0.030),
        "bitlocker": (0.955, 0.018),
        "winbuild": (0.950, 0.025),
    },
}

PLATFORMS = ["mecm", "sentinelone", "inventory", "mspatches", "bitlocker", "winbuild"]


def generate_country_data(country, start_date, end_date):
    """Generate daily compliance data for a single country."""
    profile = PROFILES[country["profile"]]
    records = []
    current_date = start_date

    # Slight upward trend over time (improvement)
    total_days = (end_date - start_date).days

    # Fleet size grows slowly over time
    base_ws = country["base_ws"]

    # Pre-compute all patch tuesdays in range
    patch_tuesdays = []
    d = start_date
    while d <= end_date:
        try:
            pt = patch_tuesday(d.year, d.month)
            if pt not in patch_tuesdays and start_date <= pt <= end_date:
                patch_tuesdays.append(pt)
        except (IndexError, ValueError):
            pass
        # Move to next month
        if d.month == 12:
            d = datetime(d.year + 1, 1, 1)
        else:
            d = datetime(d.year, d.month + 1, 1)

    # Track state for smooth transitions
    platform_states = {}
    for p in PLATFORMS:
        base_rate, _ = profile[p]
        platform_states[p] = base_rate

    day_index = 0
    current_date = start_date

    while current_date <= end_date:
        # Fleet size: gradual growth with occasional jumps
        growth_factor = 1.0 + (day_index / total_days) * 0.15  # 15% growth over period
        if random.random() < 0.005:  # Occasional batch additions
            growth_factor += random.uniform(0.02, 0.05)
        enabled_ws = int(base_ws * growth_factor)

        # Improvement trend: slight improvement over 2 years
        improvement = (day_index / total_days) * 0.01  # up to 1% improvement

        # Check if we're in a post-patch-tuesday recovery period
        days_since_patch = None
        for pt in patch_tuesdays:
            delta = (current_date - pt).days
            if 0 <= delta <= 21:
                days_since_patch = delta
                break

        platform_values = {}
        for p in PLATFORMS:
            base_rate, volatility = profile[p]
            target_rate = min(base_rate + improvement, 0.999)

            # Daily noise
            noise = random.gauss(0, volatility * 0.3)

            # Patch Tuesday effect (mainly affects mspatches, slightly affects others)
            patch_effect = 0
            if days_since_patch is not None:
                if p == "mspatches":
                    # Sharp drop then gradual recovery
                    if days_since_patch == 0:
                        patch_effect = -random.uniform(0.03, 0.08)
                    elif days_since_patch <= 3:
                        patch_effect = -random.uniform(0.02, 0.06) * (1 - days_since_patch / 4)
                    elif days_since_patch <= 14:
                        patch_effect = -random.uniform(0.005, 0.02) * (1 - days_since_patch / 15)
                elif p == "winbuild":
                    # Sometimes Windows build updates coincide
                    if days_since_patch <= 5 and random.random() < 0.3:
                        patch_effect = -random.uniform(0.005, 0.015)
                elif p == "bitlocker":
                    # Rare: new patches sometimes toggle BitLocker issues
                    if days_since_patch <= 2 and random.random() < 0.1:
                        patch_effect = -random.uniform(0.005, 0.01)

            # Weekend effect: slightly less compliance on weekends (machines off)
            weekday = current_date.weekday()
            weekend_effect = -0.002 if weekday >= 5 else 0

            # Compute rate with smooth transition
            raw_rate = target_rate + noise + patch_effect + weekend_effect
            rate = max(0.85, min(0.999, raw_rate))

            # Smooth with previous state
            platform_states[p] = platform_states[p] * 0.3 + rate * 0.7

            compliant_count = min(round(platform_states[p] * enabled_ws), enabled_ws)
            # Ensure at least some baseline
            compliant_count = max(compliant_count, int(enabled_ws * 0.85))
            platform_values[p] = compliant_count

        # Compliance score: average of all platform ratios
        platform_ratios = [platform_values[p] / enabled_ws for p in PLATFORMS]
        compliance_score = sum(platform_ratios) / len(platform_ratios)

        # Non-compliant: workstations that fail at least one check
        # Approximate: use complement of minimum platform ratio
        min_ratio = min(platform_ratios)
        # A workstation could fail multiple checks, so non-compliant is roughly
        # based on union of failures. Simplified: max gap from enabled.
        max_gap = max(enabled_ws - platform_values[p] for p in PLATFORMS)
        # Add some extra for overlapping failures
        non_compliant = min(
            max_gap + random.randint(0, max(1, int(max_gap * 0.3))),
            enabled_ws
        )
        non_compliant = max(non_compliant, enabled_ws - min(platform_values.values()))

        record = {
            "date": current_date.strftime("%Y-%m-%d"),
            "country": country["code"],
            "country_name": country["name"],
            "enabled_ws": enabled_ws,
            "mecm": platform_values["mecm"],
            "sentinelone": platform_values["sentinelone"],
            "inventory": platform_values["inventory"],
            "mspatches": platform_values["mspatches"],
            "bitlocker": platform_values["bitlocker"],
            "winbuild": platform_values["winbuild"],
            "compliance_score": round(compliance_score, 8),
            "non_compliant": non_compliant,
        }
        records.append(record)

        current_date += timedelta(days=1)
        day_index += 1

    return records


def main():
    random.seed(42)  # Reproducible data

    start_date = datetime(2024, 3, 1)
    end_date = datetime(2026, 3, 17)

    all_data = {}
    countries_list = []

    for country in COUNTRIES:
        print(f"Generating data for {country['name']}...")
        records = generate_country_data(country, start_date, end_date)
        all_data[country["code"]] = records
        countries_list.append({
            "code": country["code"],
            "name": country["name"],
            "region": country["region"],
        })

    # Pre-compute patch tuesdays for the range
    patch_tuesdays = []
    d = start_date
    while d <= end_date:
        try:
            pt = patch_tuesday(d.year, d.month)
            if start_date <= pt <= end_date:
                pt_str = pt.strftime("%Y-%m-%d")
                if pt_str not in patch_tuesdays:
                    patch_tuesdays.append(pt_str)
        except (IndexError, ValueError):
            pass
        if d.month == 12:
            d = datetime(d.year + 1, 1, 1)
        else:
            d = datetime(d.year, d.month + 1, 1)

    output = {
        "countries": countries_list,
        "patch_tuesdays": patch_tuesdays,
        "data": all_data,
    }

    output_path = os.path.join(os.path.dirname(__file__), "..", "data", "dummy_data.json")
    with open(output_path, "w") as f:
        json.dump(output, f)

    total_records = sum(len(v) for v in all_data.values())
    print(f"\nGenerated {total_records} records for {len(COUNTRIES)} countries")
    print(f"Date range: {start_date.strftime('%Y-%m-%d')} to {end_date.strftime('%Y-%m-%d')}")
    print(f"Patch Tuesdays: {len(patch_tuesdays)}")
    print(f"Output: {os.path.abspath(output_path)}")


if __name__ == "__main__":
    main()
