/**
 * Main application controller for WCD Dashboard.
 * Handles user interactions, state management, and data loading.
 */
$(document).ready(function() {
    var API = WCD.API;
    var Charts = WCD.Charts;
    var U = WCD.Utils;

    // Default country and region for the technician
    var TECH_CO = 'SGP';
    var TECH_REGION = 'AP';

    // Application state
    var state = {
        countries: [],          // available countries
        selectedCountries: [],  // currently selected country codes
        dateFrom: '',
        dateTo: '',
        autoScale: true,
        showPatchTuesdays: true,
        trendData: null,        // cached trend data for current selection
    };

    // =============================================
    // INITIALIZATION
    // =============================================
    function init() {
        setupSectionToggles();
        setupControls();
        loadCountries();
    }

    function loadCountries() {
        API.getCountries().then(function(countries) {
            state.countries = countries;
            // Set default region
            $('#region-select').val(TECH_REGION);
            // Filter and populate countries for that region
            filterCountriesByRegion(TECH_REGION);
            // Default to technician's country
            var defaultCode = countries.find(function(c) { return c.code === TECH_CO; }) ? TECH_CO : null;
            if (defaultCode) {
                $('#country-select').val([defaultCode]).trigger('change');
            }
        }).fail(function() {
            showError('Failed to load countries. Is the Flask server running on port 5000?');
        });
    }

    function filterCountriesByRegion(region) {
        var filtered = state.countries.filter(function(c) { return c.region === region; });
        populateCountrySelector(filtered);
    }

    function populateCountrySelector(countries) {
        var $select = $('#country-select');
        // Destroy existing select2 if initialized
        if ($select.hasClass('select2-hidden-accessible')) {
            $select.select2('destroy');
        }
        $select.empty();
        countries.sort(function(a, b) { return a.name.localeCompare(b.name); });
        countries.forEach(function(c) {
            $select.append(new Option(c.name, c.code));
        });

        $select.select2({
            placeholder: 'Select countries...',
            allowClear: true,
            width: '300px',
        });
    }

    // =============================================
    // CONTROLS & EVENT HANDLERS
    // =============================================
    function setupControls() {
        // Region selector
        $('#region-select').on('change', function() {
            var region = $(this).val();
            filterCountriesByRegion(region);
            // Auto-select first country in the filtered list
            var $countrySelect = $('#country-select');
            var firstCode = $countrySelect.find('option:first').val();
            if (firstCode) {
                $countrySelect.val([firstCode]).trigger('change');
            }
        });

        // Country selector
        $('#country-select').on('change', function() {
            state.selectedCountries = $(this).val() || [];
            if (state.selectedCountries.length > 0) {
                refreshDashboard();
            }
        });

        // Date preset
        $('#date-preset').on('change', function() {
            var val = $(this).val();
            if (val === 'custom') {
                $('#date-range').show();
                initDatePicker();
            } else {
                $('#date-range').hide();
                var days = parseInt(val);
                state.dateTo = U.today();
                state.dateFrom = U.daysAgo(days);
                API.clearCache();
                refreshDashboard();
            }
        });

        // Auto-scale toggle
        $('#toggle-autoscale').on('change', function() {
            state.autoScale = $(this).is(':checked');
            refreshCharts();
        });

        // Patch Tuesday toggle
        $('#toggle-patch-tuesday').on('change', function() {
            state.showPatchTuesdays = $(this).is(':checked');
            refreshCharts();
        });

        // Initialize default date range
        var defaultDays = parseInt($('#date-preset').val());
        state.dateTo = U.today();
        state.dateFrom = U.daysAgo(defaultDays);
    }

    function initDatePicker() {
        flatpickr('#date-range', {
            mode: 'range',
            dateFormat: 'Y-m-d',
            defaultDate: [state.dateFrom, state.dateTo],
            theme: 'dark',
            onChange: function(selectedDates) {
                if (selectedDates.length === 2) {
                    state.dateFrom = selectedDates[0].toISOString().split('T')[0];
                    state.dateTo = selectedDates[1].toISOString().split('T')[0];
                    API.clearCache();
                    refreshDashboard();
                }
            },
        });
    }

    // =============================================
    // SECTION COLLAPSE/EXPAND
    // =============================================
    function setupSectionToggles() {
        $(document).on('click', '.section-header[data-toggle="section"]', function() {
            var $section = $(this).closest('.dashboard-section');
            var $content = $section.find('> .section-content');
            var $icon = $(this).find('.collapse-icon');

            if ($content.is(':visible')) {
                $content.slideUp(200);
                $section.addClass('collapsed');
                $icon.html('&#9654;'); // right arrow
            } else {
                $content.slideDown(200);
                $section.removeClass('collapsed');
                $icon.html('&#9660;'); // down arrow
                // Lazy-load section data
                lazyLoadSection($section.attr('id'));
            }
        });

        // Platform breakdown sub-toggle
        $(document).on('click', '.section-header[data-toggle="platforms"]', function() {
            var $content = $(this).next('.collapsible');
            var $icon = $(this).find('.collapse-icon');

            if ($content.is(':visible')) {
                $content.slideUp(200);
                $icon.html('&#9654;');
            } else {
                $content.slideDown(200);
                $icon.html('&#9660;');
            }
        });
    }

    // =============================================
    // DATA LOADING & RENDERING
    // =============================================
    function refreshDashboard() {
        if (state.selectedCountries.length === 0) return;
        var primary = state.selectedCountries[0];

        // Load summary for primary country + trend data
        $.when(
            API.getSummary(primary),
            API.getTrend(state.selectedCountries, state.dateFrom, state.dateTo)
        ).then(function(summaryData, trendData) {
            state.trendData = trendData;

            // Section 1: Summary
            var countryName = state.countries.find(function(c) { return c.code === primary; });
            $('#summary-title').text('Summary : ' + (countryName ? countryName.name : primary));
            Charts.renderKPICards(summaryData);

            // Sparklines need 30-day trend
            var sparkFrom = U.daysAgo(30);
            API.getTrend(primary, sparkFrom, state.dateTo).then(function(sparkData) {
                Charts.renderSparklines(sparkData, primary);
            });

            // Section 2: Trend Charts
            refreshCharts();

            // Load all other sections
            loadCountrySection();
            loadDrilldownSection();
            loadFleetSection();
        }).fail(function() {
            showError('Failed to load data. Check the Flask server.');
        });
    }

    function refreshCharts() {
        if (!state.trendData || state.selectedCountries.length === 0) return;

        var opts = {
            autoScale: state.autoScale,
            showPatchTuesdays: state.showPatchTuesdays,
        };

        Charts.renderHeroChart(state.trendData, state.selectedCountries, state.dateFrom, state.dateTo, opts);
        Charts.renderNonCompliantChart(state.trendData, state.selectedCountries, opts);

        // Platform breakdown for primary country
        Charts.renderPlatformBreakdown(state.trendData, state.selectedCountries[0], opts);
    }

    function lazyLoadSection(sectionId) {
        var primary = state.selectedCountries[0];
        if (!primary) return;

        switch (sectionId) {
            case 'section-countries':
                loadCountrySection();
                break;
            case 'section-drilldown':
                loadDrilldownSection();
                break;
            case 'section-fleet':
                loadFleetSection();
                break;
        }
    }

    function loadCountrySection() {
        // Heatmap
        API.getHeatmap(state.dateFrom, state.dateTo, 'monthly').then(function(data) {
            Charts.renderCountryHeatmap(data);
        });

        // Ranking
        API.getRanking().then(function(data) {
            Charts.renderCountryRanking(data, state.selectedCountries);
        });

        // Radar (needs trend data for selected countries)
        if (state.trendData) {
            Charts.renderCountryRadar(state.trendData, state.selectedCountries);
        }
    }

    function loadDrilldownSection() {
        var primary = state.selectedCountries[0];
        API.getChanges(primary, 0.3, state.dateFrom, state.dateTo).then(function(data) {
            Charts.renderChangesTable(data);
        });
    }

    function loadFleetSection() {
        if (state.trendData) {
            Charts.renderFleetTrend(state.trendData, state.selectedCountries[0]);
        }
    }

    // =============================================
    // ERROR HANDLING
    // =============================================
    function showError(message) {
        var $alert = $('<div class="loading" style="color: #ff1744;">' + message + '</div>');
        $('#kpi-cards').html($alert);
    }

    // =============================================
    // START
    // =============================================
    init();
});
