"""Pipeline orchestrator.

Runs each step script as its own subprocess in the order listed in config.json.
Stops the chain on the first failure (non-zero exit OR status_json != "ok").
A lockfile in state/.run.lock prevents overlapping runs.

Designed to be invoked by starter.py (PM2-managed) or manually:
    python runner.py
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
from datetime import datetime
from pathlib import Path

from lib.pipeline_log import setup_logger
from lib.status import read_status

ROOT = Path(__file__).resolve().parent
STATE_DIR = ROOT / "state"
LOCK = STATE_DIR / ".run.lock"
CONFIG_PATH = ROOT / "config.json"


def _is_pid_alive(pid: int) -> bool:
    """Cross-platform liveness check (best-effort)."""
    if pid <= 0:
        return False
    if os.name == "nt":
        try:
            out = subprocess.run(
                ["tasklist", "/FI", f"PID eq {pid}", "/NH", "/FO", "CSV"],
                capture_output=True, text=True, timeout=5,
            )
            return str(pid) in out.stdout
        except Exception:
            return True  # assume alive if we cannot check
    try:
        os.kill(pid, 0)
        return True
    except (OSError, ProcessLookupError):
        return False


def _check_and_acquire_lock(log) -> bool:
    """Return True if we acquired the lock, False if another run is active."""
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    if LOCK.exists():
        try:
            stale_pid = int(LOCK.read_text(encoding="utf-8").strip() or "0")
        except ValueError:
            stale_pid = 0
        if _is_pid_alive(stale_pid):
            log.warning(
                f"another run is active (pid={stale_pid}); skipping this trigger"
            )
            return False
        log.info(f"clearing stale lockfile (pid={stale_pid} not alive)")
        try:
            LOCK.unlink()
        except FileNotFoundError:
            pass
    LOCK.write_text(str(os.getpid()), encoding="utf-8")
    return True


def _release_lock() -> None:
    try:
        LOCK.unlink()
    except FileNotFoundError:
        pass


def main() -> int:
    run_id = datetime.now().strftime("%Y%m%d_%H%M%S")
    log = setup_logger(run_id, name="runner")

    log.info(f"=== pipeline run {run_id} starting (pid={os.getpid()}) ===")

    if not _check_and_acquire_lock(log):
        return 0

    try:
        if not CONFIG_PATH.exists():
            log.error(f"config not found: {CONFIG_PATH}")
            return 1
        config = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
        steps = config.get("steps") or []
        if not steps:
            log.error("no steps defined in config.json")
            return 1

        prev_count = 0

        for step_path in steps:
            step_file = ROOT / step_path
            step_name = step_file.stem

            if not step_file.exists():
                log.error(f"step script not found: {step_file}; aborting chain")
                return 1

            log.info(f"--- starting {step_name} ---")

            env = os.environ.copy()
            env["PIPELINE_RUN_ID"] = run_id
            env["PIPELINE_PREV_COUNT"] = str(prev_count)
            env["PYTHONPATH"] = str(ROOT) + os.pathsep + env.get("PYTHONPATH", "")

            result = subprocess.run(
                [sys.executable, "-u", str(step_file)],
                cwd=str(ROOT),
                env=env,
            )

            status = read_status(step_name)
            ok = (
                result.returncode == 0
                and status is not None
                and status.get("status") == "ok"
            )

            if not ok:
                log.error(
                    f"{step_name} FAILED "
                    f"(returncode={result.returncode}, status={status}); aborting chain"
                )
                return 1

            prev_count = int(status.get("items_processed") or 0)
            log.info(f"{step_name} OK — items_processed={prev_count}")

        log.info(f"=== pipeline run {run_id} finished successfully ===")
        return 0

    except Exception as exc:
        log.exception(f"runner crashed: {exc}")
        return 1
    finally:
        _release_lock()


if __name__ == "__main__":
    sys.exit(main())
