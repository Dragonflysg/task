"""Per-run logger: writes to logs/run_<run_id>.log AND echoes to stdout.

Step scripts can call setup_logger(os.environ['PIPELINE_RUN_ID']) to attach
their output to the same run file the runner is writing to.
"""
from __future__ import annotations

import logging
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
LOGS_DIR = PROJECT_ROOT / "logs"

_FORMAT = "%(asctime)s [%(levelname)s] %(name)s: %(message)s"


def setup_logger(run_id: str, name: str = "pipeline") -> logging.Logger:
    LOGS_DIR.mkdir(parents=True, exist_ok=True)
    log_path = LOGS_DIR / f"run_{run_id}.log"

    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)
    logger.propagate = False

    already_attached = {
        getattr(h, "_pipeline_target", None) for h in logger.handlers
    }

    if str(log_path) not in already_attached:
        fh = logging.FileHandler(log_path, encoding="utf-8")
        fh.setFormatter(logging.Formatter(_FORMAT))
        fh._pipeline_target = str(log_path)  # type: ignore[attr-defined]
        logger.addHandler(fh)

    if "stdout" not in already_attached:
        sh = logging.StreamHandler(sys.stdout)
        sh.setFormatter(logging.Formatter(_FORMAT))
        sh._pipeline_target = "stdout"  # type: ignore[attr-defined]
        logger.addHandler(sh)

    return logger
