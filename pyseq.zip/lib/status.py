"""JSON status helpers shared by runner and step scripts.

Each step writes one file: <state_dir>/<step_name>_result.json
The next step (and the runner) reads that file to decide whether to continue.
Writes are atomic (temp file + os.replace) so a half-written JSON cannot be
observed by a reader.
"""
from __future__ import annotations

import json
import os
import tempfile
from datetime import datetime
from pathlib import Path
from typing import Any

PROJECT_ROOT = Path(__file__).resolve().parents[1]
STATE_DIR = PROJECT_ROOT / "state"


def _state_path(step_name: str, state_dir: Path | None = None) -> Path:
    return (state_dir or STATE_DIR) / f"{step_name}_result.json"


def write_status(
    step_name: str,
    status: str,
    items_processed: int = 0,
    error: str | None = None,
    payload: dict[str, Any] | None = None,
    started_at: str | None = None,
    state_dir: Path | None = None,
) -> Path:
    if status not in ("ok", "error"):
        raise ValueError(f"status must be 'ok' or 'error', got {status!r}")

    target = _state_path(step_name, state_dir)
    target.parent.mkdir(parents=True, exist_ok=True)

    data = {
        "step": step_name,
        "status": status,
        "items_processed": items_processed,
        "started_at": started_at,
        "ended_at": datetime.now().isoformat(timespec="seconds"),
        "error": error,
        "payload": payload or {},
    }

    fd, tmp_path = tempfile.mkstemp(
        prefix=f".{step_name}_", suffix=".json.tmp", dir=str(target.parent)
    )
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
        os.replace(tmp_path, target)
    except Exception:
        if os.path.exists(tmp_path):
            os.unlink(tmp_path)
        raise

    return target


def read_status(step_name: str, state_dir: Path | None = None) -> dict[str, Any] | None:
    path = _state_path(step_name, state_dir)
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return None
