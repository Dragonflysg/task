"""PM2-managed entry point. Schedules runner.py via the `schedule` module.

Run manually:
    python starter.py
Run under PM2:
    pm2 start starter.py --name python-seq --interpreter python
    pm2 save

The starter never blocks on the pipeline — it spawns runner.py as a detached
subprocess so the schedule loop stays responsive even during long runs.
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path

import schedule

ROOT = Path(__file__).resolve().parent
RUNNER = ROOT / "runner.py"
CONFIG_PATH = ROOT / "config.json"


def _log(msg: str) -> None:
    print(f"{datetime.now().isoformat(timespec='seconds')} [starter] {msg}", flush=True)


def trigger() -> None:
    _log(f"trigger fired — spawning {RUNNER.name}")
    try:
        subprocess.Popen(
            [sys.executable, "-u", str(RUNNER)],
            cwd=str(ROOT),
        )
    except Exception as exc:
        _log(f"failed to spawn runner: {exc}")


def main() -> int:
    if not CONFIG_PATH.exists():
        _log(f"config.json not found at {CONFIG_PATH}")
        return 1

    config = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
    times = config.get("schedule", {}).get("daily_at") or []

    if not times:
        _log("no schedule.daily_at times configured; nothing to do")
        return 1

    for t in times:
        schedule.every().day.at(t).do(trigger)

    _log(f"scheduled daily at {times}; pid={os.getpid()}")
    _log("entering schedule loop (Ctrl-C to stop)")

    while True:
        schedule.run_pending()
        time.sleep(30)


if __name__ == "__main__":
    sys.exit(main() or 0)
