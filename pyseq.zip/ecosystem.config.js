module.exports = {
  apps: [
    {
      name: "python-seq",
      script: "starter.py",
      interpreter: "python",
      cwd: "C:/PROJECTS/PYTHON_SEQ",
      autorestart: true,
      max_restarts: 10,
      out_file: "C:/PROJECTS/PYTHON_SEQ/logs/pm2_out.log",
      error_file: "C:/PROJECTS/PYTHON_SEQ/logs/pm2_err.log",
      merge_logs: true,
      time: true
    }
  ]
};
