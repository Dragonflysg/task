"""Step 3 — load."""
from __future__ import annotations

import os
import sys
import time
import traceback
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from lib.pipeline_log import setup_logger
from lib.status import read_status, write_status

STEP_NAME = Path(__file__).stem
PREV_STEP = "step_02_transform"


def do_work(log, prev_count: int, prev_payload: dict) -> tuple[int, dict]:
    log.info(f"{STEP_NAME}: prev_count={prev_count} prev_payload={prev_payload}")
    items = 0
    for i in range(prev_count):
        time.sleep(0.2)
        items += 1
        log.info(f"{STEP_NAME}: loaded item {items}/{prev_count}")
    return items, {"loaded": True}


def main() -> int:
    run_id = os.environ.get("PIPELINE_RUN_ID") or datetime.now().strftime("%Y%m%d_%H%M%S")
    log = setup_logger(run_id, name=STEP_NAME)
    started_at = datetime.now().isoformat(timespec="seconds")

    log.info(f"=== {STEP_NAME} starting ===")

    try:
        prev = read_status(PREV_STEP) or {}
        prev_count = int(prev.get("items_processed") or 0)
        prev_payload = prev.get("payload") or {}

        items, payload = do_work(log, prev_count, prev_payload)
        write_status(
            STEP_NAME, "ok",
            items_processed=items,
            payload=payload,
            started_at=started_at,
        )
        log.info(f"=== {STEP_NAME} OK — {items} items ===")
        return 0
    except Exception as exc:
        tb = traceback.format_exc()
        log.error(f"{STEP_NAME} CRASHED: {exc}\n{tb}")
        write_status(
            STEP_NAME, "error",
            error=tb,
            started_at=started_at,
        )
        return 1


if __name__ == "__main__":
    sys.exit(main())
