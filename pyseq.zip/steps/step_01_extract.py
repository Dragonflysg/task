"""Step 1 — extract.

Replace the body of `do_work()` with your real logic. The wrapper around it
guarantees a status JSON is always written, so runner.py can decide whether
to continue or abort the chain.
"""
from __future__ import annotations

import os
import sys
import time
import traceback
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from lib.pipeline_log import setup_logger
from lib.status import read_status, write_status

STEP_NAME = Path(__file__).stem


def do_work(log, prev_count: int) -> tuple[int, dict]:
    """Replace this with the real extract logic.

    Must return: (items_processed, payload_dict_for_next_step)
    """
    log.info(f"{STEP_NAME}: previous count was {prev_count}")
    items = 0
    for i in range(3):
        time.sleep(0.2)
        items += 1
        log.info(f"{STEP_NAME}: extracted item {items}")
    return items, {"sample_key": "sample_value"}


def main() -> int:
    run_id = os.environ.get("PIPELINE_RUN_ID") or datetime.now().strftime("%Y%m%d_%H%M%S")
    prev_count = int(os.environ.get("PIPELINE_PREV_COUNT") or "0")
    log = setup_logger(run_id, name=STEP_NAME)
    started_at = datetime.now().isoformat(timespec="seconds")

    log.info(f"=== {STEP_NAME} starting ===")

    try:
        # Optional: inspect previous step's full status (None for the first step).
        _ = read_status("step_00_unused_placeholder")
        items, payload = do_work(log, prev_count)
        write_status(
            STEP_NAME, "ok",
            items_processed=items,
            payload=payload,
            started_at=started_at,
        )
        log.info(f"=== {STEP_NAME} OK — {items} items ===")
        return 0
    except Exception as exc:
        tb = traceback.format_exc()
        log.error(f"{STEP_NAME} CRASHED: {exc}\n{tb}")
        write_status(
            STEP_NAME, "error",
            error=tb,
            started_at=started_at,
        )
        return 1


if __name__ == "__main__":
    sys.exit(main())
