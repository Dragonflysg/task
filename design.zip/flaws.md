# Flaws / Ambiguities — IES Subtasks (design.aspx)

Observations from `SUB1.jpg` (Subtasks panel of parent task "IES"). To be fixed one by one.
This file will be appended with further issues and their solutions.

---

## 1. Badge meaning is ambiguous

The end-date badges were described as "the number of working days of the dependency,"
but several badges read `+0d`, which would imply zero-day dependency tasks — unlikely.
They look more like the **delay each dependency contributes to this row's end date**
(a lag/offset), not the dependency's own duration.

**Open question:** Is a badge the dependency's duration, or the offset it adds to the
end-date calculation? This distinction determines how end dates are computed.

- **Status:** open
- **Solution:** _pending_

## 2. `self +Xd` badge is unexplained

Every badged row has a green `self` badge whose value equals that row's own WKNG DAYS
(`self +40d` on the 40d row, `self +5d` on the 5d row, etc.). This strongly suggests:

> end date = start date + dependency offsets + own working days

It is a key part of the badge system but was not covered in the explanation.

- **Status:** open
- **Solution:** _pending_

## 3. Start dates contradict the dependency rule

Stated rule: a subtask "cannot start until its dependencies have finished."
Yet every subtask — including ones with predecessors — shows a start date of
**01/01/2026**. So in this UI, dependencies do not push the *start* date; they extend
the *end* date instead (which is why the badges live in the END DATE column).

**Open question:** Is this the intended behavior, or should the start date shift to
after the dependencies finish (standard Gantt / finish-to-start semantics)?

- **Status:** FIXED (2026-07-18)
- **Solution:** End dates were already computed from the *effective* start (next
  working day after the latest predecessor ends) — only the STORED start date was
  stale. New helper `syncStoredStartToEffective()` in design.js now writes the
  effective start into the stored start date for Execution leaves with
  predecessors. It runs in four places: the Enable/Apply pass (with parent starts
  now rolled up as MIN of children, same bulk patch), `recalcDependents` (so live
  edits to a predecessor re-shift its dependents), and the predecessor chip
  add/remove handlers. End dates never change from this fix. Verified on emberly:
  Hanoi stayed 01/01/2027, Nagoya shifted to 03/26/2027, Tokyo to 01/05/2027,
  all end dates unchanged, Check2 27/27 match. Note: removing a predecessor keeps
  the shifted start (the 01/01 baseline is overwritten); re-running Apply resets it.

## 4. Numbers don't reconcile on "subscript"

Badges on `subscript`: `+0d`, `+23d`, `self +11d` ≈ 34 working days from 01/01/2026,
which would land around mid-February — yet its end date is **11/09/2026**.

This suggests the calculation involves the dependencies' **actual end dates**
(e.g., `Labubu Konan` may finish in late October), not just the day counts shown in
the badges. How the end date is actually derived is not yet documented.

- **Status:** open
- **Solution:** _pending_

## 5. Unmentioned / undocumented details

- **Parent rows** (`Hardware`, `CPU must be enabled`, `OS`, `superscript`) have
  grayed-out dates and no WKNG DAYS — presumably rolled up from children, read-only.
- **End dates on leaf rows with dependencies are grayed** — implying they are
  computed, not user-entered. Not stated whether end date is ever editable.
- **TIMELINE button** in the end-date cell is unexplained.
- **External predecessors:** chips like `BRAIN`, `Labubu Konan`, `CIMTool Tab22 > …`
  appear to come from *other* parent tasks entirely — so a predecessor is not
  necessarily a subtask of IES, contrary to what the explanation implied.

- **Status:** open
- **Solution:** _pending_



####### ITEMS TO CHECK ##########
- remove option A and rename OPTION B and C
- on button RESET, does it erase which columns? make sure nto to erase wht working days and %Complete
- on the PRODUCTION, when you add a predecessor, does it fetch for the value of working days or the value first of START/END DATE then it computes for the number of working days between those two dates? and where does it get that? on the API/JSON or from the web form itself?
- on the PRODUCTION, check the actual value of the stored START and END DATE and compare that agains the value of END DATE that is shown on the WEB-UI. did it take into consideration to compute the actual END DATE if there was a predecessor on the task?