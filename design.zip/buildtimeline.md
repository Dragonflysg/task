# buildtimeline.md — Timeline (Hierarchy Gantt) for the Project Hub

How timeline.html + timeline.js were built, how to use them, and how they
integrate with design.html. Built 2026-07-18 against the live schema of
`GROUP/<project>.json`.

---

## 1. What it is

A read-only Hierarchy Gantt view of a project (or one subtask subtree),
opened in its own tab. It mirrors the design.html subtask tree: parent
rollups as hollow bars, leaf subtasks as solid bars, month axis, today
marker, collapsible parents, tooltips, dark mode.

Files (all in the app root, served by the same Flask server):

| File | Role |
|---|---|
| `timeline.html` | Shell: header, legend, notice banner, loading/error states. Loads jQuery (same CDN as design.html), timeline.css, timeline.js |
| `timeline.js` | All logic: scope resolution, API fetch, date derivation, rendering, collapse, tooltips |
| `timeline.css` | Visual tokens (light + dark via `prefers-color-scheme`), Archivo + IBM Plex Mono |

No build step, no new dependencies, no server changes.

## 2. How it gets its scope (handoff design)

Priority order, implemented in `resolveScope()` in timeline.js:

1. **Query string** (primary): `timeline.html?project=NAME&taskId=123`
2. **sessionStorage** (fallback): key `timeline` holding
   `{"project": "NAME", "taskId": 123}` (`taskId: null` = whole project)
3. **Default**: whole `DEFAULT_PROJECT`
   (constant at the top of timeline.js — currently
   `INTL_to_ITServices_Execution`)

Why query-string first: survives F5, bookmarkable, shareable, and immune to
the sessionStorage copy gotcha (a new tab gets a one-time COPY of the
opener's sessionStorage at creation — a reused named tab keeps its old copy).

Why not pass the whole task tree through sessionStorage: an earlier build of
design.js did exactly that and hit the browser storage quota on large
projects (see the no-op `saveData()` comment in design.js). The server is
the single source of truth; timeline fetches it fresh.

## 3. Where the data comes from, and the trust rules

Fetch: `GET /api/load-group?project=NAME` — the same endpoint design.js
uses. Task tree is at `resp.data._taskData.tasks` (recursive `subtasks`).

Rules (established by comparing the in-memory array against the server
JSON — see comparedata.md):

| Field | Trust? | Why |
|---|---|---|
| leaf `startDate` / `endDate` | YES | patched to the server on every edit |
| parent `startDate` / `endDate` | NO — derive | design.js only re-syncs a parent while it is open in the detail pane; stored values go stale (verified: stale `IES > OS` rollup found in live data) |
| `_workingDays` | NEVER | recomputed in memory, never written back; 0 on parents |

So timeline.js:
- uses stored dates for **leaves only**;
- derives every parent's span as **min(start) / max(end) of its descendant
  leaves** (`deriveDates()`);
- counts working days itself, Mon–Fri inclusive (`workingDays()`), copied
  from design.js `calcDuration` so both pages always show the same number.

## 4. Rendering, in order (`render()` in timeline.js)

1. Time domain = min start → max end across all rows, padded to whole
   months. Chart min-width = `NAME_COL_PX + months * MONTH_PX +
   RIGHT_GUTTER_PX` so wide ranges scroll horizontally inside the panel.
2. Month gridlines + centered labels; year suffix (’27) added to January
   and the first label when the domain spans more than one calendar year.
3. Today marker (dashed line + pill) — only if today falls inside the domain.
4. One row per task, depth-indented. Whole-project view sorts the
   top-level tasks alphabetically (display only, server order untouched);
   inside a branch, and in scoped views, rows follow stored source order:
   - parent → hollow `tl-rollbar` + caret + child count; click name/caret
     to collapse or expand the subtree (`collapsed` map + `applyCollapse()`)
   - leaf → solid `tl-bar` (inner darker fill = `percentComplete`) +
     working-day count after the bar
   - leaf with predecessors → up to two hatched segments before the bar:
     - grey `tl-wait` ("waiting on predecessor"): project day 1 (earliest
       leaf start in the WHOLE project) up to the latest predecessor's end
       (derived end if the predecessor is a parent) — blocked time while
       the predecessor chain runs.
     - amber `tl-idle` ("idle gap"): predecessor end + 1 day up to the
       leaf's start — dead time / slack. Only shown when it contains ≥1
       working day, so a weekend-only gap is not marked.
     Predecessors are resolved against the WHOLE project, so tails appear
     even when the predecessor is outside the scoped subtree; the axis is
     widened so tails reaching before the first bar stay visible.
   - missing/invalid dates → italic "no dates set", no bar
5. Every bar and tail is keyboard-focusable and carries a tooltip. Bars:
   full dates, working days, and for leaves status / % complete /
   predecessor names (shown as a design.html-style path, e.g.
   "emberly > Nagoya", with each one's end date) / assignees. Tails: the
   predecessor name(s) plus the waiting/idle span and working-day count.
   Bars include the whole end day (`endPct = pct(end + 1 day)`).

Edge cases handled: unknown taskId → banner notice + full project; server
down / bad response → error panel with Retry; malformed sessionStorage JSON
→ ignored; empty project → "No dated tasks to plot."

## 5. How to use it

- Whole project: `timeline.html` (default project) or
  `timeline.html?project=INTL_to_ITServices_Execution`
- One subtree: `timeline.html?project=NAME&taskId=ID`
- From design.html: select a task, click the **Timeline** button in the
  Subtasks header.
- Collapse/expand: click a parent's name or caret. Hover or Tab onto any
  bar for details. Dark mode follows the OS setting.
- Initial state: the whole-project view always loads fully collapsed
  (top-level rows only). A scoped view loads collapsed when the scope root
  has ≥ 10 first-level subtasks, fully expanded otherwise.
- Expand All / Collapse All button at the right end of the legend row. The
  label reflects the chart's actual state (anything still collapsed →
  "Expand All"); hidden when the view has no parent rows at all.

## 6. Integration points in design.html (already applied)

Three additions, nothing else touched:

**design.html** — button beside Check in the subtask header:
```html
<button id="btn-timeline" title="Open this task's timeline in a new tab">
    <i class="fa fa-timeline"></i> Timeline
</button>
```

**design.js** — delegated click handler (placed above the `#btn-check-data`
handler):
```js
$(document).on('click', '#btn-timeline', function () {
    if (!PROJ_NAME || !selectedTaskId) return;
    try {
        sessionStorage.setItem('timeline', JSON.stringify({
            project: PROJ_NAME,
            taskId: selectedTaskId
        }));
    } catch (e) { /* quota/unavailable — query string still carries the scope */ }
    window.open('timeline.html?project=' + encodeURIComponent(PROJ_NAME) +
                '&taskId=' + encodeURIComponent(selectedTaskId), '_blank');
});
```

**design.css** — `#btn-timeline` rule cloned from `#btn-check-data`
(white/blue outline, fills on hover). Needed because the header buttons are
styled per-ID, not by a shared class.

To add a whole-project button later, same handler without `taskId`:
```js
window.open('timeline.html?project=' + encodeURIComponent(PROJ_NAME), '_blank');
```

Note: the Timeline button is currently visible to everyone; Check/Check2
are gated (`CURRENT_USER_ID === 'gs6368'` + Assessment/Execution). Gate it
the same way in `renderDetail` if needed.

## 7. Tunables (top of timeline.js)

| Constant | Default | Meaning |
|---|---|---|
| `DEFAULT_PROJECT` | `INTL_to_ITServices_Execution` | project loaded when no scope is given |
| `NAME_COL_PX` | 340 | width of the task-name column |
| `RIGHT_GUTTER_PX` | 118 | space reserved past the last bar for day-count labels |
| `MONTH_PX` | 56 | minimum horizontal pixels per month before the panel scrolls |

## 8. Known limitations / future ideas

- Read-only by design; no editing, no writes to the server.
- Bars plot stored leaf dates only — no predecessor-chain simulation. If a
  leaf's `endDate` doesn't reflect its predecessors, that is a design.js
  data issue and will show here as-is (truthfully). The hatched tails are
  the one predecessor-aware element: grey = blocked while the predecessor
  runs (from project day 1), amber = idle gap after the predecessor ends.
  They never move any bar.
- Snapshot at load; Retry/F5 to refresh. Could later join the project's
  Socket.IO room (like design.js) for live updates.
- Single accent color for all leaf bars: with 15 top-level branches, a
  color-per-branch palette can't stay colorblind-safe (8-slot max);
  identity is carried by the tree column instead.
- Deleting a task while its timeline tab is open: next Retry/F5 shows the
  not-found notice and falls back to the full project.
