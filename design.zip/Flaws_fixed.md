# Flaws Fixed — "Enable Start Date" Apply hang (browser freeze)

**Handoff document.** Written in the development environment after diagnosing and
fixing a browser hang, verified end-to-end. Intended reader: Claude (Opus 4.8) on the
production server, to review the findings and implement the same changes there.

**App context:** Project Hub — a Flask + Socket.IO task manager. Relevant files:
`design.html` / `design.js` (task detail page with the "Enable Start Date" dialog),
`view.js` (grid page), `update.js` (kanban page), `controllers_server.py` (Flask
routes, WebSocket handlers, JSON persistence). Task data is one JSON file per project
under `GROUP/`, held in an in-memory cache and flushed to disk asynchronously.
Clients persist edits by sending patches (`send_patch` over WebSocket, or POST
`/api/patch-task` fallback); the server applies each patch and re-broadcasts it to
other clients in the project room.

---

## 1. Symptom

On the design page, clicking **Apply** in the "Enable Start Date" dialog (the option
that stamps a chosen start date on every task and subtask, then computes all END
DATEs) froze the browser tab hard. The project in question has **3,141 task items**
(56 top-level tasks, 728 leaves) in a 2.4 MB JSON.

## 2. What it was NOT

The first suspect was broadcast traffic: the legacy Apply sent **one WebSocket patch
per field per row** (start date per row, end date per changed row, etc. — thousands
of individual `socket.emit` calls, each triggering a server write, a log line, a
version bump, and a re-broadcast). That was real and worth fixing (see §5), but it
was **not** what froze the tab.

## 3. Root cause: a runaway feedback loop in the end-date recompute passes

The Apply handler recomputes END DATEs in repeated passes over all items so that
predecessor chains propagate (a row's effective start = next working day after its
latest predecessor's end date). The loop looked like this:

```js
var _maxPasses = _allFlat.length + 2;              // 3,143 for this project
for (var _pass = 0; _pass < _maxPasses; _pass++) {
    var _any = false;
    for (var _i = 0; _i < _allFlat.length; _i++) {
        var _it = _allFlat[_i];
        if (_it.subtasks && _it.subtasks.length > 0) continue;
        var _dur = getStoredDuration(_it);          // ← re-derived EVERY pass
        var _newEnd = computeEndDateFromDuration(_it, _dur);
        if (_newEnd && _newEnd !== _it.endDate) {
            _it.endDate = _newEnd;
            _any = true;
        }
    }
    if (!_any) break;
}
```

The defect is `getStoredDuration(_it)` **inside** the pass loop. That helper falls
back to *deriving* the duration from the row's own dates when `_workingDays` is not
set:

```js
function getStoredDuration(taskObj) {
    if (taskObj._workingDays && taskObj._workingDays > 0) return taskObj._workingDays;
    if (!taskObj.startDate || !taskObj.endDate) return 0;
    var dur = calcDuration(taskObj.startDate, taskObj.endDate);   // ← feedback path
    ...
}
```

For a row with **empty WKNG DAYS and at least one predecessor**, the passes feed
back on themselves:

1. Pass 1: duration = 0 → end date stamped just after the predecessor finishes
   (e.g. start 01/18/2027, end ≈ 08/31/2027).
2. Pass 2: duration is now *derived from those dates* → ≈ 158 working days → end
   pushed 158 working days past the effective start.
3. Pass 3: derived duration is even bigger → end pushed further.
4. …every pass changes an end date, so `_any` never goes false. The loop only stops
   at `_maxPasses` = **item count + 2** (3,143 passes here), and each pass costs a
   full scan with recursive predecessor resolution (`findTaskById` is an O(N) tree
   walk per lookup). All of it synchronous on the UI thread → frozen tab.

**Measured (Node harness replaying the exact logic against the real project JSON):**
804 passes in 60 s and still diverging when the safety timeout fired; 7.28 million
`findTaskById` calls; every pass reported changes. In the browser this presents as a
permanently hung tab.

Note: the feedback loop predates the "empty = 0d" rule (any row with empty
`_workingDays`, a stale end date, and a predecessor could trigger it), but treating
empty WKNG DAYS as 0d (a deliberate feature — see §6) seeds an end date on *every*
leaf and made the runaway certain.

## 4. The fix (design.js, inside the Apply handler's recompute block)

Two changes, both in the Option B (bulk start date) branch of the
`$('#esd-apply').on('click', ...)` handler:

**(a) Snapshot every leaf's duration ONCE before the passes.** Durations are inputs
to the computation, not outputs — the passes exist only to propagate predecessor end
dates. Empty WKNG DAYS is a fixed `0`, never re-derived:

```js
var _durById = {};
for (var _d = 0; _d < _allFlat.length; _d++) {
    var _lf = _allFlat[_d];
    if (_lf.subtasks && _lf.subtasks.length > 0) continue;
    _durById[_lf.id] = (_lf._workingDays && _lf._workingDays > 0) ? _lf._workingDays : 0;
}
```

**(b) Cap the passes at a constant** instead of item count. Passes only need to cover
the deepest predecessor chain; the cap guarantees even a dependency *cycle* in the
data costs at most 100 cheap passes, never a frozen tab:

```js
var _changedEndIds = {};
var _maxPasses = 100;
for (var _pass = 0; _pass < _maxPasses; _pass++) {
    var _any = false;
    for (var _i = 0; _i < _allFlat.length; _i++) {
        var _it = _allFlat[_i];
        if (_it.subtasks && _it.subtasks.length > 0) continue;
        var _newEnd = computeEndDateFromDuration(_it, _durById[_it.id]);   // snapshot, not getStoredDuration
        if (_newEnd && _newEnd !== _it.endDate) {
            _it.endDate = _newEnd;
            _changedEndIds[_it.id] = true;
            _any = true;
        }
    }
    if (!_any) break;
}
```

The parent roll-up after the loop (`getMaxSubtaskEndDate` bottom-up) is unchanged.

**Measured after the fix (same data, same harness): 3 passes, 21 ms total,
32,607 `findTaskById` calls, all 3,141 end dates stamped.** Verified live in Chrome
against the dev server: Apply returns instantly, rows with empty WKNG DAYS get
END DATE = start date, rows with predecessors start the day after their latest
predecessor ends, parents roll up correctly.

## 5. Companion change (prerequisite): one-shot bulk persistence

The fixed recompute sits inside a rewritten Apply flow that also replaced the per-row
broadcasts. If production still sends per-row patches, implement this too — the two
changes were designed together:

- **Client (`design.js`):** the Apply handler queues every change —
  `_startDateEnabled` per top-level task, `startDate` for every row, every computed
  `endDate` — into one array and, only after ALL computation finishes, sends a single
  patch: `sendPatch({ op: 'bulkUpdate', updates: [{taskId, field, value}, ...] })`.
  The Reset option in the same dialog was likewise converted (Reset also no longer
  clears `_workingDays` or `percentComplete` — business decision: a reset keeps
  durations and progress so re-enabling can recompute from them).
- **Server (`controllers_server.py`):** new `bulkUpdate` op in
  `apply_patch_to_file()` — applies all entries under the existing per-project lock
  as **plain field sets** (no status→% or %→status derivations), then falls through
  to the shared tail: one version bump, one dirty-mark/async flush, one backup
  check; the caller does one log line and one room broadcast. Ops handled: reject
  when `updates` is empty or no entry matches a task.
- **Receivers:** every page that listens for `patch` events handles
  `op === 'bulkUpdate'`:
  - `design.js` → plain field sets per entry (deliberately NOT routed through the
    single-field update path: that path derives `% = 0` from a leaf status of
    "Not Started" and would erase % Complete on other open tabs during a Reset),
    then one `renderTaskList()` + `renderDetail()`.
  - `update.js` → apply all entries, one `renderBoard()`.
  - `view.js` → replay each entry through its existing single-field grid handler
    (per-cell rendering is desired there).

Verified on dev: one Apply produced exactly **one** log entry carrying 4,466 field
updates and one JSON flush one second later — previously that was thousands of
individual patches, each with its own broadcast, log line, and version bump.

## 6. Behavior rules the implementation must preserve

- **Empty WKNG DAYS = 0d, computed but never written back.** Rows with no working
  days still get an END DATE (own start date, or day-after-predecessor); the WKNG
  DAYS column stays blank — do not write `0`/`0d` into it.
- Parents (rows with children) are skipped in the pass loop; their end dates come
  only from the bottom-up roll-up (max of children).
- Durations come from `_workingDays` only during the Apply recompute (the
  `calcDuration`-from-dates fallback must NOT be consulted inside the passes).
- The single `bulkUpdate` is sent only after all computation and stamping finishes.

## 7. How to verify after implementing

1. Open the design page on a large project, click Enable → set a start date →
   Apply. The dialog must close and the grid update within ~1 second; the tab must
   stay responsive throughout.
2. Check a row with empty WKNG DAYS and no predecessor: END DATE = the chosen start
   date; WKNG DAYS still blank.
3. Check a row with predecessors: END DATE = next working day after its latest
   predecessor's end (+ its own working days if any); badges render.
4. Check parent rows: END DATE = max of children.
5. Server log for the project (LOGS/<project>/<date>.log): the Apply must appear as
   **one** entry (a `bulkUpdate` with an `updates` array), not thousands of lines.
6. Open a second browser tab on the same project before clicking Apply: it must
   receive the changes once and re-render without erasing % Complete or WKNG DAYS.
