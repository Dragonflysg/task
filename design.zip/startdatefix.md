# Start-Date Fix — predecessors now shift the stored START DATE

Handoff document for the production copy (design.aspx / Claude Opus 4.8).
Implements the same change verified on the dev copy (design.html) on 2026-07-18.
This resolves **flaws.md #3** ("Start dates contradict the dependency rule").

---

## 1. The problem

In an Execution project, "Enable Start Date → Apply" stamps ONE date (e.g.
01/01/2027) into every row. But a row with predecessors cannot start until its
predecessors finish. Example (parent task `emberly`):

| Row    | Predecessor            | Shown START | Correct START |
|--------|------------------------|-------------|---------------|
| Hanoi  | (none)                 | 01/01/2027  | 01/01/2027 ✓  |
| Nagoya | BRAIN > Hzw (ends 03/25) | 01/01/2027 | 03/26/2027    |
| Tokyo  | BRAIN > OS > windows (ends 01/14) | 01/01/2027 | 01/15/2027 |

**Key insight — end dates were already correct.** The engine computes each end
date from the *effective* start (`getEffectiveStartDate` = next working day
after the latest predecessor's end), not from the stored start. Only the
STORED/DISPLAYED start date was stale. So this fix changes **no end-date math**;
it makes the stored start date match what the engine already uses.

## 2. Behavior rules (as approved)

1. **Apply (Enable Start Date, Option B):** after end dates settle, every leaf
   with predecessors gets its stored start overwritten with the effective start.
   Parent rows roll up START = MIN of children (mirroring END = MAX of children).
2. **Live edits:** the same correction runs when a predecessor is added, when
   one of several is removed, and when a predecessor's dates move
   (`recalcDependents` cascade). No Apply needed.
3. **Removing the LAST predecessor clears START and END DATE** (empty). The
   original bulk date is not stored anywhere (a hidden baseline field was
   considered and rejected), so instead of keeping a now-meaningless shifted
   date, both dates go blank — it is obvious the row needs a new date. WKNG
   DAYS is preserved. User restores via manual date entry or re-running Apply.
4. Multiple predecessors: effective start = next working day after the LATEST
   predecessor end. Removing one of several recomputes from the remaining ones.
5. Everything is gated on `isExecutionProject()` — non-Execution projects keep
   their manual-date behavior.

## 3. Bug found during testing (include this — it will bite production too)

First implementation put the start-correction step BEFORE the parent end-date
roll-up inside the Apply handler. Result after a Reset → Apply cycle:

- **Tokyo's predecessor `windows` is a PARENT row** (its end date only exists
  after rolling up its children). At correction time it had no end date yet
  (Reset had cleared everything), so Tokyo was silently skipped — start stayed
  01/01.
- Worse, Tokyo's **stored end date was also wrong** (05/06 = 01/01 + 90wd,
  ignoring the predecessor) while the screen displayed a live-computed 05/20 —
  a stored/displayed mismatch. This part was a pre-existing bug: the recompute
  passes skipped parent rows entirely and rolled them up only once at the end,
  so any leaf depending on a parent predecessor never saw its end date.
- It had *looked* fine on the first run only because `windows` still had a
  stale end date from before the Reset.

**Fix:** roll parent end dates up **inside** the recompute pass loop (each pass:
recompute leaf ends → roll up parent ends → repeat until stable). The start
correction then runs after the loop, when every row — leaf or parent — has its
final end date. Rows that predecessor a leaf (like Nagoya → Hzw) worked either
way; rows that predecessor a parent (like Tokyo → windows) need this ordering.

## 4. Implementation

All changes are in **design.js** (client only — no server/API changes; the
corrections ride on the existing `update` / `bulkUpdate` patches, and the
server applies bulk updates in order, so corrected values queued after the
initial stamping win).

Existing helpers used (already in the file): `getEffectiveStartDate`,
`computeEndDateFromDuration`, `getStoredDuration`, `getMinSubtaskStartDate`,
`getMaxSubtaskEndDate`, `syncParentStartDate`, `syncParentEndDate`,
`recalcDependents`, `ensurePredecessorArray`, `isExecutionProject`.
Adapt names if production differs.

### Step 1 — new helper (place next to `getEffectiveStartDate` / `computeEndDateFromDuration`)

```js
// Execution: keep the STORED start date of a leaf in sync with its
// effective start (next working day after the latest predecessor ends).
// End dates are already computed from the effective start, so this can
// never change an end date — it only stops the START DATE column from
// showing the stale pre-dependency date. Returns true when the stored
// value changed; the caller is responsible for saveData/sendPatch.
function syncStoredStartToEffective(taskObj) {
    if (!isExecutionProject()) return false;
    if (!taskObj || (taskObj.subtasks && taskObj.subtasks.length > 0)) return false;
    ensurePredecessorArray(taskObj);
    if (!taskObj.predecessor || taskObj.predecessor.length === 0) return false;
    var eff = getEffectiveStartDate(taskObj);
    if (!eff || eff === taskObj.startDate) return false;
    taskObj.startDate = eff;
    return true;
}
```

### Step 2 — `recalcDependents`: dependents get their start re-stamped

Inside the loop over dependents, directly AFTER the existing
`if (dur > 0) { ... }` end-date block, add:

```js
if (syncStoredStartToEffective(item)) {
    saveData();
    sendPatch({ op: 'update', taskId: item.id, field: 'startDate', value: item.startDate });
}
```

(The existing `var dur = getStoredDuration(item);` line must stay ABOVE this —
`getStoredDuration`'s fallback derives from the stored start/end span, so it
must read the pre-stamp dates.)

### Step 3 — predecessor dropdown toggle handler (`.pred-dropdown-item` click)

This handler both adds and removes (un-ticks) predecessors. Replace its
`if (changedTask) { ... }` recompute block with:

```js
if (changedTask && isExecutionProject() && idx !== -1 && preds.length === 0) {
    // LAST predecessor removed (un-ticked in the dropdown). The
    // pre-shift start is not stored anywhere, so clear both dates
    // instead of keeping the shifted ones — an empty START DATE
    // makes it obvious the row needs a new date. WKNG DAYS is
    // preserved.
    changedTask.startDate = '';
    changedTask.endDate = '';
    saveData();
    sendPatch({ op: 'update', taskId: changedTask.id, field: 'startDate', value: '' });
    sendPatch({ op: 'update', taskId: changedTask.id, field: 'endDate', value: '' });
    recalcDependents(changedTask.id);
    if (changedTask.id === selectedTaskId &&
        !(changedTask.subtasks && changedTask.subtasks.length > 0)) {
        $('#detail-start-date').val('');
        $('#detail-end-date').val('');
    }
} else if (changedTask) {
    // Duration must be read BEFORE the start is stamped: its fallback
    // derives from the stored start/end span.
    var dur = getStoredDuration(changedTask);
    if (syncStoredStartToEffective(changedTask)) {
        saveData();
        sendPatch({ op: 'update', taskId: changedTask.id, field: 'startDate', value: changedTask.startDate });
        if (changedTask.id === selectedTaskId &&
            !(changedTask.subtasks && changedTask.subtasks.length > 0)) {
            $('#detail-start-date').val(toDisplayDate(changedTask.startDate));
        }
    }
    if (dur > 0) {
        var newEnd = computeEndDateFromDuration(changedTask, dur);
        if (newEnd) {
            changedTask.endDate = newEnd;
            saveData();
            sendPatch({ op: 'update', taskId: changedTask.id, field: 'endDate', value: newEnd });
            recalcDependents(changedTask.id);
            // If this was the currently-displayed header task (leaf),
            // refresh the END DATE input so the UI reflects the new value.
            if (changedTask.id === selectedTaskId &&
                !(changedTask.subtasks && changedTask.subtasks.length > 0)) {
                $('#detail-end-date').val(toDisplayDate(newEnd));
            }
        }
    }
}
```

(`idx !== -1` is the handler's existing "this click was a removal" flag;
`preds` is the array after the splice/push.)

Also, in the same handler's tail where the subtask table refreshes, add
`syncParentStartDate(parentTask);` before the existing
`syncParentEndDate(parentTask);` so the parent's start rolls up too.

### Step 4 — predecessor chip remove handler (`.pp-chip-remove` click)

Replace the "Recalculate end date after predecessor removal" block with:

```js
if (isExecutionProject() && taskObj.predecessor.length === 0) {
    // LAST predecessor removed. The pre-shift start is not stored
    // anywhere, so clear both dates instead of keeping the shifted
    // ones — an empty START DATE makes it obvious the row needs a
    // new date (re-run Enable/Apply or set one manually).
    // WKNG DAYS is preserved.
    taskObj.startDate = '';
    taskObj.endDate = '';
    saveData();
    sendPatch({ op: 'update', taskId: taskObj.id, field: 'startDate', value: '' });
    sendPatch({ op: 'update', taskId: taskObj.id, field: 'endDate', value: '' });
    recalcDependents(taskObj.id);
    if (taskObj.id === selectedTaskId &&
        !(taskObj.subtasks && taskObj.subtasks.length > 0)) {
        $('#detail-start-date').val('');
        $('#detail-end-date').val('');
    }
} else {
    // Recalculate end date after predecessor removal. Duration must be
    // read BEFORE the start is stamped: its fallback derives from the
    // stored start/end span.
    var dur = getStoredDuration(taskObj);
    if (syncStoredStartToEffective(taskObj)) {
        saveData();
        sendPatch({ op: 'update', taskId: taskObj.id, field: 'startDate', value: taskObj.startDate });
        if (taskObj.id === selectedTaskId &&
            !(taskObj.subtasks && taskObj.subtasks.length > 0)) {
            $('#detail-start-date').val(toDisplayDate(taskObj.startDate));
        }
    }
    if (dur > 0) {
        var newEnd = computeEndDateFromDuration(taskObj, dur);
        if (newEnd) {
            taskObj.endDate = newEnd;
            saveData();
            sendPatch({ op: 'update', taskId: taskObj.id, field: 'endDate', value: newEnd });
            recalcDependents(taskObj.id);
            if (taskObj.id === selectedTaskId &&
                !(taskObj.subtasks && taskObj.subtasks.length > 0)) {
                $('#detail-end-date').val(toDisplayDate(newEnd));
            }
        }
    }
}
```

And in this handler's tail, likewise add `syncParentStartDate(parentTask);`
before `syncParentEndDate(parentTask);`.

### Step 5 — Apply handler ("Enable Start Date", Option B branch)

In the multi-pass end-date recompute loop, the section from the pass loop to
the bulk-queue must become (this includes the Section-3 bug fix — the parent
end roll-up moved INSIDE the loop):

```js
var _changedEndIds = {};
// Passes only need to cover the deepest predecessor chain; the
// cap also guarantees a dependency cycle in the data can only
// cost 100 cheap passes, never a frozen tab.
var _maxPasses = 100;
for (var _pass = 0; _pass < _maxPasses; _pass++) {
    var _any = false;
    for (var _i = 0; _i < _allFlat.length; _i++) {
        var _it = _allFlat[_i];
        // Skip parents with subtasks — their end dates roll up from children
        if (_it.subtasks && _it.subtasks.length > 0) continue;
        var _newEnd = computeEndDateFromDuration(_it, _durById[_it.id]);
        if (_newEnd && _newEnd !== _it.endDate) {
            _it.endDate = _newEnd;
            _changedEndIds[_it.id] = true;
            _any = true;
        }
    }
    // Parent end dates must roll up INSIDE the pass loop: a row
    // whose predecessor is a PARENT (e.g. "BRAIN > OS > windows")
    // reads that parent's endDate, which is empty right after a
    // Reset until its children's ends have rolled up. Rolling up
    // per pass lets the next pass see it.
    (function _rollupEnds(list) {
        if (!list) return;
        for (var i = 0; i < list.length; i++) {
            var _t = list[i];
            if (_t.subtasks && _t.subtasks.length > 0) {
                _rollupEnds(_t.subtasks);
                var _maxEnd = getMaxSubtaskEndDate(_t.subtasks) || '';
                if (_maxEnd !== (_t.endDate || '')) {
                    _t.endDate = _maxEnd;
                    _changedEndIds[_t.id] = true;
                    _any = true;
                }
            }
        }
    })(tasks);
    if (!_any) break;
}

// Stamp the effective start into every leaf with predecessors.
// The end dates above are already computed from the effective
// start, so this cannot change any end date — it only replaces
// the stale bulk-stamped start (a row cannot start before its
// predecessors finish).
var _changedStartIds = {};
for (var _s = 0; _s < _allFlat.length; _s++) {
    if (syncStoredStartToEffective(_allFlat[_s])) {
        _changedStartIds[_allFlat[_s].id] = true;
    }
}

// Roll up parent start dates bottom-up (parent end dates were
// already rolled up inside the pass loop above)
(function _rollupStarts(list) {
    if (!list) return;
    for (var i = 0; i < list.length; i++) {
        var _t = list[i];
        if (_t.subtasks && _t.subtasks.length > 0) {
            _rollupStarts(_t.subtasks);
            var _minStart = getMinSubtaskStartDate(_t.subtasks) || '';
            if (_minStart !== (_t.startDate || '')) {
                _t.startDate = _minStart;
                _changedStartIds[_t.id] = true;
            }
        }
    }
})(tasks);

// Queue all changed dates onto the same bulk patch. These are
// appended AFTER the initial project-wide stamping entries, and
// the server applies updates in order, so the corrected values win.
for (var _sid in _changedStartIds) {
    if (!_changedStartIds.hasOwnProperty(_sid)) continue;
    var _cst = findTaskById(parseInt(_sid), tasks);
    if (_cst) {
        bulkUpdates.push({ taskId: _cst.id, field: 'startDate', value: _cst.startDate || '' });
    }
}
for (var _cid in _changedEndIds) {
    if (!_changedEndIds.hasOwnProperty(_cid)) continue;
    var _ct = findTaskById(parseInt(_cid), tasks);
    if (_ct) {
        bulkUpdates.push({ taskId: _ct.id, field: 'endDate', value: _ct.endDate || '' });
    }
}
```

(`_allFlat` and `_durById` come from the existing code directly above this
section: `_allFlat` is every task/subtask flattened, `_durById` snapshots each
leaf's `_workingDays` — or 0 — ONCE before the passes. Do not re-derive
durations inside the loop; that caused a feedback-loop browser hang before.)

## 5. Verification checklist (all passed on dev)

1. **Reset → Apply 01/01/2027** on a project like emberly:
   Hanoi (no pred) stays 01/01; Nagoya (pred = leaf Hzw, ends 03/25) start
   becomes 03/26; Tokyo (pred = PARENT windows, ends 01/14) start becomes
   01/15 and its STORED end is correct (01/15 + 90wd = 05/20), not 01/01+90wd.
   The Tokyo case is the Section-3 regression test — run it after a Reset,
   not just on already-populated data. All corrections must arrive in ONE
   `bulkUpdate` log entry, corrected values after the stamped ones.
2. **Add a predecessor** to a dated row: start shifts immediately (Hanoi +
   Hzw → 03/26), end recomputes (05/06), parent start/end roll up. No Apply
   needed.
3. **Remove one of two predecessors:** dates recompute from the remaining one.
4. **Remove the last predecessor** (both via chip × and via un-tick in the
   dropdown): START and END become empty, WKNG DAYS untouched. Setting the
   start manually afterwards recomputes the end (01/01 + 30d → 02/11).
5. End dates must NOT change in step 1 for rows that already had correct data
   — this fix only rewrites starts (plus the Section-3 stored-end repair).

## 6. Notes / limitations

- Only weekends are skipped (`nextWorkingDay` / `addWorkingDays`); holidays are
  not handled anywhere in the app — unchanged.
- The bulk Apply date is used once and not persisted; that is why the
  last-predecessor rule clears dates instead of restoring the original.
- Dependents in OTHER top-level tasks get their start/end patched by
  `recalcDependents`, but only the currently-selected task's tree re-renders —
  same (pre-existing) behavior as end dates.
- `getStoredDuration` must always be called BEFORE `syncStoredStartToEffective`
  on the same row (its fallback reads the stored dates).
