# Check2 — Screen vs Server JSON comparison button

**Handoff document.** Written in the development environment after building and
verifying the feature end-to-end. Intended reader: Claude (Opus 4.8) on the
production server, to implement the same feature there.

**App context:** Project Hub — a Flask + Socket.IO task manager. Relevant files:
`design.html` / `design.js` / `design.css` (task detail page with the Subtasks
table), `controllers_server.py` + `flask.server.py` (Flask routes). Task data is
one JSON file per project under `GROUP/`, served through the existing endpoint
`GET /api/load-group?project=<name>` (no server changes are needed for this
feature — that endpoint already returns the whole project with every field).

---

## 1. Why this button exists

A real incident motivated it: a subtask ("Nagoya") displayed **61d** in the
WKNG DAYS column while the JSON stored **nothing** (`_workingDays: 0`). The
column falls back to *deriving* a value from the row's start/end dates when
nothing is stored, so a lost/never-saved entry is invisible — the screen shows a
plausible number either way. The user only noticed because a second row with the
same visible inputs produced a different END DATE.

**Check2 makes that class of problem visible in one click**: it compares what
the subtask table currently *displays* against what the server actually has
*stored*, column by column.

## 2. What Check2 does

On click, for the currently open top-level task:

1. **Fetches the project fresh** from `GET /api/load-group?project=<PROJ_NAME>`
   (the server's live cache — the authoritative state every client sees). The
   client's in-memory `tasks` array is deliberately **not** consulted; this is
   screen vs server only.
2. **Finds the open task by id** (`selectedTaskId`, never by name) in the
   response and flattens its subtask tree.
3. **Scrapes the rendered subtask table** row by row: every cell input/select is
   tagged `data-id` (task id) + `data-field`, predecessor chips are
   `.pp-chip[data-pred-id]`, assignee chips are `.cp-chip[data-contact-id]`.
   The scrape captures the exact strings on screen — including derived
   fallback values that exist nowhere in the data.
4. **Compares per row, per column** (Task Name, Start Date, End Date,
   WKNG DAYS, Predecessor, % Cmplt, Status, Assigned To, Cost) and shows a
   report dialog: **ON SCREEN | IN JSON | ✓/✗ | HINT**, differences sorted to
   the top, plus a summary line ("27 comparisons — 26 match, 1 differ") and the
   server version number.

**Read-only:** it fixes nothing and writes nothing.

### Hints are rule-based (no AI)

Every column has a known source of truth, so "which side is right" is decided
by arithmetic:

- Stored input fields (name, dates, WKNG DAYS, %, status, cost, predecessor):
  the JSON is truth by definition — hint: *"JSON is the stored value"*.
- The Nagoya trap gets a specific hint: if the screen shows a WKNG DAYS value,
  the JSON stores 0/empty, **and** the number equals
  `calcDuration(startDate, endDate)`, the hint reads: *screen value is
  auto-computed from the dates; NOTHING is stored in JSON — if you typed it,
  the entry never saved.*
- END DATE mismatches on Execution leaves: recompute the expected value from
  stored inputs (`nextWorkingDay(MAX(pred.endDate))` if predecessors exist,
  else own start, `+ _workingDays`) and say which side matches the formula.

### Special cases handled

- **Parent rows** (rows with children) deliberately display %, Status,
  Assigned To, Cost, and WKNG DAYS as blank while the JSON stores roll-ups —
  those columns are *skipped* on parents (not false mismatches). But a parent
  *storing* leftover `_workingDays > 0` or predecessors **is** flagged
  ("parent rows store no duration / should have no predecessor").
- Rows in the JSON but not rendered on screen (e.g. nested deeper than the
  table's 3-level display cap) → flagged as "(whole row) not displayed".
- Rows on screen but not on the server (unsaved new row) → flagged.
- Dates: screen shows `mm/dd/yyyy`, JSON stores ISO — compared after
  conversion via the existing `toIsoDate()`.
- Predecessor and assignee lists compared as **id sets** (order-insensitive).
- Cost compared numerically with a $0.005 tolerance.

## 3. Implementation steps

### Step 1 — Button (design.html)

Next to the existing Check button in the subtask section header:

```html
<button id="btn-check-data" title="Check auto-computed values" style="display:none;"><i class="fa fa-clipboard-check"></i> Check</button>
<button id="btn-check2-data" title="Compare on-screen values against the server JSON" style="display:none;"><i class="fa fa-code-compare"></i> Check2</button>
```

### Step 2 — Show/hide (design.js)

In the block that toggles `#btn-check-data` (inside the detail-render path),
toggle Check2 with the same rule — visible to gs6368 on Assessment or
Execution projects:

```js
// Check buttons: visible to gs6368 on Assessment or Execution projects
if (CURRENT_USER_ID === 'gs6368' && (isAssessmentProject() || isExecutionProject())) {
    $('#btn-check-data').show();
    $('#btn-check2-data').show();
} else {
    $('#btn-check-data').hide();
    $('#btn-check2-data').hide();
}
```

### Step 3 — Dialog width (design.css)

The report has six columns; the default 560px dialog is too narrow. Add next to
the existing `#check-report-dialog` rule:

```css
#check2-report-dialog .dialog-box {
    width: 900px;
    max-width: 95vw;
    max-height: 80vh;
    display: flex;
    flex-direction: column;
}
```

The table itself reuses the existing Check-dialog classes
(`check-report-body`, `check-report-table`, `crt-item`, `crt-curr`, `crt-exp`,
`crt-reason`, `check-report-allgood`, `check-report-summary`).

### Step 4 — Logic (design.js)

Insert after the existing `#btn-check-data` click handler. Depends only on
helpers that already exist: `toIsoDate`, `toDisplayDate` (via `_chkFmtDate`),
`calcDuration`, `addWorkingDays`, `nextWorkingDay`, `buildPredecessorLabel`,
`_chkFmtCost`, `isAssessmentProject`, `isExecutionProject`, `PROJ_NAME`,
`selectedTaskId`.

```js
// ========== Check2: on-screen values vs server JSON (gs6368 only) ==========
// Fetches the project fresh from /api/load-group and compares what the
// subtask table currently DISPLAYS against what the server has STORED.
// Read-only: reports differences, fixes nothing. The in-memory `tasks`
// array is deliberately not consulted — this is screen vs server only.

function _c2FindById(id, list) {
    if (!list) return null;
    for (var i = 0; i < list.length; i++) {
        if (list[i].id === id) return list[i];
        var found = _c2FindById(id, list[i].subtasks);
        if (found) return found;
    }
    return null;
}

function _c2FlattenServer(list, path, out) {
    if (!list) return out;
    for (var i = 0; i < list.length; i++) {
        var st = list[i];
        var p = path ? (path + ' > ' + (st.name || '(unnamed)')) : (st.name || '(unnamed)');
        out.push({ st: st, path: p });
        _c2FlattenServer(st.subtasks, p, out);
    }
    return out;
}

function _c2ScrapeDomRows() {
    var rows = {};
    $('#subtask-body tr').each(function () {
        var $tr = $(this);
        var $name = $tr.find('input[data-field="name"]');
        if (!$name.length) return;
        var id = parseInt($name.attr('data-id'), 10);
        if (isNaN(id)) return;
        var preds = [];
        $tr.find('.pp-chip').each(function () {
            var pid = parseInt($(this).attr('data-pred-id'), 10);
            if (!isNaN(pid)) preds.push(pid);
        });
        var assigned = [];
        $tr.find('.cp-chip').each(function () {
            assigned.push(String($(this).attr('data-contact-id')));
        });
        var $sel = $tr.find('select[data-field="status"]');
        rows[id] = {
            name: $name.val() || '',
            start: $tr.find('input[data-field="startDate"]').val() || '',
            end: $tr.find('input[data-field="endDate"]').val() || '',
            dur: $tr.find('input[data-field="duration"]').val() || '',
            preds: preds,
            pct: $tr.find('input[data-field="percentComplete"]').val() || '',
            status: $sel.length ? ($sel.val() || '') : ($tr.find('input[data-field="status"]').val() || ''),
            assigned: assigned,
            cost: $tr.find('input[data-field="cost"]').val() || '',
            isLeafOnScreen: $sel.length > 0
        };
    });
    return rows;
}

function _c2SameIdList(a, b) {
    if (a.length !== b.length) return false;
    var sa = a.slice().sort(), sb = b.slice().sort();
    for (var i = 0; i < sa.length; i++) {
        if (String(sa[i]) !== String(sb[i])) return false;
    }
    return true;
}

function runScreenVsServerCheck(srvTask, srvAllTasks) {
    var domRows = _c2ScrapeDomRows();
    var srvRows = _c2FlattenServer(srvTask.subtasks || [], '', []);
    var results = [];   // { path, col, screen, server, ok, hint }
    var seenIds = {};

    function res(path, col, screen, server, ok, hint) {
        results.push({ path: path, col: col, screen: screen, server: server, ok: ok, hint: hint || '' });
    }

    for (var i = 0; i < srvRows.length; i++) {
        var st = srvRows[i].st;
        var path = srvRows[i].path;
        seenIds[st.id] = true;
        var dom = domRows[st.id];
        var isParent = st.subtasks && st.subtasks.length > 0;

        if (!dom) {
            res(path, '(whole row)', '(not displayed)', 'exists in JSON', false,
                'row is in the JSON but not rendered on screen (nested deeper than the table shows?)');
            continue;
        }

        // Task Name
        var sName = (st.name || '').trim();
        if (dom.name.trim() === sName) res(path, 'TASK NAME', dom.name, sName, true);
        else res(path, 'TASK NAME', dom.name, sName, false, 'JSON is the stored value');

        // Start / End Date — screen shows mm/dd/yyyy, JSON stores ISO
        var domStartIso = dom.start ? (toIsoDate(dom.start) || '') : '';
        var srvStart = st.startDate || '';
        if (domStartIso === srvStart) res(path, 'START DATE', dom.start || '(empty)', _chkFmtDate(srvStart), true);
        else res(path, 'START DATE', dom.start || '(empty)', _chkFmtDate(srvStart), false, 'JSON is the stored value; screen may be stale — reload');

        var domEndIso = dom.end ? (toIsoDate(dom.end) || '') : '';
        var srvEnd = st.endDate || '';
        if (domEndIso === srvEnd) res(path, 'END DATE', dom.end || '(empty)', _chkFmtDate(srvEnd), true);
        else {
            var endHint = 'JSON is the stored value; screen may be stale — reload';
            if (isExecutionProject() && !isParent) {
                // Which side matches the formula computed from STORED inputs?
                var ownDays = (st._workingDays && st._workingDays > 0) ? st._workingDays : 0;
                var effStart = srvStart;
                if (st.predecessor && st.predecessor.length > 0) {
                    var maxPredEnd = '';
                    for (var pj = 0; pj < st.predecessor.length; pj++) {
                        var pr = _c2FindById(st.predecessor[pj], srvAllTasks);
                        if (pr && pr.endDate && pr.endDate > maxPredEnd) maxPredEnd = pr.endDate;
                    }
                    if (maxPredEnd) effStart = nextWorkingDay(maxPredEnd);
                }
                var expEnd = effStart ? addWorkingDays(effStart, ownDays) : '';
                if (expEnd && expEnd === srvEnd) endHint = 'JSON matches the formula (' + _chkFmtDate(effStart) + ' + ' + ownDays + 'd); screen is stale — reload';
                else if (expEnd && expEnd === domEndIso) endHint = 'screen matches the formula (' + _chkFmtDate(effStart) + ' + ' + ownDays + 'd); the JSON end date is stale';
            }
            res(path, 'END DATE', dom.end || '(empty)', _chkFmtDate(srvEnd), false, endHint);
        }

        // WKNG DAYS
        var srvDur = (st._workingDays && st._workingDays > 0) ? st._workingDays : 0;
        if (isParent) {
            if (srvDur > 0) {
                res(path, 'WKNG DAYS', '(blank — parent row)', srvDur + 'd', false, 'parent rows store no duration; JSON value is leftover data');
            } else {
                res(path, 'WKNG DAYS', '(blank — parent row)', '(empty)', true);
            }
        } else {
            var domDurNum = parseInt((dom.dur || '').replace(/[^0-9]/g, ''), 10);
            if (isNaN(domDurNum)) domDurNum = 0;
            if (domDurNum === srvDur) {
                res(path, 'WKNG DAYS', dom.dur || '(empty)', srvDur > 0 ? srvDur + 'd' : '(empty)', true);
            } else {
                var durHint = 'JSON is the stored value';
                if (srvDur === 0 && domDurNum > 0) {
                    var spanNum = parseInt(calcDuration(st.startDate, st.endDate), 10) || 0;
                    if (domDurNum === spanNum) {
                        durHint = 'screen "' + domDurNum + 'd" is auto-computed from the dates; NOTHING is stored in JSON — if you typed it, the entry never saved';
                    } else {
                        durHint = 'nothing is stored in JSON; screen value is not saved';
                    }
                }
                res(path, 'WKNG DAYS', dom.dur || '(empty)', srvDur > 0 ? srvDur + 'd' : '(empty)', false, durHint);
            }
        }

        // Predecessor
        var srvPreds = [];
        if (st.predecessor) {
            srvPreds = Array.isArray(st.predecessor) ? st.predecessor : [st.predecessor];
        }
        function predLabels(ids) {
            if (!ids.length) return '(none)';
            var out = [];
            for (var li = 0; li < ids.length; li++) out.push(buildPredecessorLabel(ids[li]) || String(ids[li]));
            return out.join(', ');
        }
        if (_c2SameIdList(dom.preds, srvPreds)) {
            res(path, 'PREDECESSOR', predLabels(dom.preds), predLabels(srvPreds), true);
        } else {
            var predHint = isParent ? 'parent rows should have no predecessor' : 'JSON is the stored value';
            res(path, 'PREDECESSOR', predLabels(dom.preds), predLabels(srvPreds), false, predHint);
        }

        // % CMPLT / STATUS / ASSIGNED TO / COST — leaves only; parent rows
        // deliberately display these blank while JSON stores roll-ups.
        if (!isParent) {
            var domPct = parseInt(dom.pct, 10) || 0;
            var srvPct = parseInt(st.percentComplete, 10) || 0;
            res(path, '% CMPLT', String(domPct), String(srvPct), domPct === srvPct, domPct === srvPct ? '' : 'JSON is the stored value');

            var srvStatus = st.status || '';
            res(path, 'STATUS', dom.status || '(empty)', srvStatus || '(empty)', dom.status === srvStatus, dom.status === srvStatus ? '' : 'JSON is the stored value');

            var srvAssigned = (st.assignedTo || []).map(function (x) { return String(x); });
            res(path, 'ASSIGNED TO', dom.assigned.length ? dom.assigned.length + ' assignee(s)' : '(none)',
                srvAssigned.length ? srvAssigned.length + ' assignee(s)' : '(none)',
                _c2SameIdList(dom.assigned, srvAssigned),
                _c2SameIdList(dom.assigned, srvAssigned) ? '' : 'assignee lists differ; JSON is the stored value');

            var domCost = parseFloat(dom.cost) || 0;
            var srvCost = parseFloat(st.cost) || 0;
            res(path, 'COST', _chkFmtCost(domCost), _chkFmtCost(srvCost), Math.abs(domCost - srvCost) < 0.005,
                Math.abs(domCost - srvCost) < 0.005 ? '' : 'JSON is the stored value');
        }
    }

    // Rows on screen that are not in the server JSON
    for (var domId in domRows) {
        if (!seenIds[domId]) {
            var d = domRows[domId];
            res(d.name || '(unnamed row)', '(whole row)', 'shown on screen', 'NOT in JSON', false,
                'row exists on screen but not on the server (unsaved new row?)');
        }
    }
    return results;
}

function showCheck2Dialog(results, srvVersion) {
    var mismatches = 0;
    for (var i = 0; i < results.length; i++) if (!results[i].ok) mismatches++;

    var $overlay = $('<div class="dialog-overlay" id="check2-report-dialog">');
    var $box = $('<div class="dialog-box">');
    $box.append($('<div class="dialog-title">').html('<i class="fa fa-code-compare" style="color:#0E8A6D;margin-right:6px;"></i> Check2 — Screen vs Server JSON'));

    var $body = $('<div class="check-report-body">');
    var summary = results.length + ' comparisons — ' + (results.length - mismatches) + ' match, ' + mismatches + ' differ.'
        + (srvVersion ? ' (server version ' + srvVersion + ')' : '');
    if (mismatches === 0) {
        $body.append($('<div class="check-report-allgood">').html('<i class="fa fa-circle-check" style="margin-right:6px;"></i> ' + summary + ' Screen and server agree.'));
    } else {
        $body.append($('<div class="check-report-summary">').text(summary));
    }

    var $tbl = $('<table class="check-report-table">');
    $tbl.append($('<thead>').append(
        $('<tr>')
            .append($('<th>').text('SUBTASK'))
            .append($('<th>').text('COLUMN'))
            .append($('<th>').text('ON SCREEN'))
            .append($('<th>').text('IN JSON'))
            .append($('<th>').text(''))
            .append($('<th>').text('HINT'))
    ));
    var $tbody = $('<tbody>');
    // Differences first, then matches
    var ordered = results.filter(function (r) { return !r.ok; }).concat(results.filter(function (r) { return r.ok; }));
    for (var j = 0; j < ordered.length; j++) {
        var r = ordered[j];
        var $mark = r.ok
            ? $('<span style="color:#0E8A6D;font-weight:bold;">').html('&#10003;')
            : $('<span style="color:#C0392B;font-weight:bold;">').html('&#10007;');
        $tbody.append(
            $('<tr>')
                .append($('<td class="crt-item">').text(r.path))
                .append($('<td>').text(r.col))
                .append($('<td class="crt-curr">').text(r.screen != null ? String(r.screen) : ''))
                .append($('<td class="crt-exp">').text(r.server != null ? String(r.server) : ''))
                .append($('<td style="text-align:center;">').append($mark))
                .append($('<td class="crt-reason">').text(r.hint))
        );
    }
    $tbl.append($tbody);
    $body.append($tbl);

    $box.append($body);
    var $actions = $('<div class="dialog-actions">');
    var $close = $('<button class="dialog-btn-primary">Close</button>');
    $close.on('click', function () { $overlay.remove(); });
    $actions.append($close);
    $box.append($actions);
    $overlay.append($box);
    $('body').append($overlay);
}

$(document).on('click', '#btn-check2-data', function () {
    if (!isAssessmentProject() && !isExecutionProject()) return;
    if (!selectedTaskId) return;
    var $btn = $(this).prop('disabled', true);
    $.ajax({
        url: '/api/load-group',
        method: 'GET',
        data: { project: PROJ_NAME },
        dataType: 'json',
        timeout: 10000,
        success: function (resp) {
            $btn.prop('disabled', false);
            if (!(resp && resp.ok && resp.data && resp.data._taskData)) {
                alert('Could not fetch the project from the server.');
                return;
            }
            var srvTasks = resp.data._taskData.tasks || [];
            var srvTask = _c2FindById(selectedTaskId, srvTasks);
            if (!srvTask) {
                alert('This task (id ' + selectedTaskId + ') was not found in the server JSON.');
                return;
            }
            var results = runScreenVsServerCheck(srvTask, srvTasks);
            showCheck2Dialog(results, resp.version);
        },
        error: function () {
            $btn.prop('disabled', false);
            alert('Could not fetch the project from the server.');
        }
    });
});
```

**Note for production:** the code above assumes the same DOM structure as dev —
subtask rows in `#subtask-body`, cells tagged `data-field`/`data-id`,
predecessor chips `.pp-chip[data-pred-id]`, assignee chips
`.cp-chip[data-contact-id]`. If production's renderSubtaskTable differs, adapt
`_c2ScrapeDomRows()` accordingly; everything else is DOM-independent.

## 4. Known limitations (accepted)

- `/api/load-group` serves the server's **in-memory cache** (the authoritative
  live state); the disk file trails it by ~1 s after an edit. There is no
  endpoint that reads the literal file, and the cache is what every client
  sees, so it is the correct comparison target.
- Parent-row %, Status, Assigned To, Cost roll-ups are not compared (screen is
  deliberately blank there). The regular Check button already validates those
  roll-ups against the children.
- The subtask table renders 3 levels deep; deeper rows are reported as
  "not displayed" rather than compared.

## 5. How to verify after implementing

1. Open a task with subtasks → click **Check2** → dialog should report
   "N comparisons — N match, 0 differ" with the server version, all ✓.
2. Fake a screen-only value in DevTools:
   `document.querySelector('#subtask-body input[data-field="duration"][data-id="<someLeafId>"]').value = '75d'`
   → click Check2 → that row must appear FIRST with ✗ and hint
   "JSON is the stored value" (or the never-saved hint if the JSON stores 0).
   Reload to discard the fake.
3. Confirm the button is hidden for non-gs6368 users and on non-Assessment/
   Execution projects.
4. Confirm clicking Check2 writes nothing: the project's LOGS/<project>/<date>.log
   must get no new entries from the click.
