# Compare in-memory task data (DevTools) vs server JSON

Purpose: verify that what design.html holds in memory matches what the server
has persisted on disk. We ran this on the dev copy on 2026-07-18; this file
documents the exact procedure so it can be repeated on **production**, with
instructions for Claude (Opus 4.8) at the bottom.

---

## Background — why this comparison exists

- design.js keeps the whole project in a private in-memory array
  (`var tasks = []`, design.js:9), loaded from `/api/load-group` and mutated
  on every edit. Every edit is also patched to the server immediately
  (`sendPatch`), so **leaf fields** should always match the server.
- **Parent rollup fields do NOT reliably reach the server.** A parent's
  `endDate` is auto-derived (max of its children) by `syncParentEndDate`,
  but that function only runs for the task currently open in the detail
  pane — parents never opened keep a stale/blank `endDate` in the JSON.
- `_workingDays` in the JSON is never trusted: it is recomputed in memory
  from start/end dates and never written back (always 0 for top-level tasks
  and parents with children).

## Step 1 — expose the private array (one-time code change)

The `tasks` array lives inside `$(document).ready(...)`, so the DevTools
console cannot see it. Add this DEBUG block right after `var tasks = [];`
(design.js:9). It is a getter, so it stays correct even after project load
reassigns `tasks`:

```js
// DEBUG ONLY (safe to remove later): exposes the private in-memory task
// tree to the DevTools console as window.__tasks. Defined as a getter so
// it stays correct even after `tasks` is reassigned on project load.
Object.defineProperty(window, '__tasks', {
    get: function () { return tasks; },
    configurable: true
});
```

Note: a plain `window.__tasks = tasks;` does NOT work — project load
reassigns the variable and the hook would keep pointing at the original
empty array. It must be the getter.

## Step 2 — capture the memory dump

1. Open design.html in the browser and load the project you want to check.
2. Optional but recommended: click through the parents you care about once,
   so their rollups are recomputed in memory (memory only recomputes a
   parent's dates when it is rendered in the detail pane).
3. Open DevTools (F12) → Console, run:

   ```js
   copy(JSON.stringify(window.__tasks, null, 2))
   ```

4. Paste the clipboard into a new file `memory-dump.json` in the app root
   folder (next to design.js). The result is a JSON **array** of top-level
   tasks, each with nested `subtasks`.

## Step 3 — identify the matching server file

The server's live per-project file is `GROUP/<project-name>.json`
(see `DATA_DIR`/`GROUP_DIR` in the server .py). Its task tree is under
`_taskData.tasks`. Confirm you have the right project before diffing:
top-level task names and total node count should match the dump.

Do NOT diff against `BACKUPS/` files — those are periodic snapshots and can
be from an older dataset.

## Step 4 — run the diff

Save as `diff_mem_vs_json.py` next to the two files, adjust `SERVER_FILE`,
then `python diff_mem_vs_json.py`:

```python
import json

MEM_FILE    = 'memory-dump.json'
SERVER_FILE = 'GROUP/INTL_to_ITServices_Execution.json'   # <-- adjust per project

mem = json.load(open(MEM_FILE, encoding='utf-8'))
srv = json.load(open(SERVER_FILE, encoding='utf-8'))['_taskData']['tasks']

def index(tasks, path=''):
    out = {}
    for t in tasks:
        p = (path + ' > ' if path else '') + t.get('name', '?')
        out[t['id']] = (t, p)
        out.update(index(t.get('subtasks') or [], p))
    return out

M, S = index(mem), index(srv)

print('nodes: memory=%d server=%d' % (len(M), len(S)))
only_m = set(M) - set(S)
only_s = set(S) - set(M)
if only_m: print('only in MEMORY:', [M[i][1] for i in only_m])
if only_s: print('only in SERVER:', [S[i][1] for i in only_s])

SKIP = {'subtasks'}          # structure handled by the id index above
diffs = {}
for tid in sorted(set(M) & set(S), key=str):
    mt, mp = M[tid]
    st, _  = S[tid]
    for k in sorted(set(mt) | set(st)):
        if k in SKIP:
            continue
        mv, sv = mt.get(k), st.get(k)
        if mv != sv:
            diffs.setdefault(k, []).append((mp, mv, sv))

if not diffs:
    print('\nNO FIELD DIFFERENCES — memory and server JSON are identical.')
else:
    for k, rows in sorted(diffs.items(), key=lambda x: -len(x[1])):
        print('\n=== field %r differs on %d task(s) ===' % (k, len(rows)))
        for p, mv, sv in rows[:12]:
            print('  %-55s memory=%r  server=%r' % (p[:55], mv, sv))
        if len(rows) > 12:
            print('  ... and %d more' % (len(rows) - 12))
```

## Step 5 — interpret the results

| Finding | Meaning | Action |
|---|---|---|
| `comments` (or similar) `''` in memory vs missing/None on server | design.js initializes absent fields to empty strings | Ignore — cosmetic |
| Parent task `endDate`/`startDate` differs | Expected: server rollups go stale unless that parent was opened in the detail pane. Verify by computing max(children endDate) — memory should hold the derived value if the parent was viewed | No fix needed; consumers must derive rollups from leaves |
| **Leaf** task field differs | NOT expected — leaves are patched to the server on every edit. Could mean a lost patch (WebSocket down + AJAX failure) or another user edited after the dump was taken | Investigate; re-dump first to rule out timing |
| Node only in memory or only on server | Task added/deleted after the dump, or wrong project file | Re-dump and re-check project identity |
| `_workingDays` differs | Known-unreliable field, never written back | Ignore entirely |

Dev-run result (2026-07-18, INTL_to_ITServices_Execution, 87 nodes): all
leaves identical; 7 cosmetic `comments` diffs; exactly one stale parent
rollup (`IES > OS` server=2027-01-04, memory/derived=2027-01-01).

---

## Instructions for Claude (Opus 4.8) — production run

You are comparing the browser's in-memory task array against the server's
persisted JSON for the same project, on the production deployment.

1. **Do not modify production code yourself.** If `window.__tasks` is not
   available in production design.js, show the user the Step 1 getter block
   and let them decide how to deploy it. It is read-only and additive.
2. Ask the user for (a) the project name they had open, and (b) the
   `memory-dump.json` they captured via Step 2. Do not proceed without both.
3. Locate the server file: `GROUP/<project-name>.json`, task tree under
   `_taskData.tasks`. If the production layout differs, find `GROUP_DIR` in
   the server Python file rather than guessing. Never use `BACKUPS/` as the
   comparison target.
4. Sanity-check before diffing: same top-level task names, same total node
   count (±recent edits). If they clearly differ, stop and tell the user —
   wrong project or stale dump.
5. Run the Step 4 script unchanged (adjust file paths only). Read the whole
   output; if it is large, aggregate per field before reporting.
6. Report using the Step 5 table's categories, in this order:
   (a) leaf-field mismatches — these are the only real red flags;
   (b) stale parent rollups — expected, list them with the derived correct
       value (max of children);
   (c) cosmetic normalizations — one line, no detail needed.
7. For any stale parent rollup, verify the derived value yourself from the
   children in the SERVER file before declaring which side is correct.
8. Do not "fix" the server JSON. The agreed architecture is that consumers
   (e.g., timeline.js) trust only leaf `startDate`/`endDate` and derive all
   parent rollups and working-day counts themselves.
