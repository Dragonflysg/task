# Evaluating the Ticket Classifier (version 3)

This guide explains how to measure — with real numbers — how good the
classifier actually is, instead of eyeballing a handful of results.

## Is this "training an AI"? No.

GPT-5.1 is already trained and we never modify it. Nothing in this stage
updates the model. An **evaluation harness** is just a script that:

1. Takes historical tickets where the *correct* category is already known
   (because a human resolved them),
2. Asks the classifier to classify each one,
3. Compares the classifier's answer to the known-correct answer,
4. Prints statistics.

Think of it as a **mock exam with an answer key**. The model sits the exam;
you grade it. The only thing that "improves" over time is your **prompt**
(the instructions in `version2.py`), and *you* improve it by hand, guided by
the numbers the harness gives you. That loop — measure, tweak prompt,
measure again — is called *prompt engineering*, and it needs no training
infrastructure at all.

(For completeness: *fine-tuning* a model on your tickets is a real technique,
but it is expensive, needs thousands of examples, and is almost never needed
for a 5-category classifier. Don't go there unless prompt tuning plateaus
well below your accuracy target.)

## The workflow at a glance

```
Export historical tickets ──> labeled CSV ──> version3.py ──> report
                                                   ▲              │
                                                   │              ▼
                                          edit prompt in    read confusion
                                          version2.py  <──  matrix & metrics
```

`version3.py` imports `classify_ticket` from `version2.py`, so whenever you
edit the prompt in version2 and re-run version3, you are automatically
evaluating the *new* prompt.

---

## Step 1 — Build the labeled dataset

Export historical tickets from your ITSM tool (ServiceNow etc.) into a CSV.

**Rules that matter:**

- **Use the category as finally resolved, not as first entered.** If the
  Service Desk misfiles tickets and later corrects them, the *corrected*
  value is your answer key. A noisy answer key poisons every number.
- **Get enough of every category.** Aim for **30–50 tickets per category**
  (so roughly 150–300 total). If you export "the last 300 tickets" you may
  end up with 200 Hardware and 3 Distribution/Security Group — then your
  numbers for the rare categories are meaningless.
- **Keep real, messy examples.** Don't cherry-pick clean ones; the point is
  to see how the classifier handles reality (typos, jargon, vague one-liners).
- **De-duplicate** near-identical tickets (e.g. 40 copies of the same
  password-reset template) or they will dominate the score.

## Step 2 — CSV format

Three columns, with exactly these headers (see `labeled_tickets_sample.csv`
for a working example):

| column              | required | content                                   |
|---------------------|----------|-------------------------------------------|
| `short_description` | yes      | the ticket's short description             |
| `long_description`  | no (may be empty) | the ticket's long description     |
| `expected_category` | yes      | the known-correct category (answer key)    |

`expected_category` must be one of the categories defined in `version2.py`:
`Hardware`, `Accounts`, `Mailbox`, `Distribution/Security Group`, `Other`
(case doesn't matter; anything else is skipped with a warning).

If you build the CSV in Excel, save as **CSV UTF-8** — the script handles
the byte-order mark Excel adds.

## Step 3 — Smoke-test the harness (no API calls, free)

Before spending API calls, verify the plumbing with the built-in dry-run
mode, which uses a trivial keyword matcher instead of GPT-5.1:

```
python version3.py labeled_tickets_sample.csv --dry-run
```

You should see per-ticket progress lines, then a report with accuracy,
a confusion matrix, and the confidence tables. The sample file contains one
deliberately tricky row ("Email very slow to load") so you can see what a
misclassification looks like in the report.

## Step 4 — Run it for real

First a cheap test on 5 tickets to confirm the gateway call works:

```
python version3.py labeled_tickets.csv --limit 5
```

Then the full run (one API call per ticket; `--sleep` adds a pause between
calls if your gateway rate-limits):

```
python version3.py labeled_tickets.csv --sleep 0.5 --output eval_results.csv
```

- Progress prints per ticket; results are written to the output CSV
  **as they come in**, so a crash halfway doesn't lose everything.
- A failed API call is retried once, then recorded as `ERROR` and excluded
  from the metrics (the run keeps going).
- 300 tickets with a 0.5 s pause takes roughly 5–10 minutes.

## Step 5 — Reading the report

### Overall accuracy
The headline number: what fraction of tickets got the right category.

### Per-category precision / recall
- **Recall** for Hardware = of all *actual* Hardware tickets, how many did
  the classifier find? Low recall = it misses them.
- **Precision** for Hardware = of everything it *called* Hardware, how much
  really was? Low precision = it over-uses that label.

### Confusion matrix
Rows = the true category, columns = what the classifier said. The diagonal
is correct; everything off-diagonal is an error, and *where* the errors
cluster tells you what to fix. Example: a big number in row `Mailbox`,
column `Accounts` means mailbox tickets keep getting called Accounts —
so sharpen those two category definitions in the prompt, or add an example.

### Confidence calibration
Groups tickets by the confidence the model reported and shows the actual
accuracy inside each band. You want high-confidence bands to be near-perfect
and errors to concentrate in the low bands. If the 90–100 band is only 80%
correct, the model is over-confident and you cannot trust a "95".

### Threshold table (the business decision)
For each cutoff: if you auto-accepted every classification at or above that
confidence and sent the rest to a human, what share of tickets is automated
(**coverage**) and how accurate is the automated share? Pick the row that
matches your appetite, e.g. "at threshold 80 we auto-classify 74% of tickets
at 96% accuracy — good enough, ship it."

### The results CSV
Row-level detail: expected vs predicted, confidence, and the model's
one-sentence reasoning. **Read every wrong row.** The reasoning column
usually makes it obvious whether the prompt was unclear, the category
definitions overlap, or the ticket was genuinely ambiguous (sometimes the
"expected" label is the one that's wrong!).

## Step 6 — Iterate without fooling yourself

1. Run the harness → note the numbers.
2. Change ONE thing in the `version2.py` prompt (a category definition,
   an added example…).
3. Re-run on the **same CSV** → compare. Keep a simple log:

   | date | prompt change | accuracy | worst confusion |
   |------|---------------|----------|-----------------|
   | 2026-07-12 | baseline | 84% | Mailbox→Accounts (9) |
   | 2026-07-14 | sharpened Mailbox def | 89% | ... |

4. **Hold-out check.** After many rounds of tuning against the same tickets,
   the prompt can become over-fitted to them (great on this file, worse in
   production). Guard against it: shuffle your labeled CSV once and split it
   ~2/3 into `tuning.csv` and ~1/3 into `holdout.csv`. Do all your iterating
   on `tuning.csv`; when you think you're done, run `holdout.csv` **once** —
   that number is the honest one to report to management.

## What counts as "good"?

Don't chase 100% — humans don't hit it either. The realistic yardstick is:
**is the classifier at least as accurate as the Service Desk's current
first-touch categorization?** If you can estimate the human misfile rate
(e.g. from how often categories get corrected later), that's your bar.
Combined with the threshold table, the practical win is usually:
auto-classify the confident majority, route the uncertain minority to a
human — better than either one alone.

## Pitfalls checklist

- Answer key built from *initial* (uncorrected) categories → garbage metrics.
- Too few examples of a category → its precision/recall are noise.
- Tuning the prompt against the hold-out set → dishonest numbers.
- Changing the category list in `version2.py` without re-building the
  labeled CSV to match.
- Comparing runs made on different CSVs — only same-file runs are comparable.



Everything works end-to-end — the dry run above is exactly what your real report will look like. Three new files in C:\PROJECTS\CLASSIFIER:

- EVALUATION.md — the write-up you asked for: what an evaluation harness is, how to build the labeled dataset, how to test, how to read every section of the report, and how to iterate without fooling yourself.
- version3.py — the harness script. It imports classify_ticket from version2.py, so whenever you edit the prompt in version2, re-running version3 automatically evaluates the new prompt.
- labeled_tickets_sample.csv — a 13-ticket example showing the required CSV format (short_description, long_description, expected_category).

To your direct question: no, this does not train an AI. GPT-5.1 is never modified. The harness is a mock exam with an answer key — historical tickets whose correct category a human already confirmed get classified by your prompt, and the script grades the answers. The only thing that improves over time is your prompt, and you improve it by hand based on what the report tells you. (Fine-tuning a model is a real thing, but it's overkill for a 5-category classifier — the markdown explains when you'd ever consider it.)

How you test it, in order of cost:
1. python version3.py labeled_tickets_sample.csv --dry-run — free, no API calls; uses a built-in keyword matcher just to prove the plumbing and report work. I ran this above and it's green.
2. python version3.py labeled_tickets.csv --limit 5 — five real API calls to confirm the gateway works.
3. python version3.py labeled_tickets.csv --sleep 0.5 — the full run.

The report gives you five things: overall accuracy, per-category precision/recall, a confusion matrix (which categories get mixed up — that tells you what to fix in the prompt), confidence calibration (whether a "90" from version2 is actually right ~90% of the time), and a threshold table — the business view: "if we auto-accept everything at confidence ≥ 80 and send the rest to a human, we automate X% of tickets at Y% accuracy."

Note how the dry run already demonstrates the value: the one planted tricky ticket ("Email very slow to load") shows up instantly in the confusion matrix as Mailbox→Hardware, and precision/recall pinpoint the weak spots. With real data, that's how you'll know exactly which category definitions in the version2 prompt need sharpening.

Your only manual work is Step 1 in the markdown: exporting 150–300 historical tickets with their final corrected categories into the CSV. Row-level results (including the model's reasoning for every wrong answer) land in eval_results.csv as the run progresses, so a mid-run crash loses nothing.

##### this is me
 i ran the script which makes the test without API call and i saw it printed on the screen. am i suppose to make corrections on that CSV file so that it would benefit when it is used on the real API calls?
#####


No — nothing needs correcting from the dry run. Let me untangle what each piece is for, because there are two CSVs in play and neither should be "fixed" based on that test:

The dry run's WRONG row is intentional and meaningless. The dry run doesn't use GPT-5.1 at all — it uses a deliberately dumb keyword matcher built into version3.py, and I planted one ticket ("Email very slow to load") that the keyword matcher gets wrong on purpose, so you could see what a misclassification looks like in the report. Its only job was to prove the machinery works: reading the CSV, the progress lines, the confusion matrix, the results file. It proved that. You act on nothing from it.

The sample CSV is a format template, not your dataset. Don't correct or extend labeled_tickets_sample.csv — for the real run, you build your own file (e.g. labeled_tickets.csv) with the same three column headers, filled with 150–300 real historical tickets exported from your ITSM tool. That's the Step 1 work described in EVALUATION.md.

The one rule about the input CSV: the answer key must be true. The expected_category column is the exam's answer key, so the only "correction" that ever belongs there is making sure each ticket carries its genuinely correct category — the final one after any human correction, not what was first typed in. That correctness matters before you run, not in reaction to results.

When real API results come back with WRONG rows, you fix the prompt, not the CSV. If the model keeps calling Mailbox tickets "Accounts", the fix is sharpening those category definitions in version2.py, then re-running the same CSV to see if the number improved. The one exception: sometimes reading a wrong row reveals that your label was the mistake — the model was actually right and the ticket was misfiled in the export. Then yes, correct that row's expected_category. But never edit or delete rows just to make the score go up — at that point the exam stops measuring anything.

So your next concrete step is unchanged: export real tickets into your own labeled CSV, then python version3.py labeled_tickets.csv --limit 5 to confirm the gateway call works before the full run.