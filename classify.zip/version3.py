"""
version3.py - Stage 3: evaluation harness.

Runs the version2 classifier over a CSV of historical tickets whose correct
category is already known, then reports overall accuracy, per-category
precision/recall, a confusion matrix, confidence calibration, and an
auto-classification threshold table.

No training happens here - GPT-5.1 is never modified. This only MEASURES how
well the current version2 prompt classifies. See EVALUATION.md for the full
workflow and how to read the report.

Usage:
    python version3.py labeled_tickets_sample.csv --dry-run   (free smoke test)
    python version3.py labeled_tickets.csv --limit 5          (cheap API test)
    python version3.py labeled_tickets.csv --sleep 0.5        (full run)

Input CSV columns: short_description, long_description (optional),
expected_category. Row-level results are written to --output (default
eval_results.csv) as the run progresses.
"""

import argparse
import csv
import sys
import time

from version2 import CATEGORIES, classify_ticket

CALIBRATION_BANDS = [(90, 100), (70, 89), (40, 69), (0, 39)]
THRESHOLDS = [0, 50, 60, 70, 80, 90]

# Trivial keyword matcher used by --dry-run so the CSV plumbing and the
# report can be tested without any API calls. First match wins.
DRY_RUN_KEYWORDS = [
    ("Hardware", ["laptop", "desktop", "monitor", "printer", "dock", "slow"]),
    ("Mailbox", ["mailbox", "email", "outlook"]),
    ("Distribution/Security Group", ["distribution", "security group", " dl"]),
    ("Accounts", ["password", "login", "account", "mfa", "access"]),
]


def dry_run_classify(short_description, long_description=None):
    text = (short_description + " " + (long_description or "")).lower()
    for category, keywords in DRY_RUN_KEYWORDS:
        for keyword in keywords:
            if keyword in text:
                return {
                    "category": category,
                    "confidence": 90,
                    "reasoning": f"dry-run keyword match on {keyword!r}",
                }
    return {"category": "Other", "confidence": 30, "reasoning": "dry-run: no keyword matched"}


def load_tickets(path):
    """Read and validate the labeled CSV. Bad rows are skipped with a warning."""
    with open(path, newline="", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        fields = set(reader.fieldnames or [])
        missing = {"short_description", "expected_category"} - fields
        if missing:
            sys.exit(f"ERROR: {path} is missing required column(s): {', '.join(sorted(missing))}")

        tickets = []
        for line_no, row in enumerate(reader, start=2):
            short = (row.get("short_description") or "").strip()
            expected = (row.get("expected_category") or "").strip()
            long_ = (row.get("long_description") or "").strip() or None
            if not short or not expected:
                print(f"WARNING: line {line_no}: empty short_description or expected_category, skipped")
                continue
            canonical = next((c for c in CATEGORIES if c.lower() == expected.lower()), None)
            if canonical is None:
                print(f"WARNING: line {line_no}: unknown category {expected!r}, skipped")
                continue
            tickets.append({"short": short, "long": long_, "expected": canonical})
    return tickets


def run(tickets, classifier, out_path, sleep_seconds):
    """Classify every ticket, streaming row results to out_path as we go."""
    results = []
    fieldnames = [
        "short_description", "long_description", "expected_category",
        "predicted_category", "confidence", "correct", "reasoning",
    ]
    with open(out_path, "w", newline="", encoding="utf-8") as out:
        writer = csv.DictWriter(out, fieldnames=fieldnames)
        writer.writeheader()

        for i, ticket in enumerate(tickets, 1):
            try:
                answer = classifier(ticket["short"], ticket["long"])
            except Exception as first_error:
                print(f"  call failed ({first_error}), retrying in 5s...")
                time.sleep(5)
                try:
                    answer = classifier(ticket["short"], ticket["long"])
                except Exception as second_error:
                    answer = None
                    reasoning = f"API error: {second_error}"

            if answer is None:
                predicted, confidence, correct = "ERROR", None, None
            else:
                predicted = answer["category"]
                confidence = answer["confidence"]
                reasoning = answer["reasoning"]
                correct = predicted == ticket["expected"]

            results.append({
                "expected": ticket["expected"],
                "predicted": predicted,
                "confidence": confidence,
                "correct": correct,
            })
            writer.writerow({
                "short_description": ticket["short"],
                "long_description": ticket["long"] or "",
                "expected_category": ticket["expected"],
                "predicted_category": predicted,
                "confidence": "" if confidence is None else confidence,
                "correct": "" if correct is None else correct,
                "reasoning": reasoning,
            })
            out.flush()

            status = "OK" if correct else ("ERROR" if correct is None else "WRONG")
            conf_txt = "" if confidence is None else f" ({confidence})"
            print(f"[{i:>4}/{len(tickets)}] {ticket['short'][:35]!r:38} -> "
                  f"{predicted}{conf_txt}  expected {ticket['expected']}  {status}")

            if sleep_seconds:
                time.sleep(sleep_seconds)
    return results


def print_report(results):
    scored = [r for r in results if r["predicted"] != "ERROR"]
    n_errors = len(results) - len(scored)
    n = len(scored)
    if n == 0:
        print("\nNo scorable results (all calls failed).")
        return
    n_correct = sum(1 for r in scored if r["correct"])

    print("\n" + "=" * 62)
    print("OVERALL")
    print("=" * 62)
    print(f"Tickets scored : {n}" + (f"  (+{n_errors} API errors excluded)" if n_errors else ""))
    print(f"Accuracy       : {n_correct}/{n} = {n_correct / n:.1%}")

    print("\n" + "=" * 62)
    print("PER CATEGORY  (recall = found them, precision = trustable label)")
    print("=" * 62)
    print(f"{'Category':<30} {'N':>4} {'Precision':>10} {'Recall':>8}")
    for cat in CATEGORIES:
        n_expected = sum(1 for r in scored if r["expected"] == cat)
        n_predicted = sum(1 for r in scored if r["predicted"] == cat)
        true_pos = sum(1 for r in scored if r["expected"] == cat and r["predicted"] == cat)
        precision = f"{true_pos / n_predicted:.1%}" if n_predicted else "-"
        recall = f"{true_pos / n_expected:.1%}" if n_expected else "-"
        print(f"{cat:<30} {n_expected:>4} {precision:>10} {recall:>8}")

    print("\n" + "=" * 62)
    print("CONFUSION MATRIX  (rows = true category, columns = predicted)")
    print("=" * 62)
    codes = {cat: f"C{i + 1}" for i, cat in enumerate(CATEGORIES)}
    print(f"{'':<30}" + "".join(f"{codes[c]:>6}" for c in CATEGORIES))
    for expected in CATEGORIES:
        counts = [
            sum(1 for r in scored if r["expected"] == expected and r["predicted"] == predicted)
            for predicted in CATEGORIES
        ]
        print(f"{expected:<30}" + "".join(f"{c:>6}" for c in counts))
    print()
    for cat in CATEGORIES:
        print(f"  {codes[cat]} = {cat}")

    print("\n" + "=" * 62)
    print("CONFIDENCE CALIBRATION  (is a '90' really right ~90% of the time?)")
    print("=" * 62)
    print(f"{'Confidence band':<18} {'Tickets':>8} {'Accuracy':>10}")
    for low, high in CALIBRATION_BANDS:
        band = [r for r in scored if low <= r["confidence"] <= high]
        accuracy = f"{sum(1 for r in band if r['correct']) / len(band):.1%}" if band else "-"
        print(f"{f'{low}-{high}':<18} {len(band):>8} {accuracy:>10}")

    print("\n" + "=" * 62)
    print("THRESHOLD TABLE  (auto-accept at/above threshold, humans get the rest)")
    print("=" * 62)
    print(f"{'Threshold':<12} {'Coverage':>10} {'Accuracy of automated share':>30}")
    for threshold in THRESHOLDS:
        covered = [r for r in scored if r["confidence"] >= threshold]
        coverage = f"{len(covered) / n:.1%}"
        accuracy = f"{sum(1 for r in covered if r['correct']) / len(covered):.1%}" if covered else "-"
        print(f">= {threshold:<9} {coverage:>10} {accuracy:>30}")


def main():
    parser = argparse.ArgumentParser(description="Evaluate the version2 ticket classifier against labeled tickets.")
    parser.add_argument("csv_path", help="labeled tickets CSV (see EVALUATION.md for format)")
    parser.add_argument("--output", default="eval_results.csv", help="row-level results CSV (default: eval_results.csv)")
    parser.add_argument("--limit", type=int, default=None, help="only run the first N tickets")
    parser.add_argument("--sleep", type=float, default=0, help="seconds to wait between API calls")
    parser.add_argument("--dry-run", action="store_true", help="use a keyword matcher instead of the API (free plumbing test)")
    args = parser.parse_args()

    tickets = load_tickets(args.csv_path)
    if args.limit:
        tickets = tickets[: args.limit]
    if not tickets:
        sys.exit("ERROR: no usable tickets in the CSV.")

    classifier = dry_run_classify if args.dry_run else classify_ticket
    mode = "DRY RUN (keyword matcher, no API calls)" if args.dry_run else "GPT-5.1 via gateway"
    print(f"Evaluating {len(tickets)} tickets - {mode}\n")

    results = run(tickets, classifier, args.output, args.sleep)
    print_report(results)
    print(f"\nRow-level results written to {args.output} - read every WRONG row.")


if __name__ == "__main__":
    main()
