"""
version1.py - Stage 1: basic ticket classifier.

Sends the ticket's Short Description (and optionally the Long Description)
to GPT-5.1 through the internal REST gateway and returns exactly one
category name as a plain string.
"""

import json
import os

import requests

# Prefer an environment variable so the token never lands in source control.
ACCESS_TOKEN = os.environ.get("GENAI_ACCESS_TOKEN", "AB123456768XXXXXX")
URL = "https://SERVER.azure-api.net/stage/services/generativeai"

CATEGORIES = [
    "Hardware",
    "Accounts",
    "Mailbox",
    "Distribution/Security Group",
    "Other",
]

# Long descriptions can be entire email threads; cap what we send to keep
# token usage predictable. The signal is almost always near the top.
MAX_LONG_DESC_CHARS = 2000

SYSTEM_PROMPT = """You are a ticket classifier for an IT Service Desk.

Classify each ticket into exactly one of the following categories:
- Hardware
- Accounts
- Mailbox
- Distribution/Security Group
- Other

Rules:
- Respond with ONLY the category name, spelled exactly as shown above.
- Do not add punctuation, quotes, explanations, or any other text.
- If the ticket does not clearly fit any category, respond with: Other"""


def build_user_text(short_description, long_description=None):
    """Label each field so the model knows which is which."""
    parts = ["Short Description: " + short_description.strip()]
    if long_description and long_description.strip():
        parts.append(
            "Long Description: " + long_description.strip()[:MAX_LONG_DESC_CHARS]
        )
    return "\n\n".join(parts)


def extract_content(data):
    """
    Pull the assistant's text out of the gateway response.

    The standard OpenAI shape (choices[0].message.content) is tried first;
    API Management gateways sometimes wrap it, so a few common wrapper keys
    are also checked. If your gateway uses a different envelope, run once,
    look at the printed raw response, and adjust here.
    """
    if isinstance(data, str):
        return data
    if isinstance(data, dict):
        if "choices" in data:
            return data["choices"][0]["message"]["content"]
        for key in ("modelResponse", "response", "result", "data", "body"):
            if key in data:
                return extract_content(data[key])
    raise ValueError(
        "Could not find message content in response: " + json.dumps(data)[:500]
    )


def classify_ticket(short_description, long_description=None):
    """Return one of CATEGORIES for the given ticket descriptions."""
    payload = {
        "domainName": "Assistant",
        "modelName": "gpt-5.1",
        "modelPayload": {
            "messages": [
                {"role": "system", "content": SYSTEM_PROMPT},
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "text",
                            "text": build_user_text(short_description, long_description),
                        }
                    ],
                },
            ],
            "temperature": 0,
            "top_p": 0.95,
            "frequency_penalty": 0,
            "presence_penalty": 0,
            "max_tokens": 500,
            "stop": None,
        },
    }

    headers = {
        "Authorization": f"Bearer {ACCESS_TOKEN}",
        "Content-Type": "application/json",
    }
    response = requests.post(URL, headers=headers, json=payload, timeout=60)
    response.raise_for_status()

    answer = extract_content(response.json()).strip()

    # Guard against the model going off-script (extra words, wrong casing).
    for category in CATEGORIES:
        if category.lower() == answer.lower():
            return category
    print(f"WARNING: unexpected model output {answer!r}, falling back to 'Other'")
    return "Other"


if __name__ == "__main__":
    test_tickets = [
        ("Laptop very slow", None),
        ("Mailbox Access", None),
        ("Voice MACD", None),
        (
            "Add user to Finance DL",
            "Hi team, John Smith joined Finance last Monday and needs to be "
            "added to the Finance distribution list so he receives the "
            "monthly close reminders. Manager approved. Thanks!",
        ),
    ]

    for short_desc, long_desc in test_tickets:
        category = classify_ticket(short_desc, long_desc)
        print(f"{short_desc!r:40} -> {category}")
