
import json,requests

access_token = "AB123456768XXXXXX" 
url = "https://SERVER.azure-api.net/stage/services/generativeai"
payload = json.dumps({
    "domainName" : "Assistant"
    "modelName" : "gpt-5.1",
    "modelPayload" : {
        "messages": [
            {
                "role": "system",
                "content" : "You are a classifier"
            },
            {
                "role" : "user",
                "content" : [
                    {
                        "type" : "text",
                        "text" : "Classify the short description mentioned into one of the following categories : 'Hardware','Accounts','Mailbox','Distribution/Security Group' or 'Other'"
                    },
                    {
                        "type" : "text",
                        "text" : "My laptop is very slow"
                    }
                ]
            }
        ],
        "temperature": 0.2,
        "top_p" : 0.95,
        "frequency_penalty" : 0,
        "presence_penalty" : 0,
        "max_tokens" : 500,
        "stop" : None
    }
})

headers = {"Authorization" : f'Bearer {access_token}','Content-type': 'application/json'}
response = requests.post(url,headers=headers,data=payload)


