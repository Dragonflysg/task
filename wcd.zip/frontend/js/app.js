/**
 * Main application controller for the WCD Dashboard.
 * Manages state, controls, and orchestrates data loading + chart rendering.
 */
window.WCD = window.WCD || {};

WCD.App = (function () {
    // ── Application State ──────────────────────────────────
    const state = {
        countries: [],              // All available countries
        selectedCountries: ['AU'],  // Currently selected country codes
        fromDate: WCD.Utils.daysAgo(90),
        toDate: WCD.Utils.formatDate(new Date()),
        autoScale: true,
        showPatchTuesdays: true,
        dateRange: '90',            // Preset: 90, 180, 365, 730, custom
        // Cached data
        trendData: null,
        summaryData: null,
        rankingData: null,
        heatmapData: null,
        patchCycles: null,
        changesData: null,
    };

    // ── Initialization ─────────────────────────────────────

    async function init() {
        // Parse URL hash for deep-link
        const hash = WCD.Utils.parseHash();
        if (hash.country) state.selectedCountries = hash.country.split(',');
        if (hash.from) state.fromDate = hash.from;
        if (hash.to) state.toDate = hash.to;
        if (hash.range) state.dateRange = hash.range;
        if (hash.autoScale !== undefined) state.autoScale = hash.autoScale === 'true';

        // Load countries
        try {
            state.countries = await WCD.API.getCountries();
        } catch (e) {
            console.error('Failed to load countries:', e);
            showError('Cannot connect to API. Is the Flask server running on localhost:5000?');
            return;
        }

        // Setup UI controls
        setupControls();
        setupCollapsible();

        // Initial data load
        await loadAllData();
    }

    // ── Control Setup ──────────────────────────────────────

    function setupControls() {
        const $countrySelect = $('#country-select');
        const $addCountry = $('#add-country');
        const $dateRange = $('#date-range');
        const $fromDate = $('#from-date');
        const $toDate = $('#to-date');
        const $autoScale = $('#auto-scale');
        const $showPT = $('#show-patch-tuesdays');

        // Populate country dropdown
        $countrySelect.empty();
        state.countries.forEach(c => {
            $countrySelect.append(`<option value="${c.code}">${c.name}</option>`);
        });
        if (state.selectedCountries.length) {
            $countrySelect.val(state.selectedCountries[0]);
        }

        // Render initial country tags
        renderCountryTags();

        // Country selector change
        $countrySelect.on('change', function () {
            const code = $(this).val();
            if (!state.selectedCountries.includes(code)) {
                state.selectedCountries = [code, ...state.selectedCountries.filter(c => c !== code)];
                if (state.selectedCountries.length > 4) {
                    state.selectedCountries = state.selectedCountries.slice(0, 4);
                }
            } else {
                // Move to front (primary)
                state.selectedCountries = [code, ...state.selectedCountries.filter(c => c !== code)];
            }
            renderCountryTags();
            onStateChange();
        });

        // Add country button
        $addCountry.on('click', function () {
            const code = $countrySelect.val();
            if (code && !state.selectedCountries.includes(code)) {
                state.selectedCountries.push(code);
                renderCountryTags();
                onStateChange();
            }
        });

        // Date range preset
        $dateRange.val(state.dateRange);
        $dateRange.on('change', function () {
            state.dateRange = $(this).val();
            if (state.dateRange !== 'custom') {
                state.toDate = WCD.Utils.formatDate(new Date());
                state.fromDate = WCD.Utils.daysAgo(parseInt(state.dateRange));
                $fromDate.val(state.fromDate);
                $toDate.val(state.toDate);
            }
            onStateChange();
        });

        // Custom date inputs
        $fromDate.val(state.fromDate);
        $toDate.val(state.toDate);

        const onDateChange = WCD.Utils.debounce(function () {
            state.fromDate = $fromDate.val();
            state.toDate = $toDate.val();
            state.dateRange = 'custom';
            $dateRange.val('custom');
            onStateChange();
        }, 500);

        $fromDate.on('change', onDateChange);
        $toDate.on('change', onDateChange);

        // Auto-scale checkbox
        $autoScale.prop('checked', state.autoScale);
        $autoScale.on('change', function () {
            state.autoScale = $(this).is(':checked');
            onStateChange();
        });

        // Patch Tuesday toggle
        $showPT.prop('checked', state.showPatchTuesdays);
        $showPT.on('change', function () {
            state.showPatchTuesdays = $(this).is(':checked');
            onStateChange();
        });
    }

    function renderCountryTags() {
        const $container = $('#country-tags');
        $container.empty();
        state.selectedCountries.forEach((code, idx) => {
            const country = state.countries.find(c => c.code === code);
            const name = country ? country.name : code;
            const color = WCD.Utils.getCountryColor(code);
            const isPrimary = idx === 0;
            $container.append(`
                <span class="country-tag" style="border-color: ${color}; ${isPrimary ? 'background: ' + color + '20' : ''}">
                    <span style="color: ${color}">${code}</span>
                    ${state.selectedCountries.length > 1 ? `<span class="remove" data-code="${code}">&times;</span>` : ''}
                </span>
            `);
        });

        // Remove handler
        $container.find('.remove').on('click', function () {
            const code = $(this).data('code');
            state.selectedCountries = state.selectedCountries.filter(c => c !== code);
            if (state.selectedCountries.length === 0 && state.countries.length) {
                state.selectedCountries = [state.countries[0].code];
            }
            renderCountryTags();
            onStateChange();
        });
    }

    // ── Collapsible Sections ───────────────────────────────

    function setupCollapsible() {
        $('.section-header').on('click', function () {
            const $header = $(this);
            const $body = $header.next('.section-body');
            $header.toggleClass('collapsed');
            $body.toggleClass('collapsed');

            // Update hash with open sections
            updateHash();
        });

        // Default: sections 3, 5, 6 collapsed (technician sections)
        const hash = WCD.Utils.parseHash();
        const openSections = hash.sections ? hash.sections.split(',') : ['1', '2', '4'];

        $('.dashboard-section').each(function () {
            const id = $(this).data('section');
            if (!openSections.includes(String(id))) {
                $(this).find('.section-header').addClass('collapsed');
                $(this).find('.section-body').addClass('collapsed');
            }
        });
    }

    // ── Data Loading ───────────────────────────────────────

    async function loadAllData() {
        showLoading(true);

        try {
            const primary = state.selectedCountries[0];

            // Parallel data fetching
            const [summary, trend, ranking, heatmap, patchCycles, changes] = await Promise.all([
                WCD.API.getSummary(primary, state.toDate),
                WCD.API.getTrend(state.selectedCountries, state.fromDate, state.toDate),
                WCD.API.getRanking(state.toDate),
                WCD.API.getHeatmap(state.fromDate, state.toDate, state.dateRange > 365 ? 'month' : 'week'),
                WCD.API.getPatchCycles(primary, 12),
                WCD.API.getChanges(primary, state.fromDate, state.toDate, 0.5),
            ]);

            state.summaryData = summary;
            state.trendData = trend;
            state.rankingData = ranking;
            state.heatmapData = heatmap;
            state.patchCycles = patchCycles;
            state.changesData = changes;

            renderAll();
        } catch (e) {
            console.error('Data loading error:', e);
            showError('Failed to load data: ' + e.message);
        } finally {
            showLoading(false);
        }
    }

    // ── Rendering ──────────────────────────────────────────

    function renderAll() {
        const primary = state.selectedCountries[0];
        const autoScale = state.autoScale;

        // Section 1: KPI Cards + Gauge
        WCD.Charts.renderKPICards(state.summaryData);
        if (state.summaryData) {
            WCD.Charts.renderGauge(state.summaryData.overall_score);
        }

        // Section 2: Hero Trend + Non-Compliant + Platform Breakdown
        if (state.trendData) {
            WCD.Charts.renderHeroTrend(state.trendData, state.selectedCountries, state.fromDate, state.toDate, autoScale);
            WCD.Charts.renderNonCompliantCount(state.trendData, state.selectedCountries, autoScale);
            WCD.Charts.renderPlatformBreakdown(state.trendData, primary, autoScale);
        }

        // Section 3: Patch Cycle Analysis
        if (state.patchCycles) {
            WCD.Charts.renderPatchCycleOverlay(state.patchCycles);
            WCD.Charts.renderPatchRecoveryTime(state.patchCycles);
        }

        // Section 4: Country Comparison
        if (state.heatmapData) {
            WCD.Charts.renderCountryHeatmap(state.heatmapData, state.countries);
        }
        if (state.rankingData) {
            WCD.Charts.renderCountryRanking(state.rankingData);
            WCD.Charts.renderCountryRadar(state.rankingData, state.selectedCountries.slice(0, 4));
        }

        // Section 5: Drill-Down
        if (state.trendData) {
            WCD.Charts.renderCalendarHeatmap(state.trendData, primary);
        }
        if (state.changesData) {
            WCD.Charts.renderChangeTable(state.changesData);
        }

        // Section 6: Fleet Context
        if (state.trendData) {
            WCD.Charts.renderFleetTrend(state.trendData, primary, autoScale);
        }
        if (state.rankingData) {
            WCD.Charts.renderFleetScatter(state.rankingData);
        }

        updateHash();
    }

    // ── State Change Handler ───────────────────────────────

    const onStateChange = WCD.Utils.debounce(async function () {
        WCD.API.clearCache();
        WCD.Charts.destroyAll();
        await loadAllData();
    }, 300);

    // ── Daily Snapshot (clicked from calendar) ─────────────

    async function showDailySnapshot(date) {
        const primary = state.selectedCountries[0];
        try {
            const summary = await WCD.API.getSummary(primary, date);
            if (summary) {
                // Update the snapshot display
                const $info = $('#snapshot-info');
                $info.html(`
                    <span class="date">${WCD.Utils.formatDateDisplay(date)}</span>
                    <span>Overall: <b>${summary.overall_score.toFixed(2)}%</b></span>
                    <span>Fleet: <b>${summary.total_workstations.toLocaleString()}</b></span>
                    <span>Non-Compliant: <b class="delta-negative">${summary.non_compliant}</b></span>
                `);
                WCD.Charts.renderDailySnapshot(summary);

                // Scroll to snapshot section
                document.getElementById('daily-snapshot-container').scrollIntoView({ behavior: 'smooth' });

                // Make sure section 5 is expanded
                const $sec5 = $('[data-section="5"]');
                $sec5.find('.section-header').removeClass('collapsed');
                $sec5.find('.section-body').removeClass('collapsed');
            }
        } catch (e) {
            console.error('Failed to load snapshot:', e);
        }
    }

    // ── URL Hash ───────────────────────────────────────────

    function updateHash() {
        const openSections = [];
        $('.dashboard-section').each(function () {
            if (!$(this).find('.section-header').hasClass('collapsed')) {
                openSections.push($(this).data('section'));
            }
        });

        WCD.Utils.updateHash({
            country: state.selectedCountries.join(','),
            from: state.fromDate,
            to: state.toDate,
            range: state.dateRange,
            autoScale: state.autoScale,
            sections: openSections.join(','),
        });
    }

    // ── UI Helpers ─────────────────────────────────────────

    function showLoading(show) {
        if (show) {
            $('#loading-overlay').fadeIn(200);
        } else {
            $('#loading-overlay').fadeOut(200);
        }
    }

    function showError(message) {
        const $error = $('<div class="chart-card-full" style="text-align:center;padding:40px;color:var(--danger)"></div>');
        $error.html(`
            <i class="fa-solid fa-circle-exclamation" style="font-size:32px;margin-bottom:12px;display:block"></i>
            <p style="font-size:15px;margin-bottom:8px">${message}</p>
            <p class="text-muted text-sm">Run: <code>cd backend && pip install -r requirements.txt && python app.py</code></p>
        `);
        $('.dashboard-content').prepend($error);
    }

    // ── Public API ─────────────────────────────────────────

    return {
        init,
        state,
        showDailySnapshot,
        onStateChange,
    };
})();

// ── Bootstrap ──────────────────────────────────────────────
$(document).ready(function () {
    WCD.App.init();
});
