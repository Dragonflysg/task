/**
 * API client with caching for the WCD Dashboard.
 */
window.WCD = window.WCD || {};

WCD.API = (function () {
    const BASE_URL = 'http://localhost:5000/api';
    const cache = {};
    const CACHE_TTL = 5 * 60 * 1000; // 5 minutes

    function cacheKey(url) {
        return url;
    }

    function getCached(key) {
        const entry = cache[key];
        if (entry && (Date.now() - entry.time) < CACHE_TTL) {
            return entry.data;
        }
        return null;
    }

    function setCache(key, data) {
        cache[key] = { data: data, time: Date.now() };
    }

    async function fetchJSON(url) {
        const key = cacheKey(url);
        const cached = getCached(key);
        if (cached) return cached;

        const response = await fetch(url);
        if (!response.ok) {
            throw new Error(`API error: ${response.status} ${response.statusText}`);
        }
        const data = await response.json();
        setCache(key, data);
        return data;
    }

    return {
        clearCache() {
            Object.keys(cache).forEach(k => delete cache[k]);
        },

        async getCountries() {
            return fetchJSON(`${BASE_URL}/countries`);
        },

        async getSummary(country, date) {
            let url = `${BASE_URL}/summary?country=${encodeURIComponent(country)}`;
            if (date) url += `&date=${encodeURIComponent(date)}`;
            return fetchJSON(url);
        },

        async getTrend(countries, from, to) {
            const cc = Array.isArray(countries) ? countries.join(',') : countries;
            return fetchJSON(
                `${BASE_URL}/trend?country=${encodeURIComponent(cc)}&from=${encodeURIComponent(from)}&to=${encodeURIComponent(to)}`
            );
        },

        async getHeatmap(from, to, granularity) {
            granularity = granularity || 'week';
            return fetchJSON(
                `${BASE_URL}/heatmap?from=${encodeURIComponent(from)}&to=${encodeURIComponent(to)}&granularity=${granularity}`
            );
        },

        async getRanking(date) {
            return fetchJSON(`${BASE_URL}/ranking?date=${encodeURIComponent(date)}`);
        },

        async getPatchCycles(country, months) {
            months = months || 12;
            return fetchJSON(
                `${BASE_URL}/patch-cycles?country=${encodeURIComponent(country)}&months=${months}`
            );
        },

        async getChanges(country, from, to, threshold) {
            threshold = threshold || 0.5;
            return fetchJSON(
                `${BASE_URL}/changes?country=${encodeURIComponent(country)}&from=${encodeURIComponent(from)}&to=${encodeURIComponent(to)}&threshold=${threshold}`
            );
        }
    };
})();

