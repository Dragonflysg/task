/**
 * Utility functions for the WCD Dashboard.
 */
window.WCD = window.WCD || {};

WCD.Utils = {
    /**
     * Get the 2nd Tuesday of a given month (Patch Tuesday).
     */
    getPatchTuesday(year, month) {
        const first = new Date(year, month, 1);
        const dayOfWeek = first.getDay(); // 0=Sun, 1=Mon, 2=Tue
        let daysUntilTue = (2 - dayOfWeek + 7) % 7;
        const firstTue = new Date(year, month, 1 + daysUntilTue);
        return new Date(firstTue.getTime() + 7 * 86400000); // 2nd Tuesday
    },

    /**
     * Get all Patch Tuesdays between two dates.
     */
    getPatchTuesdays(fromDate, toDate) {
        const result = [];
        const from = new Date(fromDate);
        const to = new Date(toDate);
        let current = new Date(from.getFullYear(), from.getMonth(), 1);
        const end = new Date(to.getFullYear(), to.getMonth() + 2, 1);

        while (current < end) {
            const pt = this.getPatchTuesday(current.getFullYear(), current.getMonth());
            if (pt >= from && pt <= to) {
                result.push(pt);
            }
            current.setMonth(current.getMonth() + 1);
        }
        return result;
    },

    /**
     * Format a date as YYYY-MM-DD.
     */
    formatDate(date) {
        if (typeof date === 'string') return date;
        const d = new Date(date);
        return d.getFullYear() + '-' +
            String(d.getMonth() + 1).padStart(2, '0') + '-' +
            String(d.getDate()).padStart(2, '0');
    },

    /**
     * Format a date for display (e.g., "Mar 17, 2026").
     */
    formatDateDisplay(date) {
        const d = new Date(date);
        const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
                        'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        return `${months[d.getMonth()]} ${d.getDate()}, ${d.getFullYear()}`;
    },

    /**
     * Get a date N days ago.
     */
    daysAgo(n) {
        const d = new Date();
        d.setDate(d.getDate() - n);
        return this.formatDate(d);
    },

    /**
     * Compute delta between two values with formatting.
     */
    formatDelta(value) {
        const sign = value >= 0 ? '+' : '';
        return `${sign}${value.toFixed(2)}%`;
    },

    /**
     * Get CSS class for a compliance score.
     */
    scoreClass(score) {
        if (score >= 99) return 'score-excellent';
        if (score >= 97) return 'score-good';
        if (score >= 95) return 'score-warning';
        return 'score-critical';
    },

    /**
     * Get color for a compliance score (for heatmaps).
     */
    scoreColor(score) {
        // Map 90-100 range to red-yellow-green
        const pct = Math.max(0, Math.min(1, (score - 90) / 10));
        if (pct < 0.5) {
            // Red to Yellow
            const t = pct * 2;
            const r = 220;
            const g = Math.round(60 + 160 * t);
            const b = 60;
            return `rgb(${r},${g},${b})`;
        } else {
            // Yellow to Green
            const t = (pct - 0.5) * 2;
            const r = Math.round(220 - 180 * t);
            const g = Math.round(220 - 30 * t);
            const b = Math.round(60 + 60 * t);
            return `rgb(${r},${g},${b})`;
        }
    },

    /**
     * Debounce a function call.
     */
    debounce(fn, delay) {
        let timer;
        return function (...args) {
            clearTimeout(timer);
            timer = setTimeout(() => fn.apply(this, args), delay);
        };
    },

    /**
     * Parse URL hash parameters.
     */
    parseHash() {
        const hash = window.location.hash.substring(1);
        const params = {};
        hash.split('&').forEach(pair => {
            const [key, value] = pair.split('=');
            if (key) params[decodeURIComponent(key)] = decodeURIComponent(value || '');
        });
        return params;
    },

    /**
     * Update URL hash with parameters.
     */
    updateHash(params) {
        const pairs = Object.entries(params)
            .filter(([, v]) => v !== undefined && v !== null && v !== '')
            .map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(v)}`);
        window.location.hash = pairs.join('&');
    },

    /**
     * Generate color palette for multi-country charts.
     */
    countryColors: {
        AU: '#2E93fA', US: '#66DA26', UK: '#546E7A', DE: '#E91E63',
        JP: '#FF9800', BR: '#00BCD4', IN: '#9C27B0', FR: '#3F51B5',
        SG: '#4CAF50', ZA: '#FF5722', CA: '#795548', MX: '#607D8B'
    },

    getCountryColor(code) {
        return this.countryColors[code] || '#999999';
    }
};

