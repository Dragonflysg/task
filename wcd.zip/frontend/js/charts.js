/**
 * Chart configurations and rendering for the WCD Dashboard.
 * Uses ApexCharts for all visualizations.
 */
window.WCD = window.WCD || {};

WCD.Charts = (function () {
    // Store chart instances for cleanup/sync
    const instances = {};

    // ── Common options ──────────────────────────────────────

    function baseOptions() {
        return {
            chart: {
                fontFamily: "'Inter', -apple-system, BlinkMacSystemFont, sans-serif",
                toolbar: { show: true, tools: { download: true, zoom: true, zoomin: true, zoomout: true, pan: true, reset: true } },
                animations: { enabled: true, easing: 'easeinout', speed: 400 },
                background: 'transparent',
            },
            theme: { mode: 'dark' },
            tooltip: { theme: 'dark', x: { format: 'MMM dd, yyyy' } },
            grid: { borderColor: '#2a2a3e', strokeDashArray: 3 },
            colors: ['#6366f1', '#22d3ee', '#f59e0b', '#ef4444', '#10b981', '#8b5cf6'],
        };
    }

    /**
     * Build Patch Tuesday annotation lines for a date range.
     */
    function patchTuesdayAnnotations(fromDate, toDate) {
        if (!WCD.App || !WCD.App.state.showPatchTuesdays) return [];
        const pts = WCD.Utils.getPatchTuesdays(fromDate, toDate);
        return pts.map(pt => ({
            x: pt.getTime(),
            borderColor: '#a855f7',
            strokeDashArray: 4,
            label: {
                text: 'PT',
                orientation: 'horizontal',
                borderColor: '#a855f7',
                style: { color: '#fff', background: '#a855f7', fontSize: '10px', padding: { left: 4, right: 4, top: 2, bottom: 2 } }
            }
        }));
    }

    /**
     * Get Y-axis config respecting auto-scale setting.
     */
    function yAxisConfig(label, autoScale) {
        if (autoScale) {
            return { title: { text: label, style: { color: '#94a3b8' } }, labels: { style: { colors: '#94a3b8' }, formatter: v => v != null ? v.toFixed(2) + '%' : '' }, forceNiceScale: true };
        }
        return { title: { text: label, style: { color: '#94a3b8' } }, min: 0, max: 100, labels: { style: { colors: '#94a3b8' }, formatter: v => v != null ? v.toFixed(1) + '%' : '' } };
    }

    // ── Section 1: KPI Score Cards ─────────────────────────

    function renderKPICards(summary) {
        const container = document.getElementById('kpi-cards');
        if (!container || !summary) return;

        const metrics = [
            { key: 'overall_score', label: 'Overall', icon: 'fa-shield-halved' },
            { key: 'sentinelone', label: 'SentinelOne', icon: 'fa-virus-slash' },
            { key: 'inventory', label: 'Inventory', icon: 'fa-boxes-stacked' },
            { key: 'mspatches', label: 'MS Patches', icon: 'fa-download' },
            { key: 'winbuild', label: 'Win Build', icon: 'fa-windows' },
            { key: 'total_workstations', label: 'Fleet Size', icon: 'fa-computer', isCount: true },
            { key: 'non_compliant', label: 'Non-Compliant', icon: 'fa-triangle-exclamation', isCount: true, invert: true },
        ];

        container.innerHTML = metrics.map(m => {
            const value = summary[m.key];
            const scoreClass = m.isCount ? '' : WCD.Utils.scoreClass(value);
            const displayValue = m.isCount ? value.toLocaleString() : value.toFixed(2) + '%';

            // Sparkline data
            const sparkData = m.key === 'non_compliant' ? summary.sparkline_nc :
                              m.key === 'overall_score' ? summary.sparkline : null;

            return `
                <div class="kpi-card ${scoreClass} ${m.invert ? 'invert' : ''}">
                    <div class="kpi-icon"><i class="fa-solid ${m.icon}"></i></div>
                    <div class="kpi-value">${displayValue}</div>
                    <div class="kpi-label">${m.label}</div>
                    ${sparkData ? `<div class="kpi-spark" id="spark-${m.key}"></div>` : ''}
                </div>
            `;
        }).join('');

        // Render sparklines
        metrics.forEach(m => {
            const sparkData = m.key === 'non_compliant' ? summary.sparkline_nc :
                              m.key === 'overall_score' ? summary.sparkline : null;
            if (!sparkData) return;
            const el = document.getElementById(`spark-${m.key}`);
            if (!el) return;
            new ApexCharts(el, {
                chart: { type: 'line', height: 30, width: 100, sparkline: { enabled: true }, animations: { enabled: false } },
                series: [{ data: sparkData }],
                stroke: { width: 1.5, curve: 'smooth' },
                colors: [m.invert ? '#ef4444' : '#6366f1'],
                tooltip: { enabled: false },
            }).render();
        });
    }

    // ── Section 1.2: Compliance Gauge ──────────────────────

    function renderGauge(score) {
        destroyChart('gauge');
        const el = document.getElementById('chart-gauge');
        if (!el) return;

        const chart = new ApexCharts(el, {
            ...baseOptions(),
            chart: { ...baseOptions().chart, type: 'radialBar', height: 220 },
            series: [score],
            plotOptions: {
                radialBar: {
                    startAngle: -135, endAngle: 135,
                    hollow: { size: '60%' },
                    track: { background: '#1e1e2e', strokeWidth: '100%' },
                    dataLabels: {
                        name: { show: true, offsetY: -10, color: '#94a3b8', fontSize: '13px' },
                        value: { color: '#e2e8f0', fontSize: '28px', fontWeight: 700, formatter: v => v.toFixed(2) + '%' }
                    }
                }
            },
            fill: {
                type: 'gradient',
                gradient: {
                    shade: 'dark', type: 'horizontal',
                    gradientToColors: [score >= 98 ? '#10b981' : score >= 96 ? '#f59e0b' : '#ef4444'],
                    stops: [0, 100]
                }
            },
            labels: ['Compliance'],
        });
        chart.render();
        instances['gauge'] = chart;
    }

    // ── Section 2.1: Hero Trend Chart + Brush ──────────────

    function renderHeroTrend(trendData, countries, fromDate, toDate, autoScale) {
        destroyChart('hero-trend');
        destroyChart('hero-brush');
        const el = document.getElementById('chart-hero-trend');
        const brushEl = document.getElementById('chart-hero-brush');
        if (!el) return;

        const series = countries.map(cc => ({
            name: cc,
            data: (trendData[cc] || []).map(r => ({ x: new Date(r.date).getTime(), y: r.overall_score }))
        }));

        const colors = countries.map(cc => WCD.Utils.getCountryColor(cc));
        const annotations = patchTuesdayAnnotations(fromDate, toDate);

        const mainOpts = {
            ...baseOptions(),
            chart: {
                ...baseOptions().chart,
                id: 'hero-trend',
                type: 'line',
                height: 320,
                group: 'sync',
                toolbar: { autoSelected: 'zoom' },
            },
            series: series,
            colors: colors,
            stroke: { width: 2, curve: 'smooth' },
            xaxis: {
                type: 'datetime',
                labels: { style: { colors: '#94a3b8' } },
            },
            yaxis: yAxisConfig('Compliance %', autoScale),
            annotations: { xaxis: annotations },
            legend: { show: countries.length > 1, position: 'top', labels: { colors: '#94a3b8' } },
        };

        const mainChart = new ApexCharts(el, mainOpts);
        mainChart.render();
        instances['hero-trend'] = mainChart;

        // Brush / range selector
        if (brushEl) {
            const brushOpts = {
                ...baseOptions(),
                chart: {
                    ...baseOptions().chart,
                    id: 'hero-brush',
                    type: 'area',
                    height: 100,
                    brush: { target: 'hero-trend', enabled: true },
                    selection: {
                        enabled: true,
                        xaxis: {
                            min: new Date(fromDate).getTime(),
                            max: new Date(toDate).getTime()
                        }
                    },
                },
                series: series,
                colors: colors,
                stroke: { width: 1 },
                fill: { type: 'gradient', gradient: { opacityFrom: 0.3, opacityTo: 0.1 } },
                xaxis: { type: 'datetime', labels: { style: { colors: '#94a3b8' } }, tooltip: { enabled: false } },
                yaxis: { show: false, min: 88, max: 100 },
                legend: { show: false },
            };
            const brushChart = new ApexCharts(brushEl, brushOpts);
            brushChart.render();
            instances['hero-brush'] = brushChart;
        }
    }

    // ── Section 2.2: Non-Compliant Count ───────────────────

    function renderNonCompliantCount(trendData, countries, autoScale) {
        destroyChart('non-compliant');
        const el = document.getElementById('chart-non-compliant');
        if (!el) return;

        const series = countries.map(cc => ({
            name: cc,
            data: (trendData[cc] || []).map(r => ({ x: new Date(r.date).getTime(), y: r.non_compliant }))
        }));

        const colors = countries.map(cc => WCD.Utils.getCountryColor(cc));

        const chart = new ApexCharts(el, {
            ...baseOptions(),
            chart: { ...baseOptions().chart, type: 'area', height: 200, group: 'sync' },
            series: series,
            colors: colors,
            stroke: { width: 2, curve: 'smooth' },
            fill: { type: 'gradient', gradient: { opacityFrom: 0.4, opacityTo: 0.05 } },
            xaxis: { type: 'datetime', labels: { style: { colors: '#94a3b8' } } },
            yaxis: {
                title: { text: 'Non-Compliant Count', style: { color: '#94a3b8' } },
                labels: { style: { colors: '#94a3b8' } },
                forceNiceScale: true,
            },
            legend: { show: countries.length > 1, position: 'top', labels: { colors: '#94a3b8' } },
        });
        chart.render();
        instances['non-compliant'] = chart;
    }

    // ── Section 2.3: Platform Breakdown ────────────────────

    function renderPlatformBreakdown(trendData, country, autoScale) {
        const platforms = [
            { key: 'sentinelone', label: 'SentinelOne', color: '#6366f1' },
            { key: 'inventory', label: 'Inventory', color: '#22d3ee' },
            { key: 'mspatches', label: 'MS Patches', color: '#f59e0b' },
            { key: 'winbuild', label: 'Win Build', color: '#10b981' },
        ];

        platforms.forEach(p => {
            const chartId = `platform-${p.key}`;
            destroyChart(chartId);
            const el = document.getElementById(`chart-${chartId}`);
            if (!el) return;

            const data = (trendData[country] || []).map(r => ({
                x: new Date(r.date).getTime(),
                y: r[p.key]
            }));

            const chart = new ApexCharts(el, {
                ...baseOptions(),
                chart: { ...baseOptions().chart, type: 'line', height: 120, group: 'sync', toolbar: { show: false } },
                series: [{ name: p.label, data: data }],
                colors: [p.color],
                stroke: { width: 2, curve: 'smooth' },
                xaxis: { type: 'datetime', labels: { show: false }, axisBorder: { show: false }, axisTicks: { show: false } },
                yaxis: yAxisConfig('', autoScale),
                title: { text: p.label, align: 'left', style: { fontSize: '12px', color: '#94a3b8' } },
                legend: { show: false },
            });
            chart.render();
            instances[chartId] = chart;
        });
    }

    // ── Section 3.1: Patch Cycle Overlay ───────────────────

    function renderPatchCycleOverlay(cycles) {
        destroyChart('patch-overlay');
        const el = document.getElementById('chart-patch-overlay');
        if (!el || !cycles.length) return;

        const totalCycles = cycles.length;
        const series = cycles.map((cycle, idx) => ({
            name: cycle.label,
            data: cycle.days.map(d => ({ x: d.day, y: d.mspatches }))
        }));

        // Color gradient: light (oldest) to dark (newest)
        const colors = cycles.map((_, idx) => {
            const t = totalCycles <= 1 ? 1 : idx / (totalCycles - 1);
            const r = Math.round(200 - 120 * t);
            const g = Math.round(180 - 120 * t);
            const b = Math.round(255 - 60 * t);
            return `rgb(${r},${g},${b})`;
        });

        const chart = new ApexCharts(el, {
            ...baseOptions(),
            chart: { ...baseOptions().chart, type: 'line', height: 350 },
            series: series,
            colors: colors,
            stroke: { width: cycles.map((_, i) => i === cycles.length - 1 ? 3 : 1.5), curve: 'smooth' },
            xaxis: {
                title: { text: 'Days after Patch Tuesday', style: { color: '#94a3b8' } },
                labels: { style: { colors: '#94a3b8' } },
                tickAmount: 7,
            },
            yaxis: yAxisConfig('MS Patches %', true),
            legend: { position: 'right', labels: { colors: '#94a3b8' }, fontSize: '11px' },
            title: { text: 'Patch Cycle Recovery Overlay', align: 'left', style: { fontSize: '14px', color: '#e2e8f0' } },
        });
        chart.render();
        instances['patch-overlay'] = chart;
    }

    // ── Section 3.2: Patch Recovery Time ───────────────────

    function renderPatchRecoveryTime(cycles, targetScore) {
        destroyChart('patch-recovery');
        const el = document.getElementById('chart-patch-recovery');
        if (!el || !cycles.length) return;

        targetScore = targetScore || 97;

        const data = cycles.map(cycle => {
            // Find first day score returns to target
            const recoveryDay = cycle.days.find(d => d.day > 2 && d.mspatches >= targetScore);
            return {
                x: cycle.label,
                y: recoveryDay ? recoveryDay.day : 28, // 28 = didn't recover
            };
        });

        const chart = new ApexCharts(el, {
            ...baseOptions(),
            chart: { ...baseOptions().chart, type: 'bar', height: 350 },
            series: [{ name: 'Recovery Days', data: data }],
            colors: ['#a855f7'],
            plotOptions: { bar: { borderRadius: 4, horizontal: false, columnWidth: '60%' } },
            xaxis: { labels: { style: { colors: '#94a3b8' }, rotate: -45 } },
            yaxis: { title: { text: 'Days to Recovery', style: { color: '#94a3b8' } }, labels: { style: { colors: '#94a3b8' } } },
            title: { text: `Days to Recover to ${targetScore}%`, align: 'left', style: { fontSize: '14px', color: '#e2e8f0' } },
            annotations: {
                yaxis: [{ y: 14, borderColor: '#ef4444', strokeDashArray: 4, label: { text: 'SLA: 14 days', borderColor: '#ef4444', style: { color: '#fff', background: '#ef4444' } } }]
            },
        });
        chart.render();
        instances['patch-recovery'] = chart;
    }

    // ── Section 4.1: Country Heatmap ───────────────────────

    function renderCountryHeatmap(heatmapData, countries) {
        destroyChart('country-heatmap');
        const el = document.getElementById('chart-country-heatmap');
        if (!el || !heatmapData.length) return;

        // Organize data: rows = countries, cols = periods
        const countryMap = {};
        countries.forEach(c => { countryMap[c.code] = c.name; });

        const periods = [...new Set(heatmapData.map(d => d.period))].sort();
        const countryList = [...new Set(heatmapData.map(d => d.country))].sort();

        const series = countryList.map(cc => ({
            name: countryMap[cc] || cc,
            data: periods.map(p => {
                const entry = heatmapData.find(d => d.country === cc && d.period === p);
                return { x: p, y: entry ? entry.score : null };
            })
        }));

        const chart = new ApexCharts(el, {
            ...baseOptions(),
            chart: { ...baseOptions().chart, type: 'heatmap', height: Math.max(300, countryList.length * 30) },
            series: series,
            dataLabels: { enabled: true, style: { fontSize: '10px', colors: ['#1a1a2e'] } },
            plotOptions: {
                heatmap: {
                    shadeIntensity: 0,
                    colorScale: {
                        ranges: [
                            { from: 0, to: 94.99, color: '#ef4444', name: '< 95%' },
                            { from: 95, to: 96.99, color: '#f59e0b', name: '95-97%' },
                            { from: 97, to: 98.49, color: '#22d3ee', name: '97-98.5%' },
                            { from: 98.5, to: 99.49, color: '#6366f1', name: '98.5-99.5%' },
                            { from: 99.5, to: 100, color: '#10b981', name: '> 99.5%' },
                        ]
                    }
                }
            },
            xaxis: { labels: { style: { colors: '#94a3b8' }, rotate: -45, rotateAlways: true } },
            yaxis: { labels: { style: { colors: '#94a3b8' } } },
            title: { text: 'Compliance by Country & Period', align: 'left', style: { fontSize: '14px', color: '#e2e8f0' } },
        });
        chart.render();
        instances['country-heatmap'] = chart;
    }

    // ── Section 4.2: Country Ranking ───────────────────────

    function renderCountryRanking(rankingData) {
        destroyChart('country-ranking');
        const el = document.getElementById('chart-country-ranking');
        if (!el || !rankingData.length) return;

        const chart = new ApexCharts(el, {
            ...baseOptions(),
            chart: { ...baseOptions().chart, type: 'bar', height: Math.max(300, rankingData.length * 32) },
            series: [{ name: 'Compliance', data: rankingData.map(r => ({ x: r.country_name, y: r.overall_score })) }],
            colors: ['#6366f1'],
            plotOptions: {
                bar: {
                    horizontal: true, borderRadius: 4, barHeight: '65%',
                    dataLabels: { position: 'top' },
                    colors: {
                        ranges: [
                            { from: 0, to: 95, color: '#ef4444' },
                            { from: 95, to: 97, color: '#f59e0b' },
                            { from: 97, to: 99, color: '#6366f1' },
                            { from: 99, to: 100, color: '#10b981' },
                        ]
                    }
                }
            },
            xaxis: {
                min: Math.max(90, Math.min(...rankingData.map(r => r.overall_score)) - 1),
                max: 100,
                labels: { style: { colors: '#94a3b8' }, formatter: v => v.toFixed(1) + '%' }
            },
            yaxis: { labels: { style: { colors: '#94a3b8' } } },
            dataLabels: { enabled: true, formatter: v => v.toFixed(2) + '%', style: { fontSize: '11px' }, offsetX: 30 },
            title: { text: 'Country Ranking', align: 'left', style: { fontSize: '14px', color: '#e2e8f0' } },
        });
        chart.render();
        instances['country-ranking'] = chart;
    }

    // ── Section 4.3: Country Radar ─────────────────────────

    function renderCountryRadar(rankingData, selectedCountries) {
        destroyChart('country-radar');
        const el = document.getElementById('chart-country-radar');
        if (!el || !selectedCountries.length) return;

        const platforms = ['sentinelone', 'inventory', 'mspatches', 'winbuild'];
        const labels = ['SentinelOne', 'Inventory', 'MS Patches', 'Win Build'];

        const series = selectedCountries.map(cc => {
            const row = rankingData.find(r => r.country === cc);
            return {
                name: row ? row.country_name : cc,
                data: platforms.map(p => row ? row[p] : 0)
            };
        });

        const colors = selectedCountries.map(cc => WCD.Utils.getCountryColor(cc));

        const chart = new ApexCharts(el, {
            ...baseOptions(),
            chart: { ...baseOptions().chart, type: 'radar', height: 350, toolbar: { show: false } },
            series: series,
            colors: colors,
            xaxis: { categories: labels, labels: { style: { colors: '#94a3b8', fontSize: '12px' } } },
            yaxis: { min: 90, max: 100, tickAmount: 5, labels: { style: { colors: '#94a3b8' }, formatter: v => v.toFixed(0) + '%' } },
            stroke: { width: 2 },
            fill: { opacity: 0.15 },
            markers: { size: 3 },
            legend: { position: 'bottom', labels: { colors: '#94a3b8' } },
            title: { text: 'Platform Comparison', align: 'left', style: { fontSize: '14px', color: '#e2e8f0' } },
        });
        chart.render();
        instances['country-radar'] = chart;
    }

    // ── Section 5.1: Calendar Heatmap ──────────────────────

    function renderCalendarHeatmap(trendData, country) {
        const container = document.getElementById('calendar-heatmap');
        if (!container) return;

        const data = trendData[country] || [];
        if (!data.length) { container.innerHTML = '<p class="text-muted">No data</p>'; return; }

        // Build a simple CSS-based calendar grid (365 days)
        // Taking last 365 days of data
        const recent = data.slice(-365);
        const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

        let html = '<div class="cal-heatmap-container"><div class="cal-grid">';
        recent.forEach(r => {
            const color = WCD.Utils.scoreColor(r.overall_score);
            const dt = new Date(r.date);
            const tip = `${WCD.Utils.formatDateDisplay(r.date)}: ${r.overall_score.toFixed(2)}%`;
            html += `<div class="cal-cell" style="background:${color}" title="${tip}" data-date="${r.date}"></div>`;
        });
        html += '</div>';

        // Month labels
        html += '<div class="cal-months">';
        let lastMonth = -1;
        recent.forEach((r, i) => {
            const dt = new Date(r.date);
            if (dt.getMonth() !== lastMonth) {
                lastMonth = dt.getMonth();
                const left = (i / recent.length) * 100;
                html += `<span style="left:${left}%">${months[lastMonth]}</span>`;
            }
        });
        html += '</div>';

        // Legend
        html += '<div class="cal-legend"><span>Lower</span>';
        [92, 94, 96, 97, 98, 99, 100].forEach(v => {
            html += `<div class="cal-cell" style="background:${WCD.Utils.scoreColor(v)}" title="${v}%"></div>`;
        });
        html += '<span>Higher</span></div></div>';

        container.innerHTML = html;

        // Click handler for drill-down
        $(container).on('click', '.cal-cell[data-date]', function () {
            const date = $(this).data('date');
            if (WCD.App) WCD.App.showDailySnapshot(date);
        });
    }

    // ── Section 5.2: Daily Snapshot ────────────────────────

    function renderDailySnapshot(summaryData) {
        destroyChart('daily-snapshot');
        const el = document.getElementById('chart-daily-snapshot');
        if (!el || !summaryData) return;

        const total = summaryData.total_workstations;
        const platforms = [
            { label: 'SentinelOne Non-Compliant', value: Math.round(total * (1 - summaryData.sentinelone / 100)) },
            { label: 'Inventory Non-Compliant', value: Math.round(total * (1 - summaryData.inventory / 100)) },
            { label: 'MS Patches Non-Compliant', value: Math.round(total * (1 - summaryData.mspatches / 100)) },
            { label: 'Win Build Non-Compliant', value: Math.round(total * (1 - summaryData.winbuild / 100)) },
        ];

        const compliant = total - summaryData.non_compliant;

        const chart = new ApexCharts(el, {
            ...baseOptions(),
            chart: { ...baseOptions().chart, type: 'bar', height: 200, stacked: true, toolbar: { show: false } },
            series: [
                { name: 'Compliant', data: [compliant] },
                ...platforms.map(p => ({ name: p.label, data: [p.value] }))
            ],
            colors: ['#10b981', '#6366f1', '#22d3ee', '#f59e0b', '#ef4444'],
            plotOptions: { bar: { horizontal: true, barHeight: '50%', borderRadius: 4 } },
            xaxis: { labels: { style: { colors: '#94a3b8' } } },
            yaxis: { labels: { show: false } },
            legend: { position: 'bottom', labels: { colors: '#94a3b8' } },
            dataLabels: { enabled: true, style: { fontSize: '11px' } },
        });
        chart.render();
        instances['daily-snapshot'] = chart;
    }

    // ── Section 5.3: Change Detection Table ────────────────

    function renderChangeTable(changes) {
        const container = document.getElementById('change-table-body');
        if (!container) return;

        if (!changes.length) {
            container.innerHTML = '<tr><td colspan="8" class="text-muted text-center">No significant changes detected</td></tr>';
            return;
        }

        container.innerHTML = changes.map(c => {
            const cls = c.delta > 0 ? 'delta-positive' : 'delta-negative';
            return `
                <tr>
                    <td>${WCD.Utils.formatDateDisplay(c.date)}</td>
                    <td>${c.overall_score.toFixed(2)}%</td>
                    <td class="${cls}">${WCD.Utils.formatDelta(c.delta)}</td>
                    <td class="${c.sentinelone_delta >= 0 ? 'delta-positive' : 'delta-negative'}">${WCD.Utils.formatDelta(c.sentinelone_delta)}</td>
                    <td class="${c.inventory_delta >= 0 ? 'delta-positive' : 'delta-negative'}">${WCD.Utils.formatDelta(c.inventory_delta)}</td>
                    <td class="${c.mspatches_delta >= 0 ? 'delta-positive' : 'delta-negative'}">${WCD.Utils.formatDelta(c.mspatches_delta)}</td>
                    <td class="${c.winbuild_delta >= 0 ? 'delta-positive' : 'delta-negative'}">${WCD.Utils.formatDelta(c.winbuild_delta)}</td>
                    <td>${c.non_compliant} (${c.non_compliant_delta >= 0 ? '+' : ''}${c.non_compliant_delta})</td>
                </tr>
            `;
        }).join('');

        // Initialize DataTable if available
        if ($.fn.DataTable && !$.fn.DataTable.isDataTable('#change-table')) {
            $('#change-table').DataTable({
                order: [[2, 'asc']],
                pageLength: 15,
                dom: 'frtip',
                language: { search: 'Filter:' }
            });
        }
    }

    // ── Section 6.1: Fleet Size Trend ──────────────────────

    function renderFleetTrend(trendData, country, autoScale) {
        destroyChart('fleet-trend');
        const el = document.getElementById('chart-fleet-trend');
        if (!el) return;

        const data = trendData[country] || [];
        const chart = new ApexCharts(el, {
            ...baseOptions(),
            chart: { ...baseOptions().chart, type: 'line', height: 300 },
            series: [
                { name: 'Fleet Size', type: 'area', data: data.map(r => ({ x: new Date(r.date).getTime(), y: r.total_workstations })) },
                { name: 'Compliance %', type: 'line', data: data.map(r => ({ x: new Date(r.date).getTime(), y: r.overall_score })) },
            ],
            colors: ['#22d3ee', '#6366f1'],
            stroke: { width: [1, 2], curve: 'smooth' },
            fill: { type: ['gradient', 'solid'], gradient: { opacityFrom: 0.3, opacityTo: 0.05 } },
            xaxis: { type: 'datetime', labels: { style: { colors: '#94a3b8' } } },
            yaxis: [
                { title: { text: 'Workstations', style: { color: '#22d3ee' } }, labels: { style: { colors: '#22d3ee' } }, forceNiceScale: true },
                { opposite: true, ...yAxisConfig('Compliance %', autoScale), title: { text: 'Compliance %', style: { color: '#6366f1' } }, labels: { style: { colors: '#6366f1' }, formatter: v => v != null ? v.toFixed(1) + '%' : '' } },
            ],
            legend: { position: 'top', labels: { colors: '#94a3b8' } },
            title: { text: 'Fleet Size vs Compliance', align: 'left', style: { fontSize: '14px', color: '#e2e8f0' } },
        });
        chart.render();
        instances['fleet-trend'] = chart;
    }

    // ── Section 6.2: Fleet vs Compliance Scatter ───────────

    function renderFleetScatter(rankingData) {
        destroyChart('fleet-scatter');
        const el = document.getElementById('chart-fleet-scatter');
        if (!el || !rankingData.length) return;

        const series = [{
            name: 'Countries',
            data: rankingData.map(r => ({
                x: r.total_workstations,
                y: r.overall_score,
                z: r.non_compliant,
                name: r.country_name,
            }))
        }];

        const chart = new ApexCharts(el, {
            ...baseOptions(),
            chart: { ...baseOptions().chart, type: 'bubble', height: 350 },
            series: series,
            colors: ['#6366f1'],
            xaxis: { title: { text: 'Fleet Size', style: { color: '#94a3b8' } }, labels: { style: { colors: '#94a3b8' } } },
            yaxis: {
                title: { text: 'Compliance %', style: { color: '#94a3b8' } },
                labels: { style: { colors: '#94a3b8' }, formatter: v => v != null ? v.toFixed(1) + '%' : '' },
                forceNiceScale: true,
            },
            dataLabels: {
                enabled: true,
                formatter: function (val, opts) {
                    return opts.w.config.series[0].data[opts.dataPointIndex].name;
                },
                style: { fontSize: '10px', colors: ['#e2e8f0'] },
            },
            fill: { opacity: 0.6 },
            title: { text: 'Fleet Size vs Compliance', align: 'left', style: { fontSize: '14px', color: '#e2e8f0' } },
            tooltip: {
                custom: function ({ seriesIndex, dataPointIndex, w }) {
                    const d = w.config.series[seriesIndex].data[dataPointIndex];
                    return `<div class="custom-tooltip"><b>${d.name}</b><br/>Fleet: ${d.x.toLocaleString()}<br/>Score: ${d.y.toFixed(2)}%<br/>Non-compliant: ${d.z}</div>`;
                }
            }
        });
        chart.render();
        instances['fleet-scatter'] = chart;
    }

    // ── Utility ────────────────────────────────────────────

    function destroyChart(id) {
        if (instances[id]) {
            instances[id].destroy();
            delete instances[id];
        }
    }

    function destroyAll() {
        Object.keys(instances).forEach(destroyChart);
    }

    // ── Public API ─────────────────────────────────────────

    return {
        renderKPICards,
        renderGauge,
        renderHeroTrend,
        renderNonCompliantCount,
        renderPlatformBreakdown,
        renderPatchCycleOverlay,
        renderPatchRecoveryTime,
        renderCountryHeatmap,
        renderCountryRanking,
        renderCountryRadar,
        renderCalendarHeatmap,
        renderDailySnapshot,
        renderChangeTable,
        renderFleetTrend,
        renderFleetScatter,
        destroyAll,
        destroyChart,
        instances,
    };
})();

