#!/usr/bin/env python3
"""
Flask API backend for the Workstation Compliance Dashboard.
"""
from datetime import datetime, timedelta

import os

from flask import Flask, jsonify, request, send_from_directory
from flask_cors import CORS

import config
import models

FRONTEND_DIR = os.path.join(os.path.dirname(__file__), '..', 'frontend')

app = Flask(__name__, static_folder=FRONTEND_DIR, static_url_path='')
CORS(app)


@app.route('/')
def serve_index():
    return send_from_directory(FRONTEND_DIR, 'index.html')


@app.route('/api/countries', methods=['GET'])
def countries():
    return jsonify(models.get_countries())


@app.route('/api/summary', methods=['GET'])
def summary():
    country = request.args.get('country', 'AU')
    date_str = request.args.get('date', datetime.now().strftime('%Y-%m-%d'))
    result = models.get_summary(country, date_str)
    if result is None:
        # Try previous days if exact date not found
        for i in range(1, 8):
            dt = datetime.strptime(date_str, '%Y-%m-%d') - timedelta(days=i)
            result = models.get_summary(country, dt.strftime('%Y-%m-%d'))
            if result:
                break
    if result is None:
        return jsonify({'error': 'No data found'}), 404
    return jsonify(result)


@app.route('/api/trend', methods=['GET'])
def trend():
    country_param = request.args.get('country', 'AU')
    country_codes = [c.strip() for c in country_param.split(',')]
    from_date = request.args.get('from', (datetime.now() - timedelta(days=90)).strftime('%Y-%m-%d'))
    to_date = request.args.get('to', datetime.now().strftime('%Y-%m-%d'))
    result = models.get_trend(country_codes, from_date, to_date)
    return jsonify(result)


@app.route('/api/heatmap', methods=['GET'])
def heatmap():
    from_date = request.args.get('from', (datetime.now() - timedelta(days=180)).strftime('%Y-%m-%d'))
    to_date = request.args.get('to', datetime.now().strftime('%Y-%m-%d'))
    granularity = request.args.get('granularity', 'week')
    result = models.get_heatmap(from_date, to_date, granularity)
    return jsonify(result)


@app.route('/api/ranking', methods=['GET'])
def ranking():
    date_str = request.args.get('date', datetime.now().strftime('%Y-%m-%d'))
    result = models.get_ranking(date_str)
    if not result:
        # Try previous days
        for i in range(1, 8):
            dt = datetime.strptime(date_str, '%Y-%m-%d') - timedelta(days=i)
            result = models.get_ranking(dt.strftime('%Y-%m-%d'))
            if result:
                break
    return jsonify(result)


@app.route('/api/patch-cycles', methods=['GET'])
def patch_cycles():
    country = request.args.get('country', 'AU')
    months = int(request.args.get('months', 12))
    result = models.get_patch_cycles(country, months)
    return jsonify(result)


@app.route('/api/changes', methods=['GET'])
def changes():
    country = request.args.get('country', 'AU')
    from_date = request.args.get('from', (datetime.now() - timedelta(days=90)).strftime('%Y-%m-%d'))
    to_date = request.args.get('to', datetime.now().strftime('%Y-%m-%d'))
    threshold = float(request.args.get('threshold', 0.5))
    result = models.get_changes(country, from_date, to_date, threshold)
    return jsonify(result)


if __name__ == '__main__':
    app.run(debug=config.DEBUG, host=config.HOST, port=config.PORT)
