#!/usr/bin/env python3
"""
Generate realistic dummy compliance data for ~10 countries over 730 days.

Each country has a unique "profile" affecting baseline scores and recovery speed.
MSPatches shows cyclical dips after Patch Tuesday with gradual recovery.
"""
import json
import math
import os
import random
from datetime import datetime, timedelta

# ── Configuration ───────────────────────────────────────────

NUM_DAYS = 730
END_DATE = datetime(2026, 3, 17)
START_DATE = END_DATE - timedelta(days=NUM_DAYS - 1)

COUNTRIES = [
    {'code': 'AU', 'name': 'Australia', 'region': 'APAC', 'fleet': 1200, 'profile': 'strong'},
    {'code': 'US', 'name': 'United States', 'region': 'Americas', 'fleet': 4500, 'profile': 'large'},
    {'code': 'UK', 'name': 'United Kingdom', 'region': 'EMEA', 'fleet': 2800, 'profile': 'strong'},
    {'code': 'DE', 'name': 'Germany', 'region': 'EMEA', 'fleet': 2200, 'profile': 'strong'},
    {'code': 'JP', 'name': 'Japan', 'region': 'APAC', 'fleet': 1800, 'profile': 'methodical'},
    {'code': 'BR', 'name': 'Brazil', 'region': 'Americas', 'fleet': 900, 'profile': 'struggling'},
    {'code': 'IN', 'name': 'India', 'region': 'APAC', 'fleet': 3200, 'profile': 'large'},
    {'code': 'FR', 'name': 'France', 'region': 'EMEA', 'fleet': 1600, 'profile': 'average'},
    {'code': 'SG', 'name': 'Singapore', 'region': 'APAC', 'fleet': 400, 'profile': 'strong'},
    {'code': 'ZA', 'name': 'South Africa', 'region': 'EMEA', 'fleet': 600, 'profile': 'struggling'},
    {'code': 'CA', 'name': 'Canada', 'region': 'Americas', 'fleet': 1100, 'profile': 'average'},
    {'code': 'MX', 'name': 'Mexico', 'region': 'Americas', 'fleet': 700, 'profile': 'struggling'},
]

# Profile definitions: baseline scores and recovery characteristics
PROFILES = {
    'strong': {
        'sentinelone': (99.0, 99.8),
        'inventory': (98.5, 99.5),
        'mspatches_base': (98.0, 99.5),
        'winbuild': (99.0, 99.8),
        'patch_dip': (1.0, 3.0),       # How much MSPatches drops after Patch Tuesday
        'recovery_days': (5, 10),       # Days to recover
        'noise': 0.15,
    },
    'large': {
        'sentinelone': (98.0, 99.2),
        'inventory': (97.5, 99.0),
        'mspatches_base': (96.5, 98.5),
        'winbuild': (98.5, 99.5),
        'patch_dip': (2.0, 5.0),
        'recovery_days': (8, 16),
        'noise': 0.2,
    },
    'methodical': {
        'sentinelone': (99.2, 99.9),
        'inventory': (99.0, 99.8),
        'mspatches_base': (97.0, 99.0),
        'winbuild': (99.5, 99.9),
        'patch_dip': (2.0, 4.0),
        'recovery_days': (7, 12),
        'noise': 0.1,
    },
    'average': {
        'sentinelone': (97.5, 99.0),
        'inventory': (97.0, 98.5),
        'mspatches_base': (96.0, 98.0),
        'winbuild': (98.0, 99.2),
        'patch_dip': (2.5, 5.0),
        'recovery_days': (9, 16),
        'noise': 0.2,
    },
    'struggling': {
        'sentinelone': (95.5, 97.5),
        'inventory': (95.0, 97.0),
        'mspatches_base': (94.0, 97.0),
        'winbuild': (96.0, 98.0),
        'patch_dip': (3.0, 7.0),
        'recovery_days': (12, 21),
        'noise': 0.3,
    },
}


def get_patch_tuesday(year, month):
    """Return the 2nd Tuesday of the given month."""
    first_day = datetime(year, month, 1)
    days_until_tuesday = (1 - first_day.weekday()) % 7
    first_tuesday = first_day + timedelta(days=days_until_tuesday)
    return first_tuesday + timedelta(days=7)


def get_all_patch_tuesdays():
    """Get all Patch Tuesdays in the data range."""
    pts = []
    current = START_DATE.replace(day=1)
    end = END_DATE + timedelta(days=31)
    while current < end:
        pt = get_patch_tuesday(current.year, current.month)
        if START_DATE <= pt <= END_DATE:
            pts.append(pt)
        if current.month == 12:
            current = current.replace(year=current.year + 1, month=1)
        else:
            current = current.replace(month=current.month + 1)
    return pts


def generate_country_data(country, patch_tuesdays):
    profile = PROFILES[country['profile']]
    random.seed(hash(country['code']))  # Reproducible per country

    base_fleet = country['fleet']
    records = []

    # Pre-compute baselines with slow drift
    s1_base = random.uniform(*profile['sentinelone'])
    inv_base = random.uniform(*profile['inventory'])
    msp_base = random.uniform(*profile['mspatches_base'])
    wb_base = random.uniform(*profile['winbuild'])

    # Gradual improvement trend over 2 years (0.5-1.5% total)
    improvement = random.uniform(0.3, 1.0)

    for day_idx in range(NUM_DAYS):
        dt = START_DATE + timedelta(days=day_idx)
        date_str = dt.strftime('%Y-%m-%d')
        progress = day_idx / NUM_DAYS  # 0.0 → 1.0

        # Fleet size: gradual growth with some variation
        fleet = int(base_fleet * (1 + 0.08 * progress + 0.01 * math.sin(day_idx / 60)))
        fleet = max(fleet, 50)

        # Base scores with gradual improvement
        imp = improvement * progress
        noise = profile['noise']

        s1 = min(100, s1_base + imp * 0.3 + random.gauss(0, noise))
        inv = min(100, inv_base + imp * 0.4 + random.gauss(0, noise))
        wb = min(100, wb_base + imp * 0.2 + random.gauss(0, noise))

        # MSPatches: cyclical dip after Patch Tuesday
        msp = min(100, msp_base + imp * 0.5 + random.gauss(0, noise))
        for pt in patch_tuesdays:
            days_since_pt = (dt - pt).days
            if 0 <= days_since_pt <= 28:
                dip_magnitude = random.uniform(*profile['patch_dip'])
                recovery_time = random.uniform(*profile['recovery_days'])
                if days_since_pt == 0:
                    msp -= dip_magnitude * 0.3
                elif days_since_pt <= 2:
                    msp -= dip_magnitude
                elif days_since_pt <= recovery_time:
                    # Exponential recovery
                    recovery_progress = (days_since_pt - 2) / (recovery_time - 2)
                    msp -= dip_magnitude * (1 - recovery_progress ** 0.6)
                break  # Only apply closest Patch Tuesday

        # Occasional random events (agent failures, new deployments)
        if random.random() < 0.02:  # 2% chance per day
            event_platform = random.choice(['sentinelone', 'inventory', 'mspatches', 'winbuild'])
            event_magnitude = random.uniform(0.5, 2.0)
            if event_platform == 'sentinelone':
                s1 -= event_magnitude
            elif event_platform == 'inventory':
                inv -= event_magnitude
            elif event_platform == 'mspatches':
                msp -= event_magnitude
            else:
                wb -= event_magnitude

        # Weekend slight dip in inventory (fewer machines online)
        if dt.weekday() >= 5:
            inv -= random.uniform(0.1, 0.4)

        # Clamp all values
        s1 = round(max(90, min(100, s1)), 2)
        inv = round(max(90, min(100, inv)), 2)
        msp = round(max(88, min(100, msp)), 2)
        wb = round(max(92, min(100, wb)), 2)

        overall = round((s1 + inv + msp + wb) / 4, 2)
        non_compliant = int(fleet * (1 - overall / 100))

        records.append({
            'date': date_str,
            'country': country['code'],
            'overall_score': overall,
            'sentinelone': s1,
            'inventory': inv,
            'mspatches': msp,
            'winbuild': wb,
            'total_workstations': fleet,
            'non_compliant': non_compliant,
        })

    return records


def main():
    print("Generating dummy data...")
    patch_tuesdays = get_all_patch_tuesdays()
    print(f"  Date range: {START_DATE.date()} to {END_DATE.date()}")
    print(f"  Patch Tuesdays found: {len(patch_tuesdays)}")
    print(f"  Countries: {len(COUNTRIES)}")

    all_records = []
    for country in COUNTRIES:
        records = generate_country_data(country, patch_tuesdays)
        all_records.extend(records)
        avg_score = sum(r['overall_score'] for r in records) / len(records)
        print(f"  {country['code']} ({country['name']}): {len(records)} days, avg score {avg_score:.2f}%")

    data = {
        'generated': datetime.now().isoformat(),
        'date_range': {
            'from': START_DATE.strftime('%Y-%m-%d'),
            'to': END_DATE.strftime('%Y-%m-%d'),
        },
        'patch_tuesdays': [pt.strftime('%Y-%m-%d') for pt in patch_tuesdays],
        'countries': [{'code': c['code'], 'name': c['name'], 'region': c['region']} for c in COUNTRIES],
        'daily_records': all_records,
    }

    output_path = os.path.join(os.path.dirname(__file__), '..', 'data', 'dummy_data.json')
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    with open(output_path, 'w') as f:
        json.dump(data, f)

    size_mb = os.path.getsize(output_path) / (1024 * 1024)
    print(f"\nWritten to {output_path}")
    print(f"  Total records: {len(all_records)}")
    print(f"  File size: {size_mb:.1f} MB")


if __name__ == '__main__':
    main()
