# Change Log — design.css / design.js — 07/20/2026

Feature: **start-date overlap warning chip**. When the owner of an Execution
leaf task manually sets a START DATE that falls on or before the latest
predecessor's end date, the task runs concurrently with the predecessor it is
supposed to wait for. A warning chip (⚠ `overlaps predecessor Nd`) now appears
under the START DATE — both in the subtask table and in the detail-pane
header. This mirrors the red-hatch overlap overlay added to timeline.js on the
same date (timeline changes are not covered in this file).

---

## design.css

One block **added** after the existing `.edb-self` rule (now lines 1970–1990).
Nothing removed or modified elsewhere.

```css
/* start-before-predecessor-end warning chip (subtask START DATE cell and
   detail header) — amber/red so it reads as a violation, not information */
.edb-badge.edb-overlap {
    display: inline-block;
    margin-top: 3px;
    background: #fdecea;
    color: #b3261e;
    border: 1px solid #f2c1bd;
}
.edb-badge.edb-overlap i {
    margin-right: 3px;
    font-size: 9px;
}
.edb-badge.edb-overlap:focus {
    outline: 2px solid #b3261e;
    outline-offset: 1px;
}
.detail-meta label .start-overlap-chip {
    align-self: flex-start;
    margin-top: 4px;
}
```

Purpose of each rule:

| Rule | Purpose |
|---|---|
| `.edb-badge.edb-overlap` | The chip itself: light-red background, dark-red text, red border. Inherits size/padding/radius from the existing `.edb-badge` base so it sits alongside the `+60d` / `self +365d` badges. |
| `.edb-badge.edb-overlap i` | Spacing and size for the ⚠ triangle icon inside the chip. |
| `.edb-badge.edb-overlap:focus` | Focus ring — the chip is keyboard-focusable (`tabindex="0"`) so its tooltip is reachable without a mouse. |
| `.detail-meta label .start-overlap-chip` | Positioning only, for the copy of the chip under the header Start Date field: hug the left edge instead of stretching. |

---

## design.js

Four changes: three additions and one behavior-preserving refactor. No code
was deleted outright — one loop moved into a new function (change 3) and two
lines in the table builder were replaced (change 4).

### 1. ADDED — `buildStartOverlapChip()` and `updateHeaderStartOverlapChip()` (lines 1337–1369)

Inserted immediately before `updateHeaderEndDateBadges`.

```js
// Amber warning chip shown under a START DATE that predates the latest
// predecessor end — the owner started the task while its predecessor
// chain was still running (the timeline flags the same span as an
// overlap overlay on the bar). Returns null when there is no overlap.
function buildStartOverlapChip(taskObj) {
    if (!isExecutionProject()) return null;
    if (!taskObj || (taskObj.subtasks && taskObj.subtasks.length > 0)) return null;
    if (!taskObj.startDate) return null;
    ensurePredecessorArray(taskObj);
    if (!taskObj.predecessor || taskObj.predecessor.length === 0) return null;

    var latest = getLatestPredEnd(taskObj);
    if (!latest || taskObj.startDate > latest) return null;
    var oDays = parseInt(calcDuration(taskObj.startDate, latest), 10);
    if (isNaN(oDays) || oDays <= 0) return null;

    return $('<span class="edb-badge edb-overlap start-overlap-chip" tabindex="0">')
        .attr('title', 'Start date is before the predecessor finishes — overlaps the predecessor by ' +
              oDays + ' working day(s). Latest predecessor ends ' + toDisplayDate(latest) + '.')
        .html('<i class="fa fa-triangle-exclamation"></i> overlaps predecessor ' + oDays + 'd');
}

// Keep the header-level START DATE overlap chip in sync for the selected
// task. Piggybacks on the same refresh points as the end date badges.
function updateHeaderStartOverlapChip(task) {
    var $label = $('#detail-start-date').closest('label');
    if (!$label.length) return;
    $label.find('.start-overlap-chip').remove();
    var $chip = buildStartOverlapChip(task);
    if ($chip) $label.append($chip);
}
```

Notes:

- Chip only renders for **Execution** projects, **leaf** tasks (no subtasks),
  with a stored `startDate` and at least one predecessor.
- Overlap condition: `startDate <= latest predecessor end` **and** the span
  contains ≥ 1 working day — a weekend-only overlap is not flagged (same
  threshold the timeline uses).
- Working-day count comes from the existing `calcDuration()`.

### 2. ADDED — one line inside `updateHeaderEndDateBadges()` (line 1373)

```js
function updateHeaderEndDateBadges(task) {
    updateHeaderStartOverlapChip(task);   // <-- ADDED
    var $wrap = $('#detail-end-date-badges');
    ...
```

The header chip refreshes at the same four existing call sites that already
refresh the end-date badges (task selection / detail populate, header
start-date edit, incoming remote patches). The call is placed before that
function's early returns, because the chip's display conditions differ from
the end-date badges' conditions.

### 3. REFACTOR — `getLatestPredEnd()` extracted from `getEffectiveStartDate()` (lines 2302–2350)

Behavior of `getEffectiveStartDate` is **unchanged**. The predecessor-scanning
loop that lived inline inside it is now a standalone function so the chip and
the effective-start computation share one definition of "latest predecessor
end".

**ADDED** function (loop body is character-for-character the old inline code):

```js
// Latest end date (ISO) across a task's predecessors, '' when none can
// be resolved. Predecessors without a stored end date get one computed
// from their own chain (effective start + working days).
function getLatestPredEnd(taskObj, visited) {
    if (!visited) visited = {};
    if (!taskObj) return '';
    ensurePredecessorArray(taskObj);
    if (!taskObj.predecessor || taskObj.predecessor.length === 0) return '';

    var maxEndDate = '';
    for (var i = 0; i < taskObj.predecessor.length; i++) {
        var pred = findTaskById(taskObj.predecessor[i], tasks);
        if (!pred) continue;

        var predEnd = pred.endDate || '';
        if (!predEnd) {
            var predDays = getStoredDuration(pred);
            if (predDays > 0) {
                var effStart = getEffectiveStartDate(pred, visited);
                if (effStart) predEnd = addWorkingDays(effStart, predDays);
            }
        }

        if (predEnd && predEnd > maxEndDate) {
            maxEndDate = predEnd;
        }
    }
    return maxEndDate;
}
```

**REPLACED** inside `getEffectiveStartDate()` — the inline `var maxEndDate = '';
for (...) { ... }` loop became:

```js
    var maxEndDate = getLatestPredEnd(taskObj, visited);
    if (maxEndDate) {
        return nextWorkingDay(maxEndDate);
    }
    return taskObj.startDate || '';
```

### 4. REPLACED — subtask table START DATE cell (lines 2944–2952)

**Before:**

```js
$startWrap.append($startInput).append($startHidden).append($startBtn);
$tr.append($('<td>').append($startWrap));
```

**After:**

```js
$startWrap.append($startInput).append($startHidden).append($startBtn);
var $startTd = $('<td>').append($startWrap);
// Warn when the stored start predates the latest predecessor end
// (owner-entered overlap) — mirrors the timeline's overlap overlay
if (isExecutionProject() && !hasChildren) {
    var $overlapChip = buildStartOverlapChip(st);
    if ($overlapChip) $startTd.append($overlapChip);
}
$tr.append($startTd);
```

The cell is built identically; the only difference is the chip appended under
the date input for Execution-project leaf rows whose start overlaps a
predecessor. The chip auto-refreshes on date edits because the table already
re-renders (`renderSubtaskTable`) after any start/end date change.

---

## Not changed

- `update.js` / `update.html` maintain their own duplicates of these
  table/badge functions and were deliberately left untouched — if owners edit
  start dates through update.html, that page does not show the chip yet.
- Timeline files (`timeline.js`, `timeline.css`, `timeline.html`) were changed
  the same day for the matching overlap overlay, but are documented separately.
