# Change Log — timeline.html / timeline.js / timeline.css — 07/20/2026

Feature: **overlap indicator**. When an Execution leaf task's START DATE has
been manually pulled back to on-or-before its latest predecessor's end date,
the task runs concurrently with the predecessor it is supposed to wait for.
Previously the timeline showed nothing for this case (the waiting hatch was
silently clipped at the bar's start). Now the concurrent stretch is drawn as a
red diagonal hatch **on top of** the bar's leading segment, with its own
tooltip, a legend entry, a red `⚠` day-count label, and a matching fill in the
Excel export.

Companion change: design.js/design.css gained a warning chip under the START
DATE for the same condition — documented separately in
`change.design.7.20.26.md`.

---

## timeline.html

One legend entry **added** inside the `.tl-keyrow` block, after the
"waiting on predecessor" key. Nothing removed.

```html
<span class="tl-key"><span class="tl-key-overlap"></span>overlap (started before predecessor finished)</span>
```

---

## timeline.js

Six changes. No dead code left behind; two spots were replaced in place.

### 1. CHANGED — `computeWait()` detects the overlap (lines 173–225)

The doc comment above it was updated from "Two kinds" to "Three kinds",
adding:

```
//   overlap — the owner moved the start date BEFORE the latest
//             predecessor's end, so the task runs concurrently with the
//             chain it is supposed to wait for. Spans start ->
//             min(latest predecessor end, task end); rendered as a
//             warning overlay ON the bar, not a pre-bar tail.
```

**Signature changed** — gained a third parameter:

```js
// before
function computeWait(preds, start) {
// after
function computeWait(preds, start, end) {
```

**ADDED** after the `latest` (latest predecessor end) loop — the overlap
computation. It sits *before* the existing early-return guard so an overlap
is still reported when the task starts on project day 1 (where `waiting`
cannot exist):

```js
var overlap = null;
if (latest && latest >= start) {
    var oTo = (end && end < latest) ? end : latest;
    var od = workingDays(start, oTo);
    if (od > 0) overlap = { from: start, to: oTo, days: od };
}
```

**REPLACED** — the early-return guard now carries the overlap through:

```js
// before
if (!latest || !projectStart || projectStart >= start) return null;
// after
if (!latest || !projectStart || projectStart >= start) {
    return overlap ? { overlap: overlap } : null;
}
```

**REPLACED** — the final return includes overlap:

```js
// before
return (waiting || idle) ? { waiting: waiting, idle: idle } : null;
// after
return (waiting || idle || overlap)
    ? { waiting: waiting, idle: idle, overlap: overlap }
    : null;
```

Rules encoded here:

- Overlap condition: `latest predecessor end >= start`.
- Span: task start → `min(latest predecessor end, task end)` — a task that
  ends while its predecessor is still running is hatched over its entire bar.
- Only reported when the span contains ≥ 1 working day, so a weekend-only
  overlap is not flagged (same threshold as the existing idle/slack gaps).
- The `waiting` / `idle` / `slack` computations are untouched.

### 2. CHANGED — `buildRows()` passes the task end date (line 242)

```js
// before
wait: isParent ? null : computeWait(preds, d.s),
// after
wait: isParent ? null : computeWait(preds, d.s, d.e),
```

### 3. ADDED / REPLACED — render: overlay + warning day label (lines ~448–466)

In the leaf branch of `render()`, immediately **after** the `.tl-bar` div is
emitted (so the overlay paints above both the bar and its `% complete` fill —
later sibling wins in the same stacking context), this block was **ADDED**:

```js
// overlap overlay: hatched warning ON TOP of the bar's
// leading segment — start date was pulled back before the
// latest predecessor's end. Rendered after .tl-bar so it
// paints above both the bar and its % complete fill.
var overlap = r.wait && r.wait.overlap;
if (overlap) {
    var ol = Math.max(pct(overlap.from), 0);
    var or2 = endPct(overlap.to);
    var oTip = '<span class=\'t\'>' + esc(t.name) + '</span>' +
               '<span class=\'m\'>— OVERLAP (started ' + overlap.days +
               ' wkng days before predecessor finished):</span>' + predLines;
    h += '<div class="tl-overlap" style="left:' + ol + '%;width:' + (or2 - ol) +
         '%" tabindex="0" data-tip="' + escAttr(oTip) + '"></div>';
}
```

The tooltip reuses `predLines` (the predecessor list already built for the
waiting/idle tails, latest-ending first) and the element is keyboard-focusable
like the other tail segments.

The day-count label line was **REPLACED**:

```js
// before
h += '<div class="tl-days" style="left:' + endPct(r.e) + '%">' + days + 'd</div>';
// after
h += '<div class="tl-days' + (overlap ? ' tl-days-warn' : '') + '" style="left:' +
     endPct(r.e) + '%">' + days + 'd' + (overlap ? ' ⚠' : '') + '</div>';
```

So an overlapped task's label reads e.g. `384d ⚠` in red — visible even when
the hatch itself is only a few pixels wide at a far zoom.

### 4. CHANGED — tooltip style hookup (line 608)

The overlap overlay joins the grey ("alt") tooltip variant used by the other
hatched segments:

```js
// before
$tip.toggleClass('tl-tip-alt', $(el).is('.tl-wait, .tl-idle, .tl-slack'));
// after
$tip.toggleClass('tl-tip-alt', $(el).is('.tl-wait, .tl-idle, .tl-slack, .tl-overlap'));
```

### 5. ADDED — Excel export fill (line 656)

New entry in `XL_FILL` — red `lightUp` hatch over the bar-blue background,
mirroring the on-screen hatch-over-blue look:

```js
overlap: { type: 'pattern', pattern: 'lightUp', fgColor: { argb: 'FFC62828' }, bgColor: { argb: 'FF2A78D6' } },
```

### 6. CHANGED — Excel export day loop + legend (lines 790–800, 820)

**REPLACED** — the per-row range setup gained `oRng`:

```js
// before
var wRng = rng(w.waiting), iRng = rng(w.idle), sRng = rng(w.slack);
// after
var wRng = rng(w.waiting), iRng = rng(w.idle), sRng = rng(w.slack), oRng = rng(w.overlap);
```

**REPLACED** — inside the day loop, overlap takes precedence over the plain
bar / done fills within the bar span (same stacking as the on-screen overlay):

```js
// before
if (bs !== null && di >= bs && di <= be) {
    fill = r.isParent ? XL_FILL.roll : (di <= doneEnd ? XL_FILL.done : XL_FILL.bar);
}
// after
if (bs !== null && di >= bs && di <= be) {
    // overlap wins over bar/done inside the bar span — same
    // stacking as the on-screen overlay
    fill = r.isParent ? XL_FILL.roll
         : (oRng && di >= oRng[0] && di <= oRng[1]) ? XL_FILL.overlap
         : (di <= doneEnd ? XL_FILL.done : XL_FILL.bar);
}
```

**ADDED** — legend row in the export's legend block, after the "waiting on
predecessor" entry:

```js
[XL_FILL.overlap, 'overlap (started before predecessor finished)'],
```

---

## timeline.css

Five additions. Nothing removed.

### 1. ADDED — `--overlap` color variable

Light theme (`:root`, line 16):

```css
--overlap: #c62828;
```

Dark theme (`@media (prefers-color-scheme: dark)` block, line 33):

```css
--overlap: #ef9a9a;
```

### 2. ADDED — legend swatch `.tl-key-overlap` (line 98)

Red hatch layered over the solid bar blue, so the key looks exactly like an
overlapped bar segment:

```css
.tl-key-overlap { width: 20px; height: 12px; border-radius: 4px; background: repeating-linear-gradient(45deg, transparent 0 3px, var(--overlap) 3px 4.5px), var(--bar); }
```

### 3. CHANGED — focus ring selector (line 309)

`.tl-overlap:focus-visible` appended to the existing list:

```css
.tl-bar:focus-visible, .tl-wait:focus-visible, .tl-idle:focus-visible, .tl-slack:focus-visible, .tl-overlap:focus-visible {
```

### 4. ADDED — the overlay itself, `.tl-overlap` (lines 349–362, before `.tl-rollbar`)

```css
/* warning overlay painted ON TOP of the bar (rendered after .tl-bar): the
   task's start date was pulled back before its latest predecessor's end, so
   this leading stretch runs concurrently with the predecessor. Hatch with
   transparent gaps — the blue bar (and % fill) stays visible underneath. */
.tl-overlap {
    position: absolute;
    top: 50%;
    height: 14px;
    transform: translateY(-50%);
    border-radius: 4px;
    min-width: 6px;      /* a few-day overlap must stay visible at any zoom */
    background: repeating-linear-gradient(45deg, transparent 0 3px, var(--overlap) 3px 4.5px);
    outline: none;
}
```

Height is 14px — the same as `.tl-bar` (the pre-bar tails are 10px) — so the
hatch covers the bar edge-to-edge. The stripes use the same 3px / 4.5px rhythm
as the existing waiting/idle hatches.

### 5. ADDED — `.tl-days-warn` (line 381)

Red tint for the day-count label of an overlapped task:

```css
.tl-days-warn { color: var(--overlap); font-weight: 600; }
```

---

## Verification performed on 07/20/2026

- `node --check` passes on timeline.js.
- `computeWait` logic unit-tested against the reference scenario (predecessor
  ends 03/25/2027):
  - start 03/26/2027 → no overlap, waiting tail 60 wkng days (unchanged
    behavior, matches the `+60d` badge in design.html);
  - start 03/01/2027 → overlap 03/01 → 03/25, 19 wkng days;
  - start 05/03/2027 → idle gap only, no overlap (unchanged);
  - task ending inside the predecessor span → whole bar hatched;
  - start on project day 1 → overlap still reported (no waiting tail exists);
  - weekend-only overlap → not flagged (0 working days).
