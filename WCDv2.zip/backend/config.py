import os

# Database configuration
DB_CONFIG = {
    'host': os.environ.get('DB_HOST', 'localhost'),
    'port': int(os.environ.get('DB_PORT', 3306)),
    'user': os.environ.get('DB_USER', 'wcd_user'),
    'password': os.environ.get('DB_PASSWORD', 'wcd_pass'),
    'database': os.environ.get('DB_NAME', 'wcd'),
}

# Use JSON file instead of MySQL for development
USE_JSON = os.environ.get('USE_JSON', 'true').lower() == 'true'
JSON_DATA_PATH = os.path.join(os.path.dirname(__file__), '..', 'data', 'dummy_data.json')

# Flask config
DEBUG = os.environ.get('FLASK_DEBUG', 'true').lower() == 'true'
HOST = os.environ.get('FLASK_HOST', '0.0.0.0')
PORT = int(os.environ.get('FLASK_PORT', 5000))
