"""
Data models and data access layer.
Supports both MySQL and JSON file backends.
"""
import json
import os
from datetime import datetime, timedelta

import config


def _load_json():
    with open(config.JSON_DATA_PATH, 'r') as f:
        return json.load(f)


def _get_db_connection():
    import mysql.connector
    return mysql.connector.connect(**config.DB_CONFIG)


# ── Public API ──────────────────────────────────────────────

def get_countries():
    if config.USE_JSON:
        data = _load_json()
        return sorted(data['countries'], key=lambda c: c['name'])
    conn = _get_db_connection()
    cur = conn.cursor(dictionary=True)
    cur.execute("SELECT code, name, region FROM countries ORDER BY name")
    rows = cur.fetchall()
    cur.close()
    conn.close()
    return rows


def get_summary(country_code, date_str):
    if config.USE_JSON:
        data = _load_json()
        records = data['daily_records']
        day = [r for r in records if r['country'] == country_code and r['date'] == date_str]
        if not day:
            return None
        rec = day[0]
        # Get 30-day sparkline
        dt = datetime.strptime(date_str, '%Y-%m-%d')
        start = (dt - timedelta(days=30)).strftime('%Y-%m-%d')
        spark = sorted(
            [r for r in records if r['country'] == country_code and start <= r['date'] <= date_str],
            key=lambda r: r['date']
        )
        return {
            'date': date_str,
            'country': country_code,
            'overall_score': rec['overall_score'],
            'sentinelone': rec['sentinelone'],
            'inventory': rec['inventory'],
            'mspatches': rec['mspatches'],
            'winbuild': rec['winbuild'],
            'total_workstations': rec['total_workstations'],
            'non_compliant': rec['non_compliant'],
            'sparkline': [r['overall_score'] for r in spark],
            'sparkline_nc': [r['non_compliant'] for r in spark],
        }
    conn = _get_db_connection()
    cur = conn.cursor(dictionary=True)
    cur.execute("""
        SELECT * FROM daily_compliance
        WHERE country_code = %s AND record_date = %s
    """, (country_code, date_str))
    row = cur.fetchone()
    cur.close()
    conn.close()
    return row


def get_trend(country_codes, from_date, to_date):
    if config.USE_JSON:
        data = _load_json()
        records = data['daily_records']
        result = {}
        for cc in country_codes:
            rows = sorted(
                [r for r in records if r['country'] == cc and from_date <= r['date'] <= to_date],
                key=lambda r: r['date']
            )
            result[cc] = rows
        return result
    conn = _get_db_connection()
    cur = conn.cursor(dictionary=True)
    placeholders = ','.join(['%s'] * len(country_codes))
    cur.execute(f"""
        SELECT * FROM daily_compliance
        WHERE country_code IN ({placeholders})
          AND record_date BETWEEN %s AND %s
        ORDER BY country_code, record_date
    """, (*country_codes, from_date, to_date))
    rows = cur.fetchall()
    cur.close()
    conn.close()
    result = {}
    for row in rows:
        cc = row['country_code']
        if cc not in result:
            result[cc] = []
        result[cc].append(row)
    return result


def get_heatmap(from_date, to_date, granularity='week'):
    """Get all countries' scores aggregated by week or month."""
    if config.USE_JSON:
        data = _load_json()
        records = data['daily_records']
        filtered = [r for r in records if from_date <= r['date'] <= to_date]

        from collections import defaultdict
        buckets = defaultdict(list)
        for r in filtered:
            dt = datetime.strptime(r['date'], '%Y-%m-%d')
            if granularity == 'week':
                # ISO week start (Monday)
                week_start = dt - timedelta(days=dt.weekday())
                key = (r['country'], week_start.strftime('%Y-%m-%d'))
            else:
                key = (r['country'], dt.strftime('%Y-%m'))
            buckets[key].append(r['overall_score'])

        result = []
        for (country, period), scores in buckets.items():
            result.append({
                'country': country,
                'period': period,
                'score': round(sum(scores) / len(scores), 2),
            })
        return sorted(result, key=lambda x: (x['country'], x['period']))
    return []


def get_ranking(date_str):
    if config.USE_JSON:
        data = _load_json()
        records = data['daily_records']
        day = [r for r in records if r['date'] == date_str]
        ranking = sorted(day, key=lambda r: r['overall_score'], reverse=True)
        countries_map = {c['code']: c['name'] for c in data['countries']}
        return [{
            'country': r['country'],
            'country_name': countries_map.get(r['country'], r['country']),
            'overall_score': r['overall_score'],
            'sentinelone': r['sentinelone'],
            'inventory': r['inventory'],
            'mspatches': r['mspatches'],
            'winbuild': r['winbuild'],
            'total_workstations': r['total_workstations'],
            'non_compliant': r['non_compliant'],
        } for r in ranking]
    return []


def get_patch_cycles(country_code, months=12):
    """Get MSPatches compliance from each Patch Tuesday for N months."""
    if config.USE_JSON:
        data = _load_json()
        records = data['daily_records']
        country_recs = sorted(
            [r for r in records if r['country'] == country_code],
            key=lambda r: r['date']
        )
        if not country_recs:
            return []

        # Find Patch Tuesdays in the data range
        from_dt = datetime.strptime(country_recs[0]['date'], '%Y-%m-%d')
        to_dt = datetime.strptime(country_recs[-1]['date'], '%Y-%m-%d')

        patch_tuesdays = _get_patch_tuesdays(from_dt, to_dt)
        # Limit to last N months
        patch_tuesdays = patch_tuesdays[-months:]

        cycles = []
        rec_by_date = {r['date']: r for r in country_recs}

        for pt in patch_tuesdays:
            cycle = {
                'patch_tuesday': pt.strftime('%Y-%m-%d'),
                'label': pt.strftime('%b %Y'),
                'days': []
            }
            for day_offset in range(29):  # Day 0 to Day 28
                d = pt + timedelta(days=day_offset)
                ds = d.strftime('%Y-%m-%d')
                if ds in rec_by_date:
                    cycle['days'].append({
                        'day': day_offset,
                        'date': ds,
                        'mspatches': rec_by_date[ds]['mspatches'],
                        'overall_score': rec_by_date[ds]['overall_score'],
                    })
            if cycle['days']:
                cycles.append(cycle)
        return cycles
    return []


def get_changes(country_code, from_date, to_date, threshold=0.5):
    """Detect day-over-day changes exceeding threshold."""
    if config.USE_JSON:
        data = _load_json()
        records = data['daily_records']
        rows = sorted(
            [r for r in records if r['country'] == country_code and from_date <= r['date'] <= to_date],
            key=lambda r: r['date']
        )
        changes = []
        for i in range(1, len(rows)):
            prev, curr = rows[i - 1], rows[i]
            delta = round(curr['overall_score'] - prev['overall_score'], 2)
            if abs(delta) >= threshold:
                changes.append({
                    'date': curr['date'],
                    'prev_date': prev['date'],
                    'overall_score': curr['overall_score'],
                    'prev_score': prev['overall_score'],
                    'delta': delta,
                    'sentinelone_delta': round(curr['sentinelone'] - prev['sentinelone'], 2),
                    'inventory_delta': round(curr['inventory'] - prev['inventory'], 2),
                    'mspatches_delta': round(curr['mspatches'] - prev['mspatches'], 2),
                    'winbuild_delta': round(curr['winbuild'] - prev['winbuild'], 2),
                    'non_compliant': curr['non_compliant'],
                    'non_compliant_delta': curr['non_compliant'] - prev['non_compliant'],
                })
        return sorted(changes, key=lambda c: abs(c['delta']), reverse=True)
    return []


def _get_patch_tuesdays(from_dt, to_dt):
    """Get all Patch Tuesdays (2nd Tuesday of month) in a date range."""
    result = []
    current = from_dt.replace(day=1)
    while current <= to_dt:
        # Find 2nd Tuesday of this month
        first_day = current.replace(day=1)
        # weekday(): Monday=0, Tuesday=1
        days_until_tuesday = (1 - first_day.weekday()) % 7
        first_tuesday = first_day + timedelta(days=days_until_tuesday)
        second_tuesday = first_tuesday + timedelta(days=7)
        if from_dt <= second_tuesday <= to_dt:
            result.append(second_tuesday)
        # Move to next month
        if current.month == 12:
            current = current.replace(year=current.year + 1, month=1)
        else:
            current = current.replace(month=current.month + 1)
    return result
