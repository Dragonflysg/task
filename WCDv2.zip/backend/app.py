"""
Flask API serving compliance dashboard data.
For development, reads from dummy_data.json.
For production, replace with MySQL queries.
"""
import json
import os
from datetime import datetime, timedelta
from flask import Flask, jsonify, request
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

# Load dummy data
DATA_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "dummy_data.json")
_cache = {}


def load_data():
    if "data" not in _cache:
        with open(DATA_PATH, "r") as f:
            _cache["data"] = json.load(f)
    return _cache["data"]


def get_param(key, default=None):
    """Get parameter from JSON body (POST)."""
    body = request.get_json(silent=True) or {}
    return body.get(key, default)


@app.route("/api/countries", methods=["POST"])
def get_countries():
    data = load_data()
    return jsonify(data["countries"])


@app.route("/api/patch-tuesdays", methods=["POST"])
def get_patch_tuesdays():
    data = load_data()
    return jsonify(data["patch_tuesdays"])


@app.route("/api/summary", methods=["POST"])
def get_summary():
    """Single-day snapshot for KPI cards."""
    data = load_data()
    country = get_param("country", "AU")
    date_str = get_param("date")

    records = data["data"].get(country, [])
    if not records:
        return jsonify({"error": "Country not found"}), 404

    if date_str:
        record = next((r for r in records if r["date"] == date_str), None)
        if not record:
            record = records[-1]
    else:
        record = records[-1]

    # Compute 30-day-ago values for delta
    target_date = datetime.strptime(record["date"], "%Y-%m-%d")
    ago_date = (target_date - timedelta(days=30)).strftime("%Y-%m-%d")
    ago_record = next((r for r in records if r["date"] == ago_date), None)

    result = {
        "current": record,
        "previous": ago_record,
    }
    return jsonify(result)


@app.route("/api/trend", methods=["POST"])
def get_trend():
    """Daily time series for charts."""
    data = load_data()
    country_param = get_param("country", "AU")
    countries = country_param.split(",") if isinstance(country_param, str) else country_param
    date_from = get_param("from", "")
    date_to = get_param("to", "")

    result = {}
    for country in countries:
        records = data["data"].get(country.strip(), [])
        if date_from:
            records = [r for r in records if r["date"] >= date_from]
        if date_to:
            records = [r for r in records if r["date"] <= date_to]
        result[country.strip()] = records

    return jsonify(result)


@app.route("/api/heatmap", methods=["POST"])
def get_heatmap():
    """All countries aggregated weekly/monthly for heatmap."""
    data = load_data()
    date_from = get_param("from", "")
    date_to = get_param("to", "")
    aggregation = get_param("aggregation", "monthly")

    result = []
    for country_info in data["countries"]:
        code = country_info["code"]
        records = data["data"].get(code, [])
        if date_from:
            records = [r for r in records if r["date"] >= date_from]
        if date_to:
            records = [r for r in records if r["date"] <= date_to]

        if not records:
            continue

        # Aggregate
        buckets = {}
        for r in records:
            d = datetime.strptime(r["date"], "%Y-%m-%d")
            if aggregation == "weekly":
                key = d.strftime("%Y-W%W")
            else:
                key = d.strftime("%Y-%m")
            if key not in buckets:
                buckets[key] = []
            buckets[key].append(r["compliance_score"])

        periods = []
        for period, scores in sorted(buckets.items()):
            periods.append({
                "period": period,
                "score": round(sum(scores) / len(scores), 6),
            })

        result.append({
            "country": code,
            "name": country_info["name"],
            "periods": periods,
        })

    return jsonify(result)


@app.route("/api/ranking", methods=["POST"])
def get_ranking():
    """All countries' current scores for ranking chart."""
    data = load_data()
    date_str = get_param("date", "")

    result = []
    for country_info in data["countries"]:
        code = country_info["code"]
        records = data["data"].get(code, [])
        if not records:
            continue

        if date_str:
            record = next((r for r in records if r["date"] == date_str), records[-1])
        else:
            record = records[-1]

        result.append({
            "country": code,
            "name": country_info["name"],
            "compliance_score": record["compliance_score"],
            "enabled_ws": record["enabled_ws"],
            "non_compliant": record["non_compliant"],
        })

    result.sort(key=lambda x: x["compliance_score"], reverse=True)
    return jsonify(result)


@app.route("/api/changes", methods=["POST"])
def get_changes():
    """Day-over-day deltas, highlighting significant changes."""
    data = load_data()
    country = get_param("country", "AU")
    threshold = float(get_param("threshold", 0.5))
    date_from = get_param("from", "")
    date_to = get_param("to", "")

    records = data["data"].get(country, [])
    if date_from:
        records = [r for r in records if r["date"] >= date_from]
    if date_to:
        records = [r for r in records if r["date"] <= date_to]

    platforms = ["mecm", "sentinelone", "inventory", "mspatches", "bitlocker", "winbuild"]
    changes = []

    for i in range(1, len(records)):
        prev = records[i - 1]
        curr = records[i]
        deltas = {}
        significant = False

        for p in platforms:
            delta = curr[p] - prev[p]
            deltas[p] = delta
            if prev["enabled_ws"] > 0:
                pct_change = abs(delta / prev["enabled_ws"]) * 100
                if pct_change >= threshold:
                    significant = True

        score_delta = curr["compliance_score"] - prev["compliance_score"]
        if abs(score_delta * 100) >= threshold:
            significant = True

        if significant:
            changes.append({
                "date": curr["date"],
                "enabled_ws": curr["enabled_ws"],
                "enabled_ws_delta": curr["enabled_ws"] - prev["enabled_ws"],
                "deltas": deltas,
                "compliance_score": curr["compliance_score"],
                "score_delta": round(score_delta, 8),
                "non_compliant": curr["non_compliant"],
                "nc_delta": curr["non_compliant"] - prev["non_compliant"],
            })

    return jsonify(changes)


if __name__ == "__main__":
    app.run(debug=True, port=5000)
