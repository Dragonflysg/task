/**
 * API client for the WCD Dashboard.
 * Uses POST requests with JSON body. Includes client-side caching.
 */
var WCD = window.WCD || {};

WCD.API = (function() {
    var BASE_URL = 'http://127.0.0.1:5000/api';
    var cache = {};
    var CACHE_TTL = 5 * 60 * 1000; // 5 minutes

    function cacheKey(url, payload) {
        return 'wcd_' + url + '_' + JSON.stringify(payload || {});
    }

    function getCached(url, payload) {
        var key = cacheKey(url, payload);
        if (cache[key] && (Date.now() - cache[key].time) < CACHE_TTL) {
            return cache[key].data;
        }
        return null;
    }

    function setCache(url, payload, data) {
        cache[cacheKey(url, payload)] = { data: data, time: Date.now() };
    }

    function postJSON(url, payload) {
        var cached = getCached(url, payload);
        if (cached) {
            return $.Deferred().resolve(cached).promise();
        }
        return $.ajax({
            url: url,
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(payload || {}),
            dataType: 'json',
        }).then(function(data) {
            setCache(url, payload, data);
            return data;
        });
    }

    return {
        getCountries: function() {
            return postJSON(BASE_URL + '/countries');
        },

        getPatchTuesdays: function() {
            return postJSON(BASE_URL + '/patch-tuesdays');
        },

        getSummary: function(country, date) {
            var payload = { country: country };
            if (date) payload.date = date;
            return postJSON(BASE_URL + '/summary', payload);
        },

        getTrend: function(countries, from, to) {
            var countryParam = Array.isArray(countries) ? countries.join(',') : countries;
            var payload = { country: countryParam };
            if (from) payload.from = from;
            if (to) payload.to = to;
            return postJSON(BASE_URL + '/trend', payload);
        },

        getHeatmap: function(from, to, aggregation) {
            var payload = { aggregation: aggregation || 'monthly' };
            if (from) payload.from = from;
            if (to) payload.to = to;
            return postJSON(BASE_URL + '/heatmap', payload);
        },

        getRanking: function(date) {
            var payload = {};
            if (date) payload.date = date;
            return postJSON(BASE_URL + '/ranking', payload);
        },

        getChanges: function(country, threshold, from, to) {
            var payload = { country: country };
            if (threshold) payload.threshold = threshold;
            if (from) payload.from = from;
            if (to) payload.to = to;
            return postJSON(BASE_URL + '/changes', payload);
        },

        clearCache: function() {
            cache = {};
        },
    };
})();

window.WCD = WCD;
