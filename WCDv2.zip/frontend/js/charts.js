/**
 * Chart initialization and rendering for WCD Dashboard.
 * Uses ApexCharts for all visualizations.
 */
var WCD = window.WCD || {};

WCD.Charts = (function() {
    var charts = {};
    var U = WCD.Utils;

    // Shared group ID for synchronized charts
    var SYNC_GROUP = 'wcd-sync';

    function destroyChart(id) {
        if (charts[id]) {
            charts[id].destroy();
            delete charts[id];
        }
    }

    function destroyAll() {
        Object.keys(charts).forEach(function(id) {
            charts[id].destroy();
        });
        charts = {};
    }

    // =============================================
    // KPI CARDS
    // =============================================
    function renderKPICards(summary) {
        var current = summary.current;
        var prev = summary.previous;
        var $container = $('#kpi-cards');
        $container.empty();

        // 1. Enabled WS card (leftmost)
        var fleetDelta = prev ? U.formatDelta(current.enabled_ws - prev.enabled_ws) : null;
        $container.append(buildKPICard({
            icon: '\uD83D\uDCBB',
            value: U.formatNumber(current.enabled_ws),
            label: 'Enabled WS',
            delta: fleetDelta,
            trend: 'fleet',
        }));

        // 2. Platform cards (raw counts)
        U.PLATFORMS.forEach(function(p) {
            var currVal = current[p.key];
            var prevVal = prev ? prev[p.key] : null;
            var delta = prevVal !== null ? U.formatDelta(currVal - prevVal) : null;

            var card = buildKPICard({
                icon: p.icon,
                value: U.formatNumber(currVal),
                label: p.label,
                delta: delta,
                trend: p.key,
            });
            $container.append(card);
        });

        // Bottom row: Non-Compliant + Compliance Score (centered)
        var $bottomRow = $('#kpi-cards-bottom');
        $bottomRow.empty();

        var ncDelta = prev ? U.formatDelta(current.non_compliant - prev.non_compliant, true) : null;
        $bottomRow.append(buildKPICard({
            icon: '\u26A0\uFE0F',
            value: U.formatNumber(current.non_compliant),
            label: 'Non-Compliant',
            delta: ncDelta,
            trend: 'nc',
            isAlert: current.non_compliant > 0,
        }));

        $bottomRow.append(buildKPICard({
            icon: '\uD83D\uDEE1\uFE0F',
            value: U.formatScore(current.compliance_score),
            label: 'Compliance',
            delta: prev ? U.formatScoreDelta(current.compliance_score, prev.compliance_score) : null,
            trend: 'score',
        }));
    }

    function buildKPICard(opts) {
        var barClass = 'neutral';
        if (opts.delta) barClass = opts.delta.cssClass;
        if (opts.isAlert) barClass = 'negative';

        var $card = $('<div class="kpi-card"></div>');
        $card.append('<div class="card-top-bar ' + barClass + '"></div>');
        $card.append('<div class="card-icon">' + opts.icon + '</div>');
        $card.append('<div class="card-value">' + opts.value + '</div>');
        $card.append('<div class="card-label">' + opts.label + '</div>');

        if (opts.delta) {
            $card.append('<div class="card-delta ' + opts.delta.cssClass + '">' + opts.delta.text + ' vs 30d ago</div>');
        }

        // Sparkline placeholder
        $card.append('<div class="card-sparkline" id="sparkline-' + opts.trend + '"></div>');

        return $card;
    }

    // =============================================
    // SPARKLINES (inside KPI cards)
    // =============================================
    function renderSparklines(trendData, country) {
        var records = trendData[country] || [];
        // Last 30 data points for sparklines
        var last30 = records.slice(-30);
        if (last30.length === 0) return;

        // Score sparkline
        renderSparkline('sparkline-score', last30.map(function(r) { return +(r.compliance_score * 100).toFixed(2); }), U.COLORS.blue);

        // Platform sparklines
        U.PLATFORMS.forEach(function(p) {
            renderSparkline('sparkline-' + p.key, last30.map(function(r) { return r[p.key]; }), U.COLORS.green);
        });

        // Fleet sparkline
        renderSparkline('sparkline-fleet', last30.map(function(r) { return r.enabled_ws; }), U.COLORS.blue);

        // Non-compliant sparkline
        renderSparkline('sparkline-nc', last30.map(function(r) { return r.non_compliant; }), U.COLORS.red);
    }

    function renderSparkline(elementId, data, color) {
        var el = document.getElementById(elementId);
        if (!el) return;
        destroyChart(elementId);

        var options = {
            chart: {
                type: 'line',
                height: 30,
                sparkline: { enabled: true },
                background: 'transparent',
            },
            series: [{ data: data }],
            stroke: { width: 1.5, curve: 'smooth' },
            colors: [color],
            tooltip: { enabled: false },
        };

        charts[elementId] = new ApexCharts(el, options);
        charts[elementId].render();
    }

    // =============================================
    // COMPLIANCE GAUGE
    // =============================================
    function renderGauge(score) {
        destroyChart('compliance-gauge');
        var pct = +(score * 100).toFixed(2);
        var color = pct >= 98 ? U.COLORS.green : pct >= 95 ? U.COLORS.amber : U.COLORS.red;

        var options = $.extend(true, {}, U.darkTheme(), {
            chart: {
                type: 'radialBar',
                height: 280,
            },
            series: [pct],
            plotOptions: {
                radialBar: {
                    startAngle: -135,
                    endAngle: 135,
                    hollow: { size: '60%' },
                    track: {
                        background: '#2a3a4a',
                        strokeWidth: '100%',
                    },
                    dataLabels: {
                        name: {
                            show: true,
                            fontSize: '14px',
                            color: '#8899aa',
                            offsetY: -10,
                        },
                        value: {
                            show: true,
                            fontSize: '28px',
                            fontWeight: 700,
                            color: '#e8edf2',
                            formatter: function(val) { return val + '%'; },
                        },
                    },
                },
            },
            fill: { colors: [color] },
            labels: ['Compliance'],
        });

        charts['compliance-gauge'] = new ApexCharts(document.getElementById('compliance-gauge'), options);
        charts['compliance-gauge'].render();
    }

    // =============================================
    // HERO TREND CHART (with brush)
    // =============================================
    function renderHeroChart(trendData, countries, dateFrom, dateTo, options) {
        destroyChart('hero-chart');
        destroyChart('brush-chart');

        var showPatchTuesdays = options.showPatchTuesdays;
        var autoScale = options.autoScale;

        // Build series
        var series = [];
        countries.forEach(function(code, idx) {
            var records = trendData[code] || [];
            series.push({
                name: code,
                data: records.map(function(r) {
                    return { x: new Date(r.date).getTime(), y: +(r.compliance_score * 100).toFixed(4) };
                }),
            });
        });

        // Annotations
        var annotations = {};
        if (showPatchTuesdays) {
            annotations.xaxis = U.patchTuesdayAnnotations(dateFrom, dateTo);
        }

        var heroOptions = $.extend(true, {}, U.darkTheme(), {
            chart: {
                id: 'hero',
                type: 'line',
                height: 320,
                group: SYNC_GROUP,
                zoom: { autoScaleYaxis: autoScale },
                toolbar: { autoSelected: 'zoom' },
            },
            series: series,
            colors: U.COLORS.series.slice(0, countries.length),
            stroke: { width: 2, curve: 'smooth' },
            xaxis: { type: 'datetime' },
            yaxis: {
                title: { text: 'Compliance Score (%)' },
                labels: { formatter: function(val) { return val.toFixed(2) + '%'; } },
                min: autoScale ? undefined : 0,
                max: autoScale ? undefined : 100,
            },
            annotations: annotations,
            legend: {
                show: countries.length > 1,
                position: 'top',
            },
            tooltip: {
                x: { format: 'dd MMM yyyy' },
                y: { formatter: function(val) { return val.toFixed(4) + '%'; } },
            },
        });

        charts['hero-chart'] = new ApexCharts(document.getElementById('hero-chart'), heroOptions);
        charts['hero-chart'].render();

        // Brush chart (navigator)
        var brushOptions = $.extend(true, {}, U.darkTheme(), {
            chart: {
                id: 'brush',
                type: 'area',
                height: 80,
                brush: { target: 'hero', enabled: true },
                selection: {
                    enabled: true,
                    xaxis: {
                        min: new Date(dateFrom).getTime(),
                        max: new Date(dateTo).getTime(),
                    },
                },
                toolbar: { show: false },
            },
            series: series,
            colors: U.COLORS.series.slice(0, countries.length),
            stroke: { width: 1 },
            fill: { type: 'gradient', gradient: { opacityFrom: 0.3, opacityTo: 0.1 } },
            xaxis: { type: 'datetime' },
            yaxis: { show: false },
            legend: { show: false },
        });

        charts['brush-chart'] = new ApexCharts(document.getElementById('brush-chart'), brushOptions);
        charts['brush-chart'].render();
    }

    // =============================================
    // NON-COMPLIANT COUNT CHART
    // =============================================
    function renderNonCompliantChart(trendData, countries, options) {
        destroyChart('noncompliant-chart');

        var series = [];
        countries.forEach(function(code) {
            var records = trendData[code] || [];
            series.push({
                name: code,
                data: records.map(function(r) {
                    return { x: new Date(r.date).getTime(), y: r.non_compliant };
                }),
            });
        });

        var chartOptions = $.extend(true, {}, U.darkTheme(), {
            chart: {
                id: 'noncompliant',
                type: 'area',
                height: 200,
                group: SYNC_GROUP,
                toolbar: { show: false },
            },
            series: series,
            colors: [U.COLORS.red].concat(U.COLORS.series.slice(1, countries.length)),
            stroke: { width: 2, curve: 'smooth' },
            fill: { type: 'gradient', gradient: { opacityFrom: 0.4, opacityTo: 0.05 } },
            xaxis: { type: 'datetime' },
            yaxis: {
                title: { text: 'Non-Compliant Count' },
                labels: { formatter: function(val) { return Math.round(val); } },
            },
            legend: { show: countries.length > 1, position: 'top' },
            tooltip: {
                x: { format: 'dd MMM yyyy' },
            },
        });

        charts['noncompliant-chart'] = new ApexCharts(document.getElementById('noncompliant-chart'), chartOptions);
        charts['noncompliant-chart'].render();
    }

    // =============================================
    // PLATFORM BREAKDOWN CHARTS
    // =============================================
    function renderPlatformBreakdown(trendData, country, options) {
        var records = trendData[country] || [];
        if (records.length === 0) return;

        U.PLATFORMS.forEach(function(p) {
            var chartId = 'chart-' + p.key;
            destroyChart(chartId);

            var data = records.map(function(r) {
                return { x: new Date(r.date).getTime(), y: r[p.key] };
            });

            var annotations = {};
            if (options.showPatchTuesdays && p.key === 'mspatches') {
                var from = records[0].date;
                var to = records[records.length - 1].date;
                annotations.xaxis = U.patchTuesdayAnnotations(from, to);
            }

            var chartOptions = $.extend(true, {}, U.darkTheme(), {
                chart: {
                    id: 'platform-' + p.key,
                    type: 'line',
                    height: 120,
                    group: SYNC_GROUP,
                    toolbar: { show: false },
                },
                series: [{ name: p.label, data: data }],
                colors: [U.COLORS.series[U.PLATFORMS.indexOf(p)]],
                stroke: { width: 1.5, curve: 'smooth' },
                xaxis: { type: 'datetime', labels: { show: false } },
                yaxis: {
                    title: { text: p.label, style: { fontSize: '11px' } },
                    labels: {
                        formatter: function(val) { return Math.round(val); },
                        style: { fontSize: '10px' },
                    },
                },
                annotations: annotations,
                legend: { show: false },
                tooltip: {
                    x: { format: 'dd MMM yyyy' },
                    y: {
                        formatter: function(val) {
                            var total = records.length > 0 ? records[records.length - 1].enabled_ws : 0;
                            return val + ' / ' + total;
                        },
                    },
                },
            });

            charts[chartId] = new ApexCharts(document.getElementById(chartId), chartOptions);
            charts[chartId].render();
        });
    }

    // =============================================
    // COUNTRY HEATMAP
    // =============================================
    function renderCountryHeatmap(heatmapData) {
        destroyChart('country-heatmap');
        if (!heatmapData || heatmapData.length === 0) return;

        // Get all periods
        var allPeriods = [];
        heatmapData.forEach(function(c) {
            c.periods.forEach(function(p) {
                if (allPeriods.indexOf(p.period) === -1) allPeriods.push(p.period);
            });
        });
        allPeriods.sort();

        // Build series (each country is a series)
        var series = heatmapData.map(function(c) {
            return {
                name: c.name,
                data: allPeriods.map(function(period) {
                    var match = c.periods.find(function(p) { return p.period === period; });
                    return { x: period, y: match ? +(match.score * 100).toFixed(2) : null };
                }),
            };
        });

        // Sort by average score (worst first for visibility)
        series.sort(function(a, b) {
            var avgA = a.data.reduce(function(s, d) { return s + (d.y || 0); }, 0) / a.data.length;
            var avgB = b.data.reduce(function(s, d) { return s + (d.y || 0); }, 0) / b.data.length;
            return avgA - avgB;
        });

        var chartOptions = $.extend(true, {}, U.darkTheme(), {
            chart: {
                type: 'heatmap',
                height: Math.max(400, series.length * 28),
                toolbar: { show: true },
            },
            series: series,
            dataLabels: {
                enabled: true,
                formatter: function(val) { return val !== null ? val.toFixed(2) + '%' : ''; },
                style: { fontSize: '11px', fontWeight: 600, colors: ['#e8edf2'] },
            },
            plotOptions: {
                heatmap: {
                    colorScale: {
                        ranges: [
                            { from: 0, to: 94.99, color: U.COLORS.red, name: '< 95%' },
                            { from: 95, to: 97.49, color: U.COLORS.amber, name: '95-97.5%' },
                            { from: 97.5, to: 98.99, color: '#29b6f6', name: '97.5-99%' },
                            { from: 99, to: 100, color: U.COLORS.green, name: '99-100%' },
                        ],
                    },
                },
            },
            xaxis: {
                labels: { style: { fontSize: '10px' }, rotate: -45, rotateAlways: true },
            },
            yaxis: {
                labels: { style: { fontSize: '11px' } },
            },
            tooltip: {
                y: { formatter: function(val) { return val !== null ? val.toFixed(2) + '%' : 'N/A'; } },
            },
        });

        charts['country-heatmap'] = new ApexCharts(document.getElementById('country-heatmap'), chartOptions);
        charts['country-heatmap'].render();
    }

    // =============================================
    // COUNTRY RANKING
    // =============================================
    function renderCountryRanking(rankingData, selectedCountries) {
        destroyChart('country-ranking');
        if (!rankingData || rankingData.length === 0) return;

        var categories = rankingData.map(function(r) { return r.name; });
        var scores = rankingData.map(function(r) { return +(r.compliance_score * 100).toFixed(2); });
        var colors = rankingData.map(function(r) {
            var s = r.compliance_score * 100;
            if (selectedCountries.indexOf(r.country) >= 0) return U.COLORS.blue;
            if (s >= 99) return U.COLORS.green;
            if (s >= 97) return '#66bb6a';
            if (s >= 95) return U.COLORS.amber;
            return U.COLORS.red;
        });

        var chartOptions = $.extend(true, {}, U.darkTheme(), {
            chart: {
                type: 'bar',
                height: Math.max(400, rankingData.length * 26),
                toolbar: { show: false },
            },
            series: [{ name: 'Compliance Score', data: scores }],
            plotOptions: {
                bar: {
                    horizontal: true,
                    barHeight: '70%',
                    distributed: true,
                    dataLabels: { position: 'top' },
                },
            },
            colors: colors,
            dataLabels: {
                enabled: true,
                formatter: function(val) { return val.toFixed(2) + '%'; },
                style: { fontSize: '11px', colors: ['#e8edf2'] },
                offsetX: 30,
            },
            xaxis: {
                categories: categories,
                min: 90,
                max: 100,
                labels: { formatter: function(val) { return val.toFixed(1) + '%'; } },
            },
            yaxis: {
                labels: { style: { fontSize: '11px' } },
            },
            legend: { show: false },
            tooltip: {
                y: { formatter: function(val) { return val.toFixed(4) + '%'; } },
            },
        });

        charts['country-ranking'] = new ApexCharts(document.getElementById('country-ranking'), chartOptions);
        charts['country-ranking'].render();
    }

    // =============================================
    // COUNTRY RADAR
    // =============================================
    function renderCountryRadar(trendData, countries) {
        destroyChart('country-radar');
        if (countries.length === 0) return;

        // Use latest record for each country
        var series = [];
        countries.slice(0, 4).forEach(function(code) {
            var records = trendData[code] || [];
            if (records.length === 0) return;
            var latest = records[records.length - 1];
            var enabled = latest.enabled_ws;
            series.push({
                name: code,
                data: U.PLATFORMS.map(function(p) {
                    return +((latest[p.key] / enabled) * 100).toFixed(2);
                }),
            });
        });

        var chartOptions = $.extend(true, {}, U.darkTheme(), {
            chart: {
                type: 'radar',
                height: 380,
                toolbar: { show: false },
            },
            series: series,
            colors: U.COLORS.series.slice(0, countries.length),
            xaxis: {
                categories: U.PLATFORMS.map(function(p) { return p.label; }),
            },
            yaxis: {
                min: 90,
                max: 100,
                tickAmount: 5,
                labels: { formatter: function(val) { return val.toFixed(0) + '%'; } },
            },
            stroke: { width: 2 },
            fill: { opacity: 0.15 },
            markers: { size: 3 },
            legend: { position: 'bottom' },
            tooltip: {
                y: { formatter: function(val) { return val.toFixed(2) + '%'; } },
            },
        });

        charts['country-radar'] = new ApexCharts(document.getElementById('country-radar'), chartOptions);
        charts['country-radar'].render();
    }

    // =============================================
    // FLEET TREND CHART (dual axis)
    // =============================================
    function renderFleetTrend(trendData, country) {
        destroyChart('fleet-trend-chart');
        var records = trendData[country] || [];
        if (records.length === 0) return;

        var chartOptions = $.extend(true, {}, U.darkTheme(), {
            chart: {
                type: 'line',
                height: 300,
                toolbar: { show: true },
            },
            series: [
                {
                    name: 'Enabled WS',
                    type: 'area',
                    data: records.map(function(r) {
                        return { x: new Date(r.date).getTime(), y: r.enabled_ws };
                    }),
                },
                {
                    name: 'Compliance Score',
                    type: 'line',
                    data: records.map(function(r) {
                        return { x: new Date(r.date).getTime(), y: +(r.compliance_score * 100).toFixed(2) };
                    }),
                },
            ],
            colors: [U.COLORS.blue, U.COLORS.green],
            stroke: { width: [1, 2], curve: 'smooth' },
            fill: {
                type: ['gradient', 'solid'],
                gradient: { opacityFrom: 0.3, opacityTo: 0.05 },
            },
            xaxis: { type: 'datetime' },
            yaxis: [
                {
                    title: { text: 'Enabled WS' },
                    labels: { formatter: function(val) { return Math.round(val); } },
                },
                {
                    opposite: true,
                    title: { text: 'Compliance (%)' },
                    labels: { formatter: function(val) { return val.toFixed(2) + '%'; } },
                },
            ],
            legend: { position: 'top' },
            tooltip: { x: { format: 'dd MMM yyyy' } },
        });

        charts['fleet-trend-chart'] = new ApexCharts(document.getElementById('fleet-trend-chart'), chartOptions);
        charts['fleet-trend-chart'].render();
    }

    // =============================================
    // CHANGES TABLE (DataTables)
    // =============================================
    function renderChangesTable(changesData) {
        if ($.fn.DataTable.isDataTable('#changes-table')) {
            $('#changes-table').DataTable().destroy();
        }
        $('#changes-table tbody').empty();

        if (!changesData || changesData.length === 0) {
            $('#changes-table tbody').append('<tr><td colspan="10" style="text-align:center;color:#5a6f80;">No significant changes found</td></tr>');
            return;
        }

        var rows = changesData.map(function(c) {
            function fmtDelta(val) {
                if (val === 0) return '<span class="delta-neutral">0</span>';
                var cls = val > 0 ? 'delta-positive' : 'delta-negative';
                var sign = val > 0 ? '+' : '';
                return '<span class="' + cls + '">' + sign + val + '</span>';
            }

            return [
                c.date,
                c.enabled_ws + ' (' + (c.enabled_ws_delta >= 0 ? '+' : '') + c.enabled_ws_delta + ')',
                fmtDelta(c.deltas.mecm),
                fmtDelta(c.deltas.sentinelone),
                fmtDelta(c.deltas.inventory),
                fmtDelta(c.deltas.mspatches),
                fmtDelta(c.deltas.bitlocker),
                fmtDelta(c.deltas.winbuild),
                '<span class="' + (c.score_delta >= 0 ? 'delta-positive' : 'delta-negative') + '">' +
                    (c.score_delta >= 0 ? '+' : '') + (c.score_delta * 100).toFixed(4) + '%</span>',
                fmtDelta(c.nc_delta),
            ];
        });

        $('#changes-table').DataTable({
            data: rows,
            order: [[0, 'desc']],
            pageLength: 15,
            language: {
                emptyTable: 'No significant changes found',
            },
        });
    }

    // =============================================
    // PUBLIC API
    // =============================================
    return {
        renderKPICards: renderKPICards,
        renderSparklines: renderSparklines,
        renderGauge: renderGauge,
        renderHeroChart: renderHeroChart,
        renderNonCompliantChart: renderNonCompliantChart,
        renderPlatformBreakdown: renderPlatformBreakdown,
        renderCountryHeatmap: renderCountryHeatmap,
        renderCountryRanking: renderCountryRanking,
        renderCountryRadar: renderCountryRadar,
        renderFleetTrend: renderFleetTrend,
        renderChangesTable: renderChangesTable,
        destroyAll: destroyAll,
    };
})();

window.WCD = WCD;
