/**
 * Utility functions for the WCD Dashboard
 */
var WCD = window.WCD || {};

WCD.Utils = {
    PLATFORMS: [
        { key: 'mecm', label: 'MECM', icon: '\u2699' },
        { key: 'sentinelone', label: 'SentinelOne', icon: '\uD83D\uDEE1' },
        { key: 'inventory', label: 'Inventory', icon: '\uD83D\uDCE6' },
        { key: 'mspatches', label: 'MS Patches', icon: '\uD83D\uDD27' },
        { key: 'bitlocker', label: 'BitLocker', icon: '\uD83D\uDD12' },
        { key: 'winbuild', label: 'Win Build', icon: '\uD83D\uDCBB' },
    ],

    COLORS: {
        green: '#00c853',
        amber: '#ffb300',
        red: '#ff1744',
        blue: '#2979ff',
        purple: '#7c4dff',
        // Multi-series colors (colorblind-safe)
        series: [
            '#2979ff', '#00c853', '#ff6d00', '#aa00ff',
            '#ff1744', '#00bcd4', '#ffb300', '#76ff03',
            '#d500f9', '#1de9b6'
        ],
    },

    /**
     * Format a number with commas: 1234 -> "1,234"
     */
    formatNumber: function(n) {
        if (n === null || n === undefined) return '-';
        return n.toLocaleString();
    },

    /**
     * Format compliance score as percentage: 0.9867 -> "98.67%"
     */
    formatScore: function(score) {
        if (score === null || score === undefined) return '-';
        return (score * 100).toFixed(2) + '%';
    },

    /**
     * Format a count vs total: "98 / 100"
     */
    formatCount: function(count, total) {
        return WCD.Utils.formatNumber(count) + ' / ' + WCD.Utils.formatNumber(total);
    },

    /**
     * Format delta with sign and color class
     * Returns { text: "+5", cssClass: "positive|negative|neutral" }
     */
    formatDelta: function(value, invert) {
        if (value === null || value === undefined) return { text: '-', cssClass: 'neutral' };
        var sign = value > 0 ? '+' : '';
        var cssClass = value > 0 ? 'positive' : value < 0 ? 'negative' : 'neutral';
        if (invert) {
            cssClass = value > 0 ? 'negative' : value < 0 ? 'positive' : 'neutral';
        }
        return { text: sign + value, cssClass: cssClass };
    },

    /**
     * Format delta for score (percentage points)
     */
    formatScoreDelta: function(current, previous) {
        if (!previous) return { text: '-', cssClass: 'neutral' };
        var delta = (current - previous) * 100;
        var sign = delta > 0 ? '+' : '';
        var cssClass = delta > 0 ? 'positive' : delta < 0 ? 'negative' : 'neutral';
        return { text: sign + delta.toFixed(2) + '%', cssClass: cssClass };
    },

    /**
     * Get date string N days ago from a reference date
     */
    daysAgo: function(days, from) {
        var d = from ? new Date(from) : new Date();
        d.setDate(d.getDate() - days);
        return d.toISOString().split('T')[0];
    },

    /**
     * Get today's date as YYYY-MM-DD
     */
    today: function() {
        return new Date().toISOString().split('T')[0];
    },

    /**
     * Compute Patch Tuesdays (2nd Tuesday) for a date range
     */
    getPatchTuesdays: function(from, to) {
        var tuesdays = [];
        var d = new Date(from);
        d.setDate(1); // start of month

        while (d <= new Date(to)) {
            var year = d.getFullYear();
            var month = d.getMonth();
            // Find 2nd Tuesday
            var firstDay = new Date(year, month, 1).getDay();
            var firstTuesday = (9 - firstDay) % 7 + 1; // day of first Tuesday
            var secondTuesday = firstTuesday + 7;
            var ptDate = new Date(year, month, secondTuesday);
            var ptStr = ptDate.toISOString().split('T')[0];
            if (ptStr >= from && ptStr <= to) {
                tuesdays.push(ptStr);
            }
            // Next month
            d.setMonth(d.getMonth() + 1);
        }
        return tuesdays;
    },

    /**
     * Build ApexCharts annotation objects for Patch Tuesdays
     */
    patchTuesdayAnnotations: function(from, to) {
        var pts = WCD.Utils.getPatchTuesdays(from, to);
        return pts.map(function(dateStr) {
            return {
                x: new Date(dateStr).getTime(),
                borderColor: '#7c4dff',
                strokeDashArray: 4,
                label: {
                    text: 'PT',
                    orientation: 'horizontal',
                    style: {
                        background: '#7c4dff',
                        color: '#fff',
                        fontSize: '9px',
                        padding: { left: 4, right: 4, top: 2, bottom: 2 },
                    },
                    position: 'top',
                },
            };
        });
    },

    /**
     * Common ApexCharts theme options for dark mode
     */
    darkTheme: function() {
        return {
            theme: { mode: 'dark' },
            chart: {
                background: 'transparent',
                foreColor: '#8899aa',
                fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif',
                zoom: { allowMouseWheelZoom: false },
                toolbar: { show: true, tools: { download: true, selection: true, zoom: true, zoomin: true, zoomout: true, pan: true, reset: true } },
            },
            grid: {
                borderColor: '#2a3a4a',
                strokeDashArray: 3,
            },
            tooltip: {
                theme: 'dark',
            },
        };
    },
};

window.WCD = WCD;
