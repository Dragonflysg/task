"""Run inside the PTY to restore Ctrl+C handling inherited from PM2/pythonw."""
import ctypes
from ctypes import wintypes
import subprocess
import sys


def main():
    kernel32 = ctypes.WinDLL('kernel32', use_last_error=True)
    handler_type = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.DWORD)
    kernel32.SetConsoleCtrlHandler.argtypes = [ctypes.c_void_p, wintypes.BOOL]
    kernel32.SetConsoleCtrlHandler.restype = wintypes.BOOL
    # The ignore flag is inherited; ordinary registered handlers are not.
    if not kernel32.SetConsoleCtrlHandler(None, False):
        raise ctypes.WinError(ctypes.get_last_error())

    @handler_type
    def keep_launcher_alive(event):
        return event in (0, 1)  # Ctrl+C / Ctrl+Break: let the shell handle these.

    if not kernel32.SetConsoleCtrlHandler(keep_launcher_alive, True):
        raise ctypes.WinError(ctypes.get_last_error())
    # Keep the callback alive until the shell exits. Do not create a new group:
    # CREATE_NEW_PROCESS_GROUP would disable Ctrl+C again in the child.
    child = subprocess.Popen([sys.argv[1]])
    return child.wait()


if __name__ == '__main__':
    raise SystemExit(main())
