# IES: Functions and Files

Local, evolving PowerBuilder inventory built with Flask, jQuery, HTML and CSS. IBM Plex Sans and jQuery are bundled locally so the interface works without a CDN.

## Run

From `C:\PROJECTS\POWERBUILDER\object-atlas`:

```powershell
python -m pip install -r requirements.txt
python app.py
```

Open http://127.0.0.1:5055. Use the Flask URL, not a directly opened HTML file. The backend must remain running for uploads and saves.

## Backend organization

`app.py` creates the Flask app, registers HTTP endpoints with `add_url_rule`, and starts the server. `controllers_server.py` contains the endpoint handlers, validation, upload logic, and shared response helpers. `storage.py` handles SQLite transactions and the JSON migration. `storage_json_legacy.py` is used only to recover older SQLite-only workspaces when no JSON exists.

`build_response(JSONDATA, status=200)` creates JSON responses; `_build_cors_preflight_response()` answers OPTIONS requests. CORS allows the current origin by default. To allow a separate frontend, set `ATLAS_CORS_ORIGINS` before starting the server to a comma-separated list of exact origins, including scheme and port (no trailing slash). Write requests still require `X-Atlas-Request: 1`. No additional package is needed.

To add an endpoint, define its function in `controllers_server.py`, then add an `app.add_url_rule('/api/example', view_func=controllers.example, methods=['GET'])` line inside `create_app` in `app.py`.

## Application workflow

Select a category → select a function in the Classic sidebar → add its screenshot and comments → upload files into colored extension folders. Multiple files and drag-and-drop are supported. Click a file badge to download. Function comments save automatically after a short pause; an explicit Save comments button is also available. Moving between functions/categories saves outstanding notes. A failed save keeps the existing view and unsaved text.

Main-System starts with the eight function names in Menu.jpg as confirmed by the user. Main-Invoices starts empty. Add function creates another entry in the current category. Filename references shown in Menu.jpg are not uploaded source files and are not seeded as actual files.

Each function has its own photo gallery, files and comments. Category photos appear on the main menu. Three common folders are visible initially; Show other object types reveals SRU, SRM, SRS, SRA, SRQ and SRJ. Folders with uploads remain visible.

## Local storage

```text
workspace/
  inventory-live.sqlite3               # live database
  inventory.json                       # preserved pre-migration JSON
  inventory.sqlite3                    # older database, retained unchanged
  backups/                             # mappings saved before JSON imports
  Main-System/
    _photos/                           # category images; old images retained
    Invoice_Search_New_Amend_Delete_Search/
      srw/
      srf/
      srd/
      ...
  Main-Invoices/
    _photos/
    [function folder]/
      [extension]/
```

Folder names are sanitized for Windows. Newly created functions have a short unique suffix. Duplicate uploaded filenames get numbered suffixes rather than overwriting. Stop the server before copying the entire workspace folder for a complete backup, including inventory-live.sqlite3. Do not manually move registered files; the index currently tracks the original locations. Set ATLAS_DATA_DIR to choose another storage root before starting.

Uploads: 32 MB total per request, up to 50 source files per request. Each source folder accepts its matching extension. Photos accept validated PNG, JPEG or WebP images up to 30 megapixels and are re-encoded as JPEG. This is an inventory, not a PowerBuilder compiler or dependency parser.

## Verification

```powershell
python -m unittest -v test_app.py
node --check static/app.js
```

Tests use temporary storage and do not add sample uploads to the user's workspace. This first version runs on loopback for local use, without accounts, remote hosting or a production server. Future iterations can add source previews, dependency mapping and category editing.

## Third-party assets

jQuery 3.7.1: https://jquery.org/license/ (MIT; license header retained in vendor file).
IBM Plex Sans: https://github.com/IBM/plex (SIL Open Font License; license copied in static/vendor).
Flask upload guidance: https://flask.palletsprojects.com/en/stable/patterns/fileuploads/

## SQLite storage and JSON exchange

`workspace/inventory-live.sqlite3` is the live database. On its first initialization it imports the current `inventory.json`; the older `inventory.sqlite3` is never used when JSON exists. Both old files remain unchanged. Later starts use the live SQLite database, so manual edits to the old JSON do not affect the app.

Categories, functions, and active source files have separate tables with foreign-key ownership and indexes. Additional attributes, comments, photo references, histories, and custom fields are preserved in JSON payload columns. Each edit runs in a SQLite transaction; only changed object rows are updated. Connections coordinate concurrent writes with a 30-second busy timeout. The current UI still loads the full inventory, and the database resides on the Flask server's local disk, not a shared network drive.

Use **Export JSON** in the header to download the current mapping. Use **Import JSON** to replace that mapping after confirmation. Before each import, the app saves the previous mapping to `workspace/backups/before-import-<unique ID>.json`. Invalid relationships, unsafe paths, and missing active source/image files are rejected. Unknown fields are preserved. Import/export carries metadata only, not the image or source bytes; move the corresponding folders as part of transferring a project. Importing an empty valid mapping intentionally clears the inventory, with the previous mapping recoverable from the backup.

Images and source files remain in their existing folders. Removing an item from the UI preserves its file on disk. Personal review flags remain in browser local storage and are not exported. For a full backup, stop the Flask server and copy the complete workspace directory. Do not replace or manually edit the SQLite file while the app runs.

## Classic layout

The main app now uses the approved Classic theme, with the function list on the left and details on the right. The first function is selected when opening a category. Add function opens a form in the sidebar and selects the newly created function. Function screenshots are stored under category/function/_photos; the function record stores photos, photo, and photo_history. Older JSON files remain compatible and acquire these fields when screenshots are uploaded. The separate theme galleries remain available; browser-only prototype data is separate from the main project and is not imported automatically.

Each filename has a trash icon that removes its active card association only. The physical source file stays in its original folder, and its metadata moves from the function’s files list to detached_files in the live database. This is not a disk deletion. Re-uploading the same filename still uses numbered suffixes to preserve the original.
