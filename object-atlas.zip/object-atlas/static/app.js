/* jQuery UI: server-backed metadata and file uploads. */
$(function () {
  'use strict';
  let inventory, currentCategory=null, currentFunction=null, more=false, busy=false, saveTimer;
  const dirty={function:false};
  const selectedPhotos={};
  let photoUploadTarget=null;
  const reviewKey=id=>'ies:reviewed-file:v1:'+id;
  function isReviewed(id){try{return localStorage.getItem(reviewKey(id))==='1';}catch{return false;}}
  function updateReviewButton(button){
    const reviewed=isReviewed(button.attr('data-id'));
    button.attr({'aria-pressed':String(reviewed),title:(reviewed?'Reviewed — click to unmark':'Mark as reviewed')+' (this browser only)'});
  }
  $(window).on('storage',function(event){
    const key=event.originalEvent.key;
    if(key===null||key.startsWith('ies:reviewed-file:v1:'))$('#folders .review-file').each(function(){updateReviewButton($(this));});
  });
  $('.app-top').append('<div class="inventory-tools"><a class="classic-button" href="/api/inventory/export">Export JSON</a><button type="button" id="import-json" class="classic-button">Import JSON</button><input type="file" id="import-json-file" accept=".json,application/json" hidden></div>');
  $('#import-json').on('click',()=>$('#import-json-file').trigger('click'));
  $('#import-json-file').on('change',function(){
    const file=this.files[0];this.value='';if(!file)return;
    action(async()=>{
      if(file.size>32*1024*1024)throw {responseJSON:{error:'Choose a JSON file smaller than 32 MB.'}};
      let data;try{data=JSON.parse(await file.text());}catch{throw {responseJSON:{error:'This file is not valid JSON.'}};}
      if(!confirm('Import '+file.name+'? This replaces the shared category/function/file mapping for all developers. A backup of the current mapping will be saved. Referenced photos and files must already be in this workspace.'))return;
      await saveNotes();
      const result=await $.ajax({url:'/api/inventory/import',method:'POST',contentType:'application/json',data:JSON.stringify(data)});
      currentCategory=null;currentFunction=null;$('#detail').prop('hidden',true);$('#home').prop('hidden',false);
      await refresh();notice('JSON imported. Previous mapping saved in '+result.backup);
    });
  });
  $.ajaxSetup({headers:{'X-Atlas-Request':'1'}});
  function notice(text,error=false){$('#message').text(text).toggleClass('error',error).prop('hidden',false);}
  function failure(xhr){notice(xhr.responseJSON?.error || 'Could not reach the server. Your changes have not been saved. Please retry.',true);}
  function cat(){return inventory.categories.find(c=>c.id===currentCategory)}
  function fn(){return cat()?.functions.find(f=>f.id===currentFunction)}
  function clearMessage(){$('#message').prop('hidden',true)}
  function refresh(){return $.getJSON('/api/inventory').then(data=>{inventory=data;renderHome();if(currentCategory)renderDetail();});}
  function renderHome(){
    const list=$('#categories').empty();
    inventory.categories.forEach(c=>{
      const count=c.functions.reduce((n,f)=>n+f.files.length,0);
      const card=$('<article class="category category-card">');
      const open=$('<button class="category-open">').attr({'data-id':c.id,'aria-label':'Open '+c.name});
      const thumb=$('<span class="category-thumbnail">');
      if(c.photo_url)thumb.append($('<img>').attr({src:c.photo_url,alt:c.name+' screenshot',loading:'lazy'}));
      else thumb.append($('<span class="thumbnail-placeholder">').append('<span aria-hidden="true">▧</span>',$('<span>').text('Category screenshot')));
      open.append(thumb,$('<span class="category-caption">').append($('<strong>').text(c.name),$('<small>').text(`${c.functions.length} functions · ${count} ${count===1?'file':'files'}`),$('<span class="category-open-arrow" aria-hidden="true">').text('→')));
      card.append(open,$('<div class="category-photo-actions">').append($('<button class="category-photo-upload classic-button">').text(c.photo_url?'Replace photo':'＋ Upload photo').attr('aria-label',(c.photo_url?'Replace photo for ':'Upload photo for ')+c.name),$('<small>').text('PNG / JPG / WebP')),$('<input type="file" class="category-photo-input" hidden>').attr({'data-id':c.id,accept:'image/png,image/jpeg,image/webp'}));
      list.append(card);
    });
    $('#category-count').text(String(inventory.categories.length).padStart(2,'0'));
    list.append($('<button class="category add-category" id="add-category" aria-label="Add category">').append('<span class="add-category-plus">＋</span><strong>Add</strong>'));
  }
  function renderDetail(){const c=cat();if(!c)return;$('#home').prop('hidden',true);$('#detail').prop('hidden',false);$('#crumb,#category-title').text(c.name);$('#function-count').text(c.functions.length+' functions');
    const list=$('#function-list').empty();c.functions.forEach(f=>list.append($('<button class="function-item">').attr({'data-id':f.id,'aria-pressed':String(f.id===currentFunction)}).text(f.name)));if(!c.functions.some(f=>f.id===currentFunction))currentFunction=c.functions[0]?.id||null;$('#empty-functions').prop('hidden',!!currentFunction);$('#function-content').prop('hidden',!currentFunction);renderFunction();
  }
  function renderFunction(){if(!fn())return;const f=fn();$('#function-title').text(f.name);$('#function-list .function-item').each(function(){$(this).attr('aria-pressed',String($(this).attr('data-id')===currentFunction))});renderPhotos();$('#file-total').text(f.files.length+' source '+(f.files.length===1?'file':'files'));$('#function-comment').val(f.comment);$('#function-save-state').text('');dirty.function=false;$('#storage-path').text(`workspace / ${cat().name} / ${f.folder} / [file type]`);const grid=$('#folders').empty();const primary=['srw','srf','srd'];const ordered=[...primary,...Object.keys(inventory.types).filter(t=>!primary.includes(t))];ordered.forEach(type=>{const files=f.files.filter(x=>x.type===type);const card=$('<div class="folder">').attr('data-type',type).prop('hidden',!more&&!primary.includes(type)&&!files.length);card.append($('<span class="folder-tab">').text('.'+type));card.append($('<div class="folder-header">').append($('<h4>').text(inventory.types[type]+' ').append($('<span class="extension-badge">').text('(.'+type+')')),$('<button class="add-file">').attr({'aria-label':'Upload .'+type+' files',title:'Add files'}).text('+')));const badges=$('<div class="badges">');files.forEach(file=>{
        const row=$('<div class="file-row">');
        row.append($('<a class="file-badge">').attr({href:'/api/files/'+file.id,title:'Download '+file.name}).append($('<span class="filename">').text(file.name),$('<small>').text(Math.max(1,Math.ceil(file.size/1024))+' KB')));
        const review=$('<button type="button" class="review-file">').attr({'data-id':file.id,'aria-label':'Reviewed: '+file.name});
        review.html('<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="1.7" aria-hidden="true"><path d="M5 21V3m0 1c5-4 9 4 14 0v10c-5 4-9-4-14 0"/></svg>');
        updateReviewButton(review);row.prepend(review);
        const view=$('<button type="button" class="view-file file-tool">').attr({'data-id':file.id,'aria-label':'View contents of '+file.name,title:'View file contents'});
        view.html('<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="1.7" aria-hidden="true"><path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/></svg>');
        const inspect=$('<button type="button" class="inspect-file file-tool" aria-disabled="true">').attr({'aria-label':'Analyze '+file.name+' (coming later)',title:'Analysis — coming later'});
        inspect.html('<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="1.7" aria-hidden="true"><circle cx="10" cy="10" r="6"/><path d="m15 15 6 6"/></svg>');
        row.append(view,inspect);
        const remove=$('<button type="button" class="remove-file">').attr({'data-id':file.id,'aria-label':'Remove '+file.name+' from this card (keep file on disk)',title:'Remove from card — keep file on disk'});
        remove.html('<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13M10 10v7M14 10v7"/></svg>');
        row.append(remove);badges.append(row);
      });card.append(badges);if(!files.length)card.append($('<p class="folder-empty">').text('No files yet. Add your first export.'));card.append($('<div class="folder-footer">').text('Drop .'+type+' files here · multiple files welcome'));card.append($('<input type="file" multiple hidden class="file-input">').attr('accept','.'+type));grid.append(card)});$('#more-types').text(more?'Show fewer object types ↑':'Show other object types ↓');}
  async function saveNotes(){
    if(dirty.function&&currentFunction){const id=currentFunction, comment=$('#function-comment').val();await $.ajax({url:'/api/functions/'+id+'/comment',method:'PUT',contentType:'application/json',data:JSON.stringify({comment})});fn().comment=comment;dirty.function=false;$('#function-save-state').text('')}
  }
  async function action(work){if(busy)return;clearTimeout(saveTimer);busy=true;clearMessage();const controls=$('button,select,textarea,input');controls.prop('disabled',true);try{await work()}catch(xhr){failure(xhr)}finally{busy=false;controls.prop('disabled',false);if(currentCategory&&!currentFunction)$('#function-select').prop('disabled',true)}}
  $('#categories').on('click','.category-open[data-id]',function(){currentCategory=$(this).attr('data-id');currentFunction=null;more=false;clearMessage();renderDetail();window.scrollTo(0,0)});
  $('#categories').on('click','.category-photo-upload',function(){$(this).closest('.category-card').find('.category-photo-input').trigger('click')});
  $('#categories').on('change','.category-photo-input',function(){
    const file=this.files[0],id=$(this).attr('data-id');this.value='';if(!file)return;
    action(async()=>{
      if(file.size>32*1024*1024)throw {responseJSON:{error:'Choose a photo smaller than 32 MB.'}};
      const data=new FormData();data.append('photo',file);
      await $.ajax({url:'/api/categories/'+id+'/photo',method:'POST',data,contentType:false,processData:false});
      await refresh();notice('Category photo saved.');
    });
  });
  $('#categories').on('click','#add-category',()=>{$('#new-category').prop('hidden',false);$('#new-category-name').trigger('focus')});
  $('#cancel-category').on('click',()=>{$('#new-category').prop('hidden',true);$('#new-category-name').val('');clearMessage()});
  $('#new-category').on('submit',function(e){e.preventDefault();const name=$('#new-category-name').val().trim();action(async()=>{const result=await $.ajax({url:'/api/categories',method:'POST',contentType:'application/json',data:JSON.stringify({name})});currentCategory=result.id;currentFunction=null;more=false;$('#new-category').prop('hidden',true);$('#new-category-name').val('');await refresh();notice('Category created. Add a function to begin.');window.scrollTo(0,0)})});
  $('.back,.brand').on('click',function(e){e.preventDefault();action(async()=>{await saveNotes();currentCategory=null;currentFunction=null;$('#detail').prop('hidden',true);$('#home').prop('hidden',false);$('#new-function').prop('hidden',true);renderHome();window.scrollTo(0,0)})});
  $('#function-comment').on('input',()=>{dirty.function=true;$('#function-save-state').text('Unsaved changes');clearTimeout(saveTimer);saveTimer=setTimeout(()=>action(saveNotes),900)});
  $('#save-function').on('click',()=>action(async()=>{await saveNotes();notice('Comments saved.')}));
  $('#function-list').on('click','.function-item',function(){const next=$(this).attr('data-id');action(async()=>{await saveNotes();currentFunction=next;renderFunction()})});
  const photoViewer=document.getElementById('photo-viewer');
  function photos(){return fn()?.photo_items||[];}
  function currentPhoto(){const items=photos();return items.find(p=>p.id===selectedPhotos[currentFunction])||items[0];}
  function renderPhotos(){
    const f=fn();if(!f)return;const items=photos(),photo=currentPhoto();
    if(photo)selectedPhotos[currentFunction]=photo.id;
    $('#function-photo').prop('hidden',!photo);$('.photo-empty').prop('hidden',!!photo);$('#remove-photo').prop('hidden',!photo);
    $('#photo-target').attr({'aria-label':photo?'View larger screenshot of '+f.name:'Add screenshot for '+f.name,title:photo?'Click to enlarge':'Upload screenshots'}).toggleClass('has-photo',!!photo);
    if(photo)$('#function-photo').attr({src:photo.url,alt:'Screen reference '+(items.indexOf(photo)+1)+' for '+f.name});else $('#function-photo').removeAttr('src');
    const thumbs=$('#photo-thumbnails').empty();items.forEach((p,index)=>thumbs.append($('<button type="button" class="photo-thumb">').attr({'data-photo-id':p.id,'aria-label':'Show photo '+(index+1),'aria-pressed':String(p.id===photo?.id)}).append($('<img>').attr({src:p.url,alt:'Photo '+(index+1),loading:'lazy'}))));
    const count=photo?(items.indexOf(photo)+1)+' / '+items.length:'No photos';$('#photo-counter,#modal-photo-counter').text(count);
    $('.photo-arrow').prop('hidden',items.length<2);$('#photo-viewer .photo-prev,#photo-viewer .photo-next').prop('hidden',items.length<2);
    if(photoViewer.open&&photo){$('#photo-viewer-title').text(f.name+' — Screen reference');$('#photo-viewer-image').attr({src:photo.url,alt:'Screen reference '+count+' for '+f.name})}
  }
  function choosePhotos(replace=false){if(!fn())return;photoUploadTarget={functionId:currentFunction,replace:replace?currentPhoto()?.id:null};$('#photo-input').prop('multiple',!replace).trigger('click');}
  $('#photo-target').on('click',()=>{
    if(!fn())return;const photo=currentPhoto();if(!photo){choosePhotos();return;}
    photoViewer.showModal();document.body.classList.add('photo-viewer-open');renderPhotos();
  });
  $('#remove-photo').on('click',()=>{
    const photo=currentPhoto(),functionId=currentFunction;
    if(!photo)return;
    const items=photos(),index=items.indexOf(photo),next=items[index+1]||items[index-1];
    action(async()=>{
      await saveNotes();
      await $.ajax({url:'/api/functions/'+encodeURIComponent(functionId)+'/photos/'+encodeURIComponent(photo.id),method:'DELETE'});
      if(next)selectedPhotos[functionId]=next.id;else delete selectedPhotos[functionId];
      await refresh();notice('Photo removed from the gallery. The original image is still on disk.');
    });
  });
  $('#photo-thumbnails').on('click','.photo-thumb',function(){selectedPhotos[currentFunction]=$(this).attr('data-photo-id');renderPhotos();$('#photo-thumbnails .photo-thumb[aria-pressed="true"]').trigger('focus')});
  function stepPhoto(delta){const items=photos();if(items.length<2)return;const index=items.indexOf(currentPhoto());selectedPhotos[currentFunction]=items[(index+delta+items.length)%items.length].id;renderPhotos();}
  $('.photo-prev').on('click',()=>stepPhoto(-1));$('.photo-next').on('click',()=>stepPhoto(1));
  photoViewer.addEventListener('keydown',e=>{if(e.key==='ArrowLeft'||e.key==='ArrowRight'){e.preventDefault();stepPhoto(e.key==='ArrowLeft'?-1:1)}});
  $('#close-photo-viewer').on('click',()=>photoViewer.close());
  photoViewer.addEventListener('click',event=>{
    if(event.target!==photoViewer)return;
    const box=photoViewer.getBoundingClientRect();
    if(event.clientX<box.left||event.clientX>box.right||event.clientY<box.top||event.clientY>box.bottom)photoViewer.close();
  });
  photoViewer.addEventListener('close',()=>{document.body.classList.remove('photo-viewer-open');$('#photo-viewer-image').removeAttr('src');$('#photo-target').trigger('focus')});
  async function uploadPhotos(files,target){
    if(!files.length||!target)return;
    await action(async()=>{await saveNotes();if(files.length>20||files.reduce((n,f)=>n+f.size,0)>32*1024*1024)throw {responseJSON:{error:'Choose up to 20 photos totaling less than 32 MB.'}};
      const data=new FormData();files.forEach(file=>data.append('photos',file));if(target.replace)data.append('replace',target.replace);
      const result=await $.ajax({url:'/api/functions/'+target.functionId+'/photos',method:'POST',data,contentType:false,processData:false});
      selectedPhotos[target.functionId]=result.selected;await refresh();notice(target.replace?'Photo replaced. The previous image is retained on disk.':files.length+' photo(s) added.');
    });
  }
  $('#photo-input').on('change',function(){
    const files=Array.from(this.files),target=photoUploadTarget;this.value='';uploadPhotos(files,target);
  });
  const screenReference=$('#photo-target').closest('section');
  screenReference.attr({tabindex:'0','aria-label':'Screen reference. Paste a screenshot with Control V.'});
  $('<button type="button" id="paste-photo" class="classic-button">Paste Photo</button>').prependTo('.photo-gallery-actions');
  screenReference.append('<p class="paste-photo-hint">Copy a screenshot, then click here and press Ctrl+V to add it.</p>');
  screenReference.on('click','.paste-photo-hint',()=>screenReference.trigger('focus'));
  function clipboardPhoto(blob,index){return new File([blob],'clipboard-'+Date.now()+'-'+index+'.'+(blob.type==='image/jpeg'?'jpg':blob.type==='image/webp'?'webp':'png'),{type:blob.type});}
  screenReference.on('paste',function(event){
    if(busy||!currentFunction||document.querySelector('dialog[open]'))return;
    const items=Array.from(event.originalEvent.clipboardData?.items||[]);
    const files=items.filter(item=>item.kind==='file'&&item.type.startsWith('image/')).map(item=>item.getAsFile()).filter(Boolean);
    if(!files.length)return;
    event.preventDefault();uploadPhotos(files.map(clipboardPhoto),{functionId:currentFunction,replace:null});
  });
  const pasteDialog=$('<dialog id="paste-photo-dialog" aria-labelledby="paste-photo-title"><h2 id="paste-photo-title">Paste a screenshot</h2><p>Capture with your Snipping Tool to get your screenshot. Then press Ctrl+V in the box below.</p><textarea id="paste-photo-box" aria-label="Paste screenshot here" placeholder="Press Ctrl+V here" autofocus></textarea><p id="paste-photo-status" role="status">Your screenshot will be added to this function.</p><button type="button" id="cancel-paste-photo">Cancel</button></dialog>').appendTo('body')[0];
  let pasteTarget=null;
  $('#paste-photo').on('click',()=>{
    if(busy||!currentFunction)return;
    clearMessage();pasteTarget={functionId:currentFunction,replace:null};
    $('#paste-photo-box').val('');$('#paste-photo-status').text('Your screenshot will be added to this function.');
    pasteDialog.showModal();$('#paste-photo-box').trigger('focus');
  });
  $('#paste-photo-box').on('paste',function(event){
    event.preventDefault();
    if(busy||!pasteTarget)return;
    const clipboard=event.originalEvent.clipboardData;
    const files=Array.from(clipboard?.files||[]).filter(file=>file.type.startsWith('image/'));
    if(!files.length){$('#paste-photo-status').text('No image received. Use your Snipping Tool to get your screenshot and press Ctrl+V again.');return;}
    const target=pasteTarget;
    pasteDialog.close();
    uploadPhotos(files.map(clipboardPhoto),target);
  });
  $('#cancel-paste-photo').on('click',()=>pasteDialog.close());
  pasteDialog.addEventListener('close',()=>{pasteTarget=null;$('#paste-photo-box').val('');});
  $('#more-types').on('click',()=>{more=!more;const note=$('#function-comment').val(),changed=dirty.function;renderFunction();$('#function-comment').val(note);dirty.function=changed;if(changed)$('#function-save-state').text('Unsaved changes');clearTimeout(saveTimer);saveTimer=setTimeout(()=>action(saveNotes),900)});
  async function upload(type,files){if(!files.length)return;await action(async()=>{await saveNotes();const data=new FormData();for(const file of files)data.append('files',file);await $.ajax({url:'/api/functions/'+currentFunction+'/files/'+type,method:'POST',data,processData:false,contentType:false});await refresh();notice(files.length+' file(s) saved. Click a filename badge to download it.')})}
  const codeDialog=$('<dialog id="code-viewer" aria-labelledby="code-file-title" aria-describedby="code-viewer-label"><header><h2 id="code-file-title"></h2><span id="code-viewer-label">Contents of the file</span><button type="button" id="copy-code" disabled>Copy Code</button></header><pre id="code-contents" tabindex="0"></pre><footer><span id="code-status" role="status"></span><button type="button" id="close-code" autofocus>Close</button></footer></dialog>').appendTo('body')[0];
  let codeRequest=null,codeText=null;
  function decodeSource(buffer){
    const bytes=new Uint8Array(buffer);
    if(bytes[0]===255&&bytes[1]===254)return {text:new TextDecoder('utf-16le',{fatal:true}).decode(bytes),encoding:'UTF-16 LE'};
    if(bytes[0]===254&&bytes[1]===255)return {text:new TextDecoder('utf-16be',{fatal:true}).decode(bytes),encoding:'UTF-16 BE'};
    try{return {text:new TextDecoder('utf-8',{fatal:true}).decode(bytes),encoding:'UTF-8'};}
    catch{return {text:new TextDecoder('windows-1252').decode(bytes),encoding:'Windows-1252 (assumed legacy encoding)'};}
  }
  $('#folders').on('click','.view-file',async function(){
    const id=$(this).attr('data-id'),file=fn()?.files.find(file=>file.id===id);
    if(!file)return;
    codeRequest?.abort();const controller=new AbortController();codeRequest=controller;codeText=null;
    $('#code-file-title').text(file.name);$('#code-contents').text('Loading…');$('#code-status').text('');$('#copy-code').prop('disabled',true);
    codeDialog.showModal();
    try{
      const response=await fetch('/api/files/'+encodeURIComponent(id),{signal:controller.signal});
      if(!response.ok)throw new Error('Could not load this file. Please close and try again.');
      const source=decodeSource(await response.arrayBuffer());
      if(codeRequest!==controller||!codeDialog.open)return;
      codeText=source.text;$('#code-contents').text(codeText);$('#copy-code').prop('disabled',false);$('#code-status').text(source.encoding+(codeText.length?'':' · Empty file'));
      $('#code-contents').scrollTop(0).scrollLeft(0);
    }catch(error){if(error.name!=='AbortError'&&codeRequest===controller){$('#code-contents').text('');$('#code-status').text(error.message);}}
  });
  $('#copy-code').on('click',async()=>{
    if(codeText===null)return;
    try{await navigator.clipboard.writeText(codeText);$('#code-status').text('Code copied.');}
    catch{$('#code-status').text('Clipboard access was blocked. Select the text and copy it manually.');}
  });
  $('#close-code').on('click',()=>codeDialog.close());
  codeDialog.addEventListener('close',()=>{codeRequest?.abort();codeRequest=null;codeText=null;$('#code-contents').text('');$('#copy-code').prop('disabled',true);});
  $('#folders').on('click','.review-file',function(){
    const button=$(this),id=button.attr('data-id');
    try{
      if(isReviewed(id))localStorage.removeItem(reviewKey(id));else localStorage.setItem(reviewKey(id),'1');
      updateReviewButton(button);
    }catch{notice('This browser could not save your review flag. Check that local storage is enabled.',true);}
  });
  const deleteDialog=$('<dialog id="delete-file-dialog" aria-labelledby="delete-file-title" aria-describedby="delete-file-question delete-file-note"><h2 id="delete-file-title">Delete file?</h2><p id="delete-file-question"></p><p id="delete-file-note">This removes the file from this card only. The original file stays on disk.</p><div class="delete-file-actions"><button type="button" id="confirm-delete-file">Delete</button><button type="button" id="cancel-delete-file" autofocus>Cancel</button></div></dialog>').appendTo('body')[0];
  let pendingDelete=null;
  $('#folders').on('click','.remove-file',function(){
    if(busy)return;
    const id=$(this).attr('data-id'),file=fn()?.files.find(file=>file.id===id);
    if(!file)return;
    pendingDelete=id;
    $('#delete-file-question').text('Are you sure you want to delete '+file.name+'?');
    deleteDialog.showModal();
  });
  $('#cancel-delete-file').on('click',()=>deleteDialog.close());
  deleteDialog.addEventListener('close',()=>{pendingDelete=null;});
  $('#confirm-delete-file').on('click',()=>{
    const id=pendingDelete;
    pendingDelete=null;
    deleteDialog.close();
    if(!id)return;
    action(async()=>{await saveNotes();await $.ajax({url:'/api/files/'+id,method:'DELETE'});await refresh();notice('Removed from the card. The original file is still on disk.');});
  });
  $('#folders').on('click','.add-file',function(){$(this).closest('.folder').find('.file-input').trigger('click')}).on('change','.file-input',function(){const files=Array.from(this.files),type=$(this).closest('.folder').attr('data-type');this.value='';upload(type,files)}).on('dragover','.folder',function(e){e.preventDefault();$(this).addClass('dragging')}).on('dragleave','.folder',function(){$(this).removeClass('dragging')}).on('drop','.folder',function(e){e.preventDefault();$(this).removeClass('dragging');upload($(this).attr('data-type'),Array.from(e.originalEvent.dataTransfer.files))});
  $('#add-function').on('click',()=>{$('#new-function').prop('hidden',false);$('#new-function-name').trigger('focus')});$('#cancel-function').on('click',()=>$('#new-function').prop('hidden',true));
  $('#new-function').on('submit',function(e){e.preventDefault();const name=$('#new-function-name').val().trim();action(async()=>{await saveNotes();const result=await $.ajax({url:'/api/categories/'+currentCategory+'/functions',method:'POST',contentType:'application/json',data:JSON.stringify({name})});currentFunction=result.id;$('#new-function').prop('hidden',true);$('#new-function-name').val('');await refresh();notice('Function created.')})});
  window.addEventListener('beforeunload',e=>{if(dirty.function||busy){e.preventDefault();e.returnValue=''}});
  refresh().fail(failure);
});
