# LLM Wiki — corporate gateway edition

Same engine as `C:\PROJECTS\LLMWIKI`, with two differences:

- The Anthropic adapter is gone. Generation goes through **one function**,
  `QueryLLM`, which you replace with your department's token + POST code.
- No web layer. No FastAPI, no uvicorn, no Jinja2, no templates. Everything is
  driven from the command line so you can read and evaluate the pipeline
  without a browser in the way.

**It runs on the Python standard library alone.** `requirements.txt` is empty.
The only dependency you will add is whatever your own gateway code needs.

## Run it

```
py build_wiki.py                  # offline: no network calls at all
py smoke_test.py                  # does the ask pipeline behave?
py gateway_test.py                # does it survive a flaky gateway?  (14 checks)

py ask.py "why can I read the shared mailbox but not send from it?"
py ask.py --gateway "how do I request a shared mailbox?"

py compare_modes.py --full        # is the model earning its calls?
py inspect_wiki.py --links        # the auto-link graph between pages
py scale_test.py 100 500          # what does a build cost at your corpus size?
```

Offline is the default everywhere. Nothing reaches the network unless you pass
`--gateway` or set `LLMWIKI_GATEWAY=1`.

## Where the gateway is used: answers only

This is the most important setting in the project, so it is worth being
explicit about. `config.py` ships with:

```python
GATEWAY_TASKS = {"answer"}
```

There are three stages that *could* call a model. Only the last one does:

| Stage | When | What it sends | Calls for a 300-file corpus | Enabled |
|---|---|---|---|---|
| `concepts` | build | every source file, whole | 300 | no |
| `page` | build | passages per page | 300-400 | no |
| `answer` | ask | 3 retrieved passages | 1 per new question | **yes** |

What that buys you:

- **The build is free and offline at any corpus size.** `py build_wiki.py
  --gateway` on the sample corpus makes **zero** calls. Rebuild as often as you
  like; add 200 files and it still makes zero.
- **The corpus is never bulk-transmitted.** Concept extraction would post every
  file you own to the gateway. Answer-time sends only the three passages
  relevant to a question somebody actually asked.
- **Pages stay extractive** - quoted verbatim from the source files, with
  `file:line` citations. For reference material that is arguably the better
  product: the page says what the document says, and nothing else.
- **Cost is proportional to use, not to size.** You pay per new question, once,
  and the cache means you do not pay again for a repeat.

To author the pages with the model anyway, opt in per build and read the cost
off the usage table:

```
py build_wiki.py --stages concepts,page     # 9 files -> 29 calls, ~24,500 tokens
```

`--stages` overrides `GATEWAY_TASKS` for one build and implies `--gateway`.

### The sequential throttle

Your gateway takes one request at a time, so `config.py` has:

```python
GATEWAY_MIN_INTERVAL_SECONDS = 0.0   # minimum seconds between calls
```

Leave it at 0 for answers-only, where calls arrive one per question anyway. Set
it to 0.5-1.0 before running `--stages` against the real endpoint, so a build
is not the reason a colleague gets rate limited. `gateway_test.py` case 8
verifies the spacing actually holds.

## Wiring in your gateway

Open `llmwiki/gateway.py`. Everything above it calls exactly one function:

```python
QueryLLM(prompt, system=None, temperature=0.2, domain="it-support", max_tokens=1200) -> str
```

Delete the dummy body, paste your real code in, keep the signature. That is the
whole integration. `GetToken()` is next to it and is called for you.

Two contracts the rest of the code depends on:

1. **Return the text, not the envelope.** `choices[0].message.content`, not the
   whole JSON.
2. **Raise `GatewayError(msg, status=...)` on failure. Never return None, never
   return an error string.** A returned `"I'm sorry, I cannot help with that"`
   would be written into a wiki page as if it were documentation. The status
   code matters: `401` triggers a token refresh, `429`/`503` trigger backoff and
   retry, anything else gives up and falls back to extraction.

Settings live in `llmwiki/config.py` (`GATEWAY_TEMPERATURE`, `GATEWAY_DOMAIN`,
`GATEWAY_MAX_RETRIES`, `GATEWAY_BACKOFF_SECONDS`, `GATEWAY_TASKS`,
`GATEWAY_MIN_INTERVAL_SECONDS`).

The dummy is not random text — it reads the excerpts back out of the prompt and
returns them with citation markers, so the citation plumbing is genuinely
exercised. What you are evaluating before you wire the real gateway in is the
*shape* of the pipeline, not the prose quality.

### Simulating a bad day

```python
from llmwiki.gateway import SIMULATE
SIMULATE["latency"] = (0.4, 1.2)   # what does a 29-call build actually cost in wall clock?
SIMULATE["fail_rate"] = 0.3        # one call in three fails
SIMULATE["expire_token"] = True    # token lapses mid-build
```

`gateway_test.py` provokes all of these deliberately. Current result: **14/14**.

## The three things worth knowing before you commit to this

### 1. The model never sees a question the corpus cannot answer

Retrieval and the coverage gate run **first**. If coverage is below
`MIN_COVERAGE` the question becomes a gap page and `QueryLLM` is never called.

```
py compare_modes.py   ->  5 questions, 4 calls sent
```

The fifth was "what is the guest wi-fi password?", which the corpus does not
cover. It cost nothing and produced no prose to hallucinate with. This is why
the gate is upstream of the model rather than a post-hoc filter — you cannot
talk the wiki into answering by rephrasing.

### 2. Caching turns a 29-call rebuild into a 2-call rebuild

Every prompt is hashed with the settings that shaped it. Measured on this
corpus:

| Build | Calls sent | Prompt tokens |
|---|---|---|
| `--stages concepts,page`, cold cache | 29 | ~24,500 |
| rebuild, nothing changed | **0** | 0 |
| rebuild after editing one Q&A in `accounts.txt` | **2** | ~2,400 |

Nine files → 9 concept calls; fourteen concepts → 20 page calls. Scale that
linearly before you enable those stages on a real corpus: **300 topic files is
roughly 300 + N calls for a cold build.** With the cache, only the files you
actually touched cost anything after that. On the shipped answers-only default
all three rows are zero, because the build never calls out at all.

**The cache matters just as much in answers-only mode**, for a reason that is
easy to miss: `build_wiki.py` clears `data/answers.json` on every rebuild, so
every previously-answered question is asked from scratch the next time somebody
visits it. Without the prompt cache you would re-pay for all of them on every
rebuild. With it you pay only for the questions whose *retrieved passages*
changed — which is precisely the set whose answers might now be different.

Cost is not the only reason. A wiki whose unrelated pages quietly reword
themselves on every rebuild is one nobody trusts. Caching makes the build
reproducible: same corpus in, same wiki out.

Cache invalidation is free because the key *is* the content — edit a file and
the prompts containing it hash differently, so stale entries are simply never
looked up again. `--prune-cache` removes them; `--no-cache` bypasses.

### 3. A gateway outage degrades the wiki, it does not break it

`complete()` returns `None` on final failure and every caller falls back to
extraction. `gateway_test.py` case 4 kills the gateway completely mid-build and
asserts that the build still finishes, the pages still have bodies, and every
failure is recorded rather than raised.

That is the behaviour you want on a shared corporate endpoint. An internal
knowledge base that answers slightly more plainly is working. One that returns
a traceback is not.

### 4. It behaves at 100-500 files, but check the concept cap

`py scale_test.py 100 500` builds a synthetic corpus of that size and times
each stage. On a laptop:

| Files | Blocks | Concepts (mined) | Build |
|---|---|---|---|
| 100 | 900 | 114 (14 cross-file) | 0.5s |
| 300 | 2,700 | 314 (14 cross-file) | 2.8s |
| 500 | 4,500 | 514 (14 cross-file) | 6.9s |

Fast enough that build time is a non-issue at your size. The number to watch is
the one in brackets.

`MAX_MINED_CONCEPTS` caps the **cross-cutting** concepts — pages like *Send As*
or *DFS* that no single file owns and that carry most of the wiki's links. The
per-file topic pages are guaranteed and are not counted against it. That
distinction is the whole point: a cap on the *total* silently produces zero
mined concepts on any corpus bigger than the cap, because the topic pages fill
it before mining starts. The build still succeeds, every file still gets a
page, and the cross-file links you actually wanted are just quietly absent.

If `scale_test.py` or `inspect_wiki.py --links` reports few mined concepts on
your corpus, raise `MAX_MINED_CONCEPTS` (default 60) and rebuild.

## Evaluating it on your own corpus

Replace `corpus\*.txt`, **delete `data\`**, then:

```
py build_wiki.py
py inspect_wiki.py           # did it find sensible concepts?
py inspect_wiki.py --links   # is the wiki connected, or a set of islands?
py smoke_test.py             # edit QUESTIONS first - see below
```

`--links` is the honest test of whether this is a wiki. "Pages nothing links
to" are islands: a topic the rest of your documentation never mentions by name.
A handful is normal. If most pages are islands, your files do not share
vocabulary and the auto-linker has nothing to work with — raise
`MAX_MINED_CONCEPTS` first, then look at whether the same thing is called three
different names across your files, which is a finding about the documentation
rather than about this tool.

`smoke_test.py` carries an expected outcome for each question and exits
non-zero if reality disagrees, so it doubles as a regression test. Swap in ten
of your own questions: seven you know the corpus answers, three you know it
does not. If the three "does not" cases come back as answers, `MIN_COVERAGE` in
`config.py` is too low for your vocabulary. That single edit is the most
valuable hour you can spend on this.

Then `py compare_modes.py --full` and read a few answers side by side. The
grounding check there is the one to watch: it flags any `[n]` marker the model
emits that points past the end of the supplied passages, which is a model
inventing a citation. That failure mode is the most damaging one available to a
knowledge base, because it looks exactly like a well-sourced answer.

## Layout

```
corpus/              9 sample IT topic files - the input
llmwiki/
  gateway.py         *** THE FILE YOU REPLACE *** QueryLLM + GetToken
  llm.py             retry / token refresh / cache / fallback around QueryLLM
  cache.py           content-addressed prompt cache
  ledger.py          per-call accounting
  config.py          every tunable number
  corpus.py          parse .txt -> Blocks (one Q&A pair or paragraph each)
  retrieval.py       BM25 + the coverage metric
  concepts.py        concept extraction (heuristic or gateway)
  pages.py           assemble one wiki page per concept
  answer.py          the ask pipeline, gap detection, citations
  render.py          markdown -> HTML + the auto-linker (used by --links)
  wiki.py            runtime: load, ask, cache answers, record gaps
build_wiki.py        the build  (--stages to enable model authoring)
ask.py               ask one question from the command line
data/                generated: wiki.json, answers.json, gaps.json,
                     llm_cache.json, ledger.json
```

Evaluation scripts, not part of the app: `smoke_test.py`, `gateway_test.py`,
`compare_modes.py`, `inspect_wiki.py`, `scale_test.py`.

## Differences from V1 you should know about

- `llm.complete()` takes two extra keyword arguments, `task` and `label`. They
  feed the ledger and the cache key. The three call sites in `concepts.py`,
  `pages.py` and `answer.py` pass them; nothing else changed in those files.
- `get_llm()` signature is now `get_llm(force_offline=False, use_gateway=False,
  cache=None)`.
- The build prints a gateway usage table and writes `data/ledger.json`.
- `llm.handles(task)` is new. Callers ask it before building a prompt, so a
  disabled stage costs nothing at all.

Two changes to the shared engine, both needed for a corpus of your size. Both
were verified to produce a **byte-identical wiki** on the nine-file sample
corpus, page bodies and block counts included:

- **`MAX_CONCEPTS` → `MAX_MINED_CONCEPTS`** (`concepts.py`). V1 capped the
  total, which meant zero mined concepts above 26 files — see section 4. If you
  ever take this back to V1, take this fix with it.
- **`attach_blocks` pre-filters with a substring test** before running the
  alias regex, and groups blocks by source once instead of rescanning per
  concept. A word-boundary match implies a substring match, so no result can
  change. At 500 files: 12.9s → 1.8s.

Everything else — BM25, the coverage metric, page assembly, gap detection — is
the V1 logic unchanged.
