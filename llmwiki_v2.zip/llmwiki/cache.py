"""Content-addressed cache for gateway replies.

This is the difference between a rebuild costing 20+ calls and costing 1.

Every prompt is hashed with the settings that shaped it. A rebuild that changes
one topic file only changes the prompts that actually contain that file's text,
so only those go to the gateway; every other concept page is served from disk,
byte for byte identical to last time.

That last part matters beyond cost: a wiki whose unrelated pages quietly reword
themselves on every rebuild is one nobody trusts. Caching makes the build
reproducible - same corpus in, same wiki out.

Cache invalidation is free because the key IS the content. Edit a source file
and the prompts containing it hash differently, so the stale entries are simply
never looked up again. `py build_wiki.py --prune-cache` removes them.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Dict, Optional


class PromptCache:
    def __init__(self, path: Path, enabled: bool = True):
        self.path = path
        self.enabled = enabled
        self._data: Dict[str, dict] = {}
        self._used: set = set()
        self._load()

    def _load(self) -> None:
        if not self.enabled or not self.path.exists():
            return
        try:
            self._data = json.loads(self.path.read_text(encoding="utf-8"))
        except Exception:
            self._data = {}   # a corrupt cache is a cache miss, not a crash

    @staticmethod
    def key(task: str, system: str, prompt: str, **settings) -> str:
        h = hashlib.sha256()
        h.update(task.encode("utf-8"))
        h.update(b"\x00")
        h.update((system or "").encode("utf-8"))
        h.update(b"\x00")
        h.update(prompt.encode("utf-8"))
        for k in sorted(settings):
            h.update(f"\x00{k}={settings[k]}".encode("utf-8"))
        return h.hexdigest()[:32]

    def get(self, key: str) -> Optional[str]:
        if not self.enabled:
            return None
        entry = self._data.get(key)
        if entry is None:
            return None
        self._used.add(key)
        return entry["reply"]

    def put(self, key: str, task: str, label: str, reply: str) -> None:
        if not self.enabled:
            return
        self._data[key] = {"task": task, "label": label, "reply": reply}
        self._used.add(key)

    def prune(self) -> int:
        """Drop entries not touched during this run. Only safe after a full build."""
        dead = set(self._data) - self._used
        for k in dead:
            del self._data[k]
        return len(dead)

    def save(self) -> None:
        if not self.enabled:
            return
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text(json.dumps(self._data, indent=2, ensure_ascii=False),
                             encoding="utf-8")

    @property
    def size(self) -> int:
        return len(self._data)
