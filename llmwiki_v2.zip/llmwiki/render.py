"""Tiny markdown renderer plus the auto-linker that makes this a wiki.

Auto-linking is the feature that separates a wiki from a folder of answers.
Every time one page mentions a concept that has its own page, that mention
becomes a link, so a reader can wander the knowledge base instead of having to
think up the next question.
"""
from __future__ import annotations

import html
import re
from typing import Callable, Dict, Iterable, List, Optional

from .config import LINKS_PER_ALIAS_PER_PAGE

_CITE = re.compile(r"\[(\d+)\]")
_BOLD = re.compile(r"\*\*(.+?)\*\*")


def esc(text: str) -> str:
    return html.escape(text, quote=False)


class Linker:
    """Turns concept mentions into <a> tags. One instance per rendered page."""

    def __init__(self, concepts: Iterable, current_slug: Optional[str] = None):
        self.current_slug = current_slug
        self.alias_to_slug: Dict[str, str] = {}
        self.slug_to_name: Dict[str, str] = {}
        aliases: List[str] = []

        for c in concepts:
            slug = c["slug"] if isinstance(c, dict) else c.slug
            name = c["name"] if isinstance(c, dict) else c.name
            als = c["aliases"] if isinstance(c, dict) else c.aliases
            if slug == current_slug:
                continue
            self.slug_to_name[slug] = name
            for a in als:
                low = a.lower()
                if len(low) < 3:
                    continue
                if low not in self.alias_to_slug:
                    self.alias_to_slug[low] = slug
                    aliases.append(a)

        self.used: Dict[str, int] = {}
        if aliases:
            aliases.sort(key=len, reverse=True)
            self.pattern = re.compile(
                r"(?<![\w&])(" + "|".join(re.escape(a) for a in aliases) + r")(?![\w])",
                re.I,
            )
        else:
            self.pattern = None

    def __call__(self, escaped_text: str) -> str:
        if not self.pattern:
            return escaped_text

        def repl(m: re.Match) -> str:
            surface = m.group(1)
            slug = self.alias_to_slug.get(surface.lower())
            if not slug:
                return surface
            if self.used.get(slug, 0) >= LINKS_PER_ALIAS_PER_PAGE:
                return surface
            self.used[slug] = self.used.get(slug, 0) + 1
            title = esc(self.slug_to_name.get(slug, surface))
            return f'<a class="wikilink" href="/wiki/{slug}" title="{title}">{surface}</a>'

        return self.pattern.sub(repl, escaped_text)


def _inline(text: str, linker: Optional[Callable[[str], str]]) -> str:
    out = esc(text)
    if linker:
        out = linker(out)
    out = _BOLD.sub(r"<strong>\1</strong>", out)
    out = _CITE.sub(
        r'<sup class="cite"><a href="#src-\1" data-cite="\1">\1</a></sup>', out
    )
    return out


def render_markdown(text: str, linker: Optional[Callable[[str], str]] = None) -> str:
    """Supports: ### headings, - bullets, **bold**, [n] citations, paragraphs."""
    html_parts: List[str] = []
    bullets: List[str] = []

    def flush_bullets():
        if bullets:
            items = "".join(f"<li>{b}</li>" for b in bullets)
            html_parts.append(f"<ul>{items}</ul>")
            bullets.clear()

    for raw in text.split("\n"):
        line = raw.rstrip()
        if not line.strip():
            flush_bullets()
            continue
        if line.startswith("### "):
            flush_bullets()
            html_parts.append(f"<h3>{_inline(line[4:].strip(), linker)}</h3>")
        elif line.startswith("## "):
            flush_bullets()
            html_parts.append(f"<h3>{_inline(line[3:].strip(), linker)}</h3>")
        elif line.lstrip().startswith("- "):
            bullets.append(_inline(line.lstrip()[2:].strip(), linker))
        else:
            flush_bullets()
            html_parts.append(f"<p>{_inline(line.strip(), linker)}</p>")

    flush_bullets()
    return "\n".join(html_parts)
