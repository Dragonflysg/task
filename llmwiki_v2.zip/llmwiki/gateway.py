"""THE ONLY FILE YOU NEED TO REPLACE.

==============================================================================
  Everything above this layer calls exactly one function:

      QueryLLM(prompt, system=None, temperature=..., domain=..., max_tokens=...)
          -> str   on success
          -> raises GatewayError on failure

  Delete the dummy body below, paste in your real token + POST code, keep the
  signature and the exception contract, and the whole wiki starts running on
  your department's gateway. Nothing else in the codebase changes.
==============================================================================

The dummy below simulates what your gateway does so the pipeline can be
evaluated end to end before you wire the real thing in:

  * a bearer token that must be fetched before the first call and that EXPIRES
    mid-build (see TOKEN_TTL_SECONDS) - a full build is dozens of sequential
    calls and can easily outlive a short-lived token
  * an OpenAI-shaped request payload and an OpenAI-shaped response envelope
  * network latency
  * transient failures (429 rate limit, 503) that should be retried
  * auth failures (401) that should trigger a token refresh, not a retry

Failure injection is off by default. Turn it on to see how the pipeline copes:

    from llmwiki.gateway import SIMULATE
    SIMULATE["fail_rate"] = 0.3
"""
from __future__ import annotations

import hashlib
import json
import random
import re
import time
from typing import List, Optional

# --------------------------------------------------------------------------
# Settings you would move into config / environment for the real gateway
# --------------------------------------------------------------------------
GATEWAY_URL = "https://ai.example-corp.internal/v1/chat/completions"
TOKEN_URL = "https://ai.example-corp.internal/oauth/token"
DEFAULT_DOMAIN = "it-support"
DEFAULT_TEMPERATURE = 0.2
TOKEN_TTL_SECONDS = 900

# Dummy-only knobs. None of this survives into the real implementation.
SIMULATE = {
    "latency": (0.0, 0.0),   # (min, max) seconds per call; try (0.4, 1.2)
    "fail_rate": 0.0,        # chance of a transient 429/503
    "expire_token": False,   # let the token lapse after TOKEN_TTL_SECONDS
}


class GatewayError(RuntimeError):
    """Any failure talking to the gateway.

    `status` mirrors the HTTP status where there is one, because the retry
    policy in llm.py branches on it: 401 means refresh the token and retry,
    429/503 mean back off and retry, anything else means give up and fall back
    to the extractive path.
    """

    def __init__(self, message: str, status: Optional[int] = None):
        super().__init__(message)
        self.status = status


# --------------------------------------------------------------------------
# Token handling
# --------------------------------------------------------------------------
_token: Optional[str] = None
_token_issued_at: float = 0.0


def GetToken(force_refresh: bool = False) -> str:
    """Fetch (and cache) a bearer token.

    REAL IMPLEMENTATION: POST your client credentials to TOKEN_URL and return
    the access token. Keep the caching - a build makes dozens of calls and you
    do not want a token round trip in front of every one of them.
    """
    global _token, _token_issued_at
    age = time.time() - _token_issued_at
    if _token and not force_refresh and age < TOKEN_TTL_SECONDS:
        return _token

    # --- dummy ---
    _token = "tok_" + hashlib.sha1(str(time.time()).encode()).hexdigest()[:24]
    _token_issued_at = time.time()
    return _token


def _token_is_stale() -> bool:
    if not SIMULATE["expire_token"]:
        return False
    return (time.time() - _token_issued_at) > TOKEN_TTL_SECONDS


# --------------------------------------------------------------------------
# The call
# --------------------------------------------------------------------------
def QueryLLM(prompt: str,
             system: Optional[str] = None,
             temperature: float = DEFAULT_TEMPERATURE,
             domain: str = DEFAULT_DOMAIN,
             max_tokens: int = 1200,
             timeout: int = 60) -> str:
    """Send one prompt to the gateway and return the generated text.

    REAL IMPLEMENTATION, roughly:

        token = GetToken()
        payload = {
            "model": MODEL,
            "domain": domain,
            "temperature": temperature,
            "max_tokens": max_tokens,
            "messages": (
                ([{"role": "system", "content": system}] if system else [])
                + [{"role": "user", "content": prompt}]
            ),
        }
        r = requests.post(GATEWAY_URL, json=payload, timeout=timeout,
                          headers={"Authorization": f"Bearer {token}"})
        if r.status_code != 200:
            raise GatewayError(r.text[:200], status=r.status_code)
        return r.json()["choices"][0]["message"]["content"]

    Two contracts the rest of the code relies on:
      1. Return the *text*, not the envelope.
      2. Raise GatewayError with .status set. Never return None, never return
         an error string - a fabricated "I'm sorry, I cannot..." string would
         be written into a wiki page as though it were content.
    """
    token = GetToken()

    # --- everything from here down is dummy behaviour ---
    lo, hi = SIMULATE["latency"]
    if hi > 0:
        time.sleep(random.uniform(lo, hi))

    if _token_is_stale():
        raise GatewayError("token expired", status=401)

    if SIMULATE["fail_rate"] and random.random() < SIMULATE["fail_rate"]:
        raise GatewayError(*random.choice([
            ("rate limit exceeded", 429),
            ("upstream temporarily unavailable", 503),
        ]))

    payload = {
        "model": "corp-generative-ai",
        "domain": domain,
        "temperature": temperature,
        "max_tokens": max_tokens,
        "messages": (([{"role": "system", "content": system}] if system else [])
                     + [{"role": "user", "content": prompt}]),
    }
    response = {
        "id": "cmpl_" + hashlib.sha1(prompt.encode()).hexdigest()[:16],
        "object": "chat.completion",
        "choices": [{
            "index": 0,
            "message": {"role": "assistant",
                        "content": _simulate_generation(prompt, payload)},
            "finish_reason": "stop",
        }],
        "usage": {
            "prompt_tokens": len(prompt) // 4,
            "completion_tokens": 0,
            "total_tokens": len(prompt) // 4,
        },
    }
    return response["choices"][0]["message"]["content"]


# --------------------------------------------------------------------------
# Dummy generation
#
# Deliberately NOT random text. It reads the excerpts out of the prompt and
# writes them back with citation markers, so the output is grounded in the
# corpus and the citation plumbing is genuinely exercised. What you are
# evaluating with the dummy is the SHAPE of the pipeline - prompt in, grounded
# markdown with [n] markers out - not the prose quality.
# --------------------------------------------------------------------------
_EXCERPT = re.compile(r"^\[(\d+)\]\s*\(([^)]*)\)\s*$", re.M)


def _excerpts(prompt: str) -> List[dict]:
    """Pull the numbered excerpt blocks back out of a page/answer prompt."""
    out, marks = [], list(_EXCERPT.finditer(prompt))
    for i, m in enumerate(marks):
        end = marks[i + 1].start() if i + 1 < len(marks) else len(prompt)
        body = prompt[m.end():end].strip()
        question = ""
        if body.startswith("Q:"):
            head, _, rest = body.partition("\nA:")
            question, body = head[2:].strip(), rest.strip()
        out.append({"n": int(m.group(1)), "origin": m.group(2),
                    "question": question, "text": body})
    return out


def _first_sentences(text: str, n: int = 2) -> str:
    parts = re.split(r"(?<=[.!?])\s+", " ".join(text.split()))
    return " ".join(parts[:n]).strip()


def _simulate_generation(prompt: str, payload: dict) -> str:
    # 1. concept extraction -> JSON array
    if "JSON array" in prompt:
        return json.dumps(_simulate_concepts(prompt), indent=2)

    ex = _excerpts(prompt)
    if not ex:
        return "No source material was supplied, so there is nothing to report."

    # 2. a concept page
    if prompt.lstrip().startswith("Write the wiki page"):
        name = "This topic"
        m = re.search(r"concept:\s*(.+)", prompt)
        if m:
            name = m.group(1).strip()
        lead = _first_sentences(ex[0]["text"], 2)
        out = [f"{lead} [{ex[0]['n']}]", "", "### In detail", ""]
        for e in ex[1:5]:
            out.append(f"- {_first_sentences(e['text'], 1)} [{e['n']}]")
        qa = [e for e in ex if e["question"]][:3]
        if qa:
            out += ["", "### Common questions", ""]
            for e in qa:
                out += [f"**{e['question']}**", "",
                        f"{_first_sentences(e['text'], 2)} [{e['n']}]", ""]
        out += ["", f"*Drafted from {len(ex)} passages by the corporate "
                    f"gateway ({payload['domain']}, temp {payload['temperature']}).*"]
        return "\n".join(out)

    # 3. an answer to a user question
    best = next((e for e in ex if e["question"]), ex[0])
    out = [f"{_first_sentences(best['text'], 3)} [{best['n']}]", "",
           "### In practice", ""]
    for e in ex[:4]:
        if e["n"] == best["n"]:
            continue
        out.append(f"- {_first_sentences(e['text'], 1)} [{e['n']}]")
    return "\n".join(out)


_TITLE = re.compile(r"\b([A-Z][a-z]{2,}(?:\s+(?:[A-Z][a-z]{1,}|On|As|Of|And)){1,3})\b")
_STOP = {"The", "This", "That", "There", "These", "Those", "When", "Where",
         "What", "Which", "If", "You", "Your", "It", "They", "Do", "Raise",
         "Sign", "Report", "Only", "Personal", "Corporate", "Expect", "Yes"}


def _simulate_concepts(prompt: str) -> List[dict]:
    """Stand in for the model's concept extraction.

    Uses a cheap title-case heuristic so the JSON contains real phrases from
    the file. A real model does better; the point here is that the JSON is
    well formed and the names are things that actually occur in the text.
    """
    body = prompt.split("--- FILE:", 1)[-1]
    seen: dict = {}
    for m in _TITLE.finditer(body):
        phrase = m.group(1).strip()
        if phrase.split()[0] in _STOP or len(phrase) < 4:
            continue
        seen.setdefault(phrase.lower(), phrase)
    names = list(seen.values())[:8]
    return [{"name": n, "aliases": [n.lower(), n.lower() + "s"]} for n in names]
