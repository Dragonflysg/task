"""Accounting for every gateway call.

The question you actually need answered before putting this on a server is
"what does a build cost me in calls, and how long does it take". So every call
is recorded: what it was for, whether it hit the cache, how long it took, how
many retries it needed, and whether it ultimately failed.

    from llmwiki.ledger import LEDGER
    LEDGER.reset()
    ...
    print(LEDGER.report())
"""
from __future__ import annotations

import json
import threading
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Dict, List, Optional


@dataclass
class Call:
    task: str                 # "concepts" | "page" | "answer"
    label: str                # which file / page / question
    cached: bool = False
    seconds: float = 0.0
    retries: int = 0
    prompt_chars: int = 0
    reply_chars: int = 0
    error: Optional[str] = None


class Ledger:
    def __init__(self) -> None:
        self._lock = threading.Lock()
        self.calls: List[Call] = []
        self.started = time.time()

    def reset(self) -> None:
        with self._lock:
            self.calls = []
            self.started = time.time()

    def record(self, call: Call) -> None:
        with self._lock:
            self.calls.append(call)

    # ---- summaries ----
    @property
    def billable(self) -> List[Call]:
        """Calls that actually went to the gateway."""
        return [c for c in self.calls if not c.cached]

    def by_task(self) -> Dict[str, dict]:
        out: Dict[str, dict] = {}
        for c in self.calls:
            row = out.setdefault(c.task, {"calls": 0, "cached": 0, "failed": 0,
                                          "retries": 0, "seconds": 0.0,
                                          "prompt_chars": 0})
            row["calls"] += 1
            row["cached"] += int(c.cached)
            row["failed"] += int(bool(c.error))
            row["retries"] += c.retries
            row["seconds"] += c.seconds
            row["prompt_chars"] += c.prompt_chars
        return out

    def report(self) -> str:
        if not self.calls:
            return "  no gateway calls (offline build)"
        rows = self.by_task()
        w = max(len(t) for t in rows)
        out = [f"  {'task':<{w}}  {'total':>5} {'sent':>5} {'cached':>6} "
               f"{'failed':>6} {'retries':>7} {'seconds':>8}"]
        for task, r in sorted(rows.items()):
            out.append(f"  {task:<{w}}  {r['calls']:>5} "
                       f"{r['calls'] - r['cached']:>5} {r['cached']:>6} "
                       f"{r['failed']:>6} {r['retries']:>7} {r['seconds']:>8.2f}")
        sent = len(self.billable)
        failed = sum(1 for c in self.calls if c.error)
        chars = sum(c.prompt_chars for c in self.billable)
        out.append("")
        out.append(f"  {sent} call(s) sent to the gateway, "
                   f"{len(self.calls) - sent} served from cache, {failed} failed")
        out.append(f"  ~{chars // 4:,} prompt tokens sent "
                   f"(rough estimate at 4 chars/token)")
        out.append(f"  wall clock: {time.time() - self.started:.1f}s")
        return "\n".join(out)

    def save(self, path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(
            {"started": self.started,
             "summary": self.by_task(),
             "calls": [asdict(c) for c in self.calls]},
            indent=2), encoding="utf-8")


LEDGER = Ledger()
