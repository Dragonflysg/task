"""Parse the plain-text topic files into retrievable blocks.

The expected file shape is deliberately forgiving, because real knowledge bases
are never tidy:

    # Topic: Network Shares
    # Owner: IT Infrastructure Team
    # Updated: 2026-02-28

    ## About
    One or more free paragraphs of discussion.

    ## Questions
    Q: How do I request access to a network share?
    A: Raise an access request naming the exact DFS path...

Each Q/A pair becomes one block. Each discussion paragraph becomes one block.
A block is the unit that gets retrieved and the unit that gets cited, so it
needs to be small enough to be a precise citation and large enough to stand on
its own when a user reads it out of context.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import List

from .config import CORPUS_DIR


@dataclass
class Block:
    id: str
    source: str        # file name, e.g. "network_shares.txt"
    topic: str         # "Network Shares"
    owner: str
    updated: str
    kind: str          # "qa" | "prose"
    question: str      # empty for prose blocks
    text: str
    line: int          # 1-indexed line in the source file

    @property
    def search_text(self) -> str:
        """Used for retrieval, where the topic name is a useful extra signal."""
        return f"{self.topic} {self.question} {self.text}"

    @property
    def concept_text(self) -> str:
        """Used for concept mining. Deliberately excludes the topic header and
        keeps the question on its own line: gluing 'Network Shares' onto 'How do
        I...' invents phrases like 'Network Shares How' that are not concepts."""
        return f"{self.question}\n{self.text}" if self.question else self.text

    @property
    def title(self) -> str:
        return self.question or f"{self.topic} - overview"

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class Document:
    source: str
    topic: str
    owner: str
    updated: str
    blocks: List[Block] = field(default_factory=list)


_HEADER = re.compile(r"^#\s*(Topic|Owner|Updated)\s*:\s*(.+?)\s*$", re.I)
_SECTION = re.compile(r"^##\s*(.+?)\s*$")
_Q = re.compile(r"^Q\s*:\s*(.*)$")
_A = re.compile(r"^A\s*:\s*(.*)$")


def _slug_base(source: str) -> str:
    return Path(source).stem.replace("_", "-")


def parse_file(path: Path) -> Document:
    raw = path.read_text(encoding="utf-8")
    lines = raw.splitlines()

    topic, owner, updated = Path(path).stem.replace("_", " ").title(), "Unknown", "Unknown"
    doc_start = 0
    for i, line in enumerate(lines):
        m = _HEADER.match(line)
        if m:
            key, val = m.group(1).lower(), m.group(2)
            if key == "topic":
                topic = val
            elif key == "owner":
                owner = val
            else:
                updated = val
            doc_start = i + 1
        elif line.strip() and not line.startswith("#"):
            break

    doc = Document(source=path.name, topic=topic, owner=owner, updated=updated)
    base = _slug_base(path.name)

    # State machine over the body.
    mode = "prose"
    buf: List[str] = []
    buf_line = doc_start + 1
    q_text = ""
    q_line = 0
    n_prose = 0
    n_qa = 0

    def flush_prose():
        nonlocal buf, n_prose
        text = " ".join(s.strip() for s in buf).strip()
        buf = []
        if len(text) < 40:          # skip stray fragments
            return
        n_prose += 1
        doc.blocks.append(Block(
            id=f"{base}#p{n_prose}", source=path.name, topic=topic, owner=owner,
            updated=updated, kind="prose", question="", text=text, line=buf_line,
        ))

    def flush_qa():
        nonlocal buf, n_qa, q_text
        text = " ".join(s.strip() for s in buf).strip()
        buf = []
        if not q_text or not text:
            q_text = ""
            return
        n_qa += 1
        doc.blocks.append(Block(
            id=f"{base}#q{n_qa}", source=path.name, topic=topic, owner=owner,
            updated=updated, kind="qa", question=q_text, text=text, line=q_line,
        ))
        q_text = ""

    for i, line in enumerate(lines[doc_start:], start=doc_start + 1):
        stripped = line.strip()

        if _SECTION.match(line):
            if mode == "qa":
                flush_qa()
            else:
                flush_prose()
            mode = "prose"
            buf_line = i + 1
            continue

        mq = _Q.match(stripped)
        if mq:
            if mode == "qa":
                flush_qa()
            else:
                flush_prose()
            mode = "question"
            q_text = mq.group(1).strip()
            q_line = i
            continue

        ma = _A.match(stripped)
        if ma:
            mode = "qa"
            buf = [ma.group(1).strip()]
            continue

        if not stripped:
            if mode == "qa":
                flush_qa()
                mode = "prose"
                buf_line = i + 1
            elif mode == "prose":
                flush_prose()
                buf_line = i + 1
            continue

        if mode == "question":
            # A question that wrapped onto a second line.
            q_text = f"{q_text} {stripped}".strip()
        else:
            if not buf:
                buf_line = i
            buf.append(stripped)

    if mode == "qa":
        flush_qa()
    else:
        flush_prose()

    return doc


def load_corpus(corpus_dir: Path | None = None) -> List[Document]:
    corpus_dir = corpus_dir or CORPUS_DIR
    docs = [parse_file(p) for p in sorted(corpus_dir.glob("*.txt"))]
    if not docs:
        raise SystemExit(f"No .txt files found in {corpus_dir}")
    return docs


def all_blocks(docs: List[Document]) -> List[Block]:
    return [b for d in docs for b in d.blocks]
