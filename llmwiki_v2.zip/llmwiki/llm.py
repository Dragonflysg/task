"""Pluggable LLM adapter, wired to a corporate HTTP gateway.

Nothing else in the codebase knows whether a model is present. Every caller
does the same thing:

    out = llm.complete(system=..., user=..., task="page", label="Accounts")
    if out is None:
        ...fall back to the deterministic extractive path...

`complete()` returns None rather than raising, always. A gateway outage, an
expired token nobody can refresh, a rate limit that never clears - all of them
degrade the wiki to extraction rather than taking it down. That is a deliberate
choice: an internal knowledge base that returns a slightly duller answer is
working; one that returns HTTP 500 is not.

Modes
    offline   BM25 + extraction only. No network. The default.
    gateway   Routes through llmwiki.gateway.QueryLLM.

Select with `py build_wiki.py --gateway` or LLMWIKI_GATEWAY=1.
"""
from __future__ import annotations

import os
import time
from typing import Optional

from .cache import PromptCache
from .config import (GATEWAY_BACKOFF_SECONDS, GATEWAY_DOMAIN, GATEWAY_MAX_RETRIES,
                     GATEWAY_MIN_INTERVAL_SECONDS, GATEWAY_TASKS,
                     GATEWAY_TEMPERATURE)
from .gateway import GatewayError, GetToken, QueryLLM
from .ledger import LEDGER, Call


ALL_TASKS = frozenset({"concepts", "page", "answer"})

# Wall-clock time of the last call actually sent. Module level on purpose: the
# throttle is a property of the shared gateway, not of any one adapter object.
_last_sent_at = 0.0


class LLM:
    name = "none"
    available = False

    def handles(self, task: str) -> bool:
        """Will this adapter actually call a model for this build stage?

        Callers use it to choose their path BEFORE building a prompt, so a
        disabled stage costs nothing at all - not a wasted prompt, not a
        wasted string join.
        """
        return False

    def complete(self, system: str, user: str, max_tokens: int = 1200,
                 task: str = "unknown", label: str = "") -> Optional[str]:
        return None

    def describe(self) -> str:
        return "offline (extractive)"


class NullLLM(LLM):
    """No model. Callers fall back to deterministic extraction."""


class GatewayLLM(LLM):
    """Talks to the department's generative AI endpoint via QueryLLM."""

    name = "gateway"
    available = True

    def __init__(self, cache: Optional[PromptCache] = None,
                 temperature: float = GATEWAY_TEMPERATURE,
                 domain: str = GATEWAY_DOMAIN,
                 max_retries: int = GATEWAY_MAX_RETRIES,
                 tasks=None,
                 min_interval: float = GATEWAY_MIN_INTERVAL_SECONDS):
        self.cache = cache
        self.temperature = temperature
        self.domain = domain
        self.max_retries = max_retries
        self.tasks = frozenset(GATEWAY_TASKS if tasks is None else tasks)
        self.min_interval = min_interval

    def handles(self, task: str) -> bool:
        return task in self.tasks

    def describe(self) -> str:
        return f"gateway ({self.domain}, temp {self.temperature})"

    def _throttle(self) -> None:
        """Space calls out. The gateway is sequential and shared."""
        global _last_sent_at
        if self.min_interval > 0:
            wait = _last_sent_at + self.min_interval - time.time()
            if wait > 0:
                time.sleep(wait)
        _last_sent_at = time.time()

    def complete(self, system: str, user: str, max_tokens: int = 1200,
                 task: str = "unknown", label: str = "") -> Optional[str]:
        # A stage that is not enabled never reaches the network and never
        # reaches the ledger. It is not a failure, so nothing is logged; the
        # caller simply takes the extractive path.
        if not self.handles(task):
            return None

        settings = {"temperature": self.temperature, "domain": self.domain,
                    "max_tokens": max_tokens}
        key = PromptCache.key(task, system, user, **settings) if self.cache else None

        if key:
            hit = self.cache.get(key)
            if hit is not None:
                LEDGER.record(Call(task=task, label=label, cached=True,
                                   prompt_chars=len(user), reply_chars=len(hit)))
                return hit

        started = time.time()
        retries = 0
        last = "unknown error"

        for attempt in range(self.max_retries):
            try:
                self._throttle()
                reply = QueryLLM(prompt=user, system=system,
                                 temperature=self.temperature,
                                 domain=self.domain, max_tokens=max_tokens)
            except GatewayError as exc:
                last = f"{exc.status or '-'}: {exc}"
                retries += 1

                # 401: the token lapsed mid-build. Refresh and retry immediately;
                # backing off here would only waste the fresh token's lifetime.
                if exc.status == 401:
                    GetToken(force_refresh=True)
                    continue

                # 429/503: transient. Exponential backoff, then retry.
                if exc.status in (429, 503) and attempt < self.max_retries - 1:
                    time.sleep(GATEWAY_BACKOFF_SECONDS * (2 ** attempt))
                    continue
                break
            except Exception as exc:                      # noqa: BLE001
                last = f"unexpected: {exc.__class__.__name__}: {exc}"
                break
            else:
                if key:
                    self.cache.put(key, task, label, reply)
                LEDGER.record(Call(task=task, label=label,
                                   seconds=time.time() - started, retries=retries,
                                   prompt_chars=len(user), reply_chars=len(reply)))
                return reply

        LEDGER.record(Call(task=task, label=label, seconds=time.time() - started,
                           retries=retries, prompt_chars=len(user), error=last))
        print(f"  [llm] {task} '{label}' failed ({last}); using extractive fallback")
        return None


_cached: Optional[LLM] = None


def get_llm(force_offline: bool = False, use_gateway: bool = False,
            cache: Optional[PromptCache] = None, tasks=None) -> LLM:
    """Pick the mode. Offline unless explicitly told otherwise."""
    global _cached
    if force_offline or os.environ.get("LLMWIKI_OFFLINE") == "1":
        return NullLLM()
    if use_gateway or os.environ.get("LLMWIKI_GATEWAY") == "1":
        if _cached is None or not isinstance(_cached, GatewayLLM):
            _cached = GatewayLLM(cache=cache, tasks=tasks)
        elif cache is not None:
            _cached.cache = cache
        return _cached
    if _cached is None:
        _cached = NullLLM()
    return _cached


def set_llm(llm: LLM) -> None:
    """Install a specific adapter. Used by the evaluation scripts."""
    global _cached
    _cached = llm
