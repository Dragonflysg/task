"""LLM Wiki - turn a folder of Q&A text files into a browsable, cited wiki."""
__version__ = "0.1.0"
