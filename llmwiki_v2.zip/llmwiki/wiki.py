"""Runtime wiki: loads the built index, answers questions, records gaps."""
from __future__ import annotations

import json
import threading
from datetime import datetime, timezone
from typing import Dict, List, Optional, Tuple

from .answer import build_answer, normalise_question
from .config import ANSWERS_FILE, DATA_DIR, GAPS_FILE, WIKI_FILE
from .corpus import Block
from .llm import LLM, get_llm
from .retrieval import BM25Index

_LOCK = threading.Lock()


def _read_json(path, default):
    if not path.exists():
        return default
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default


def _write_json(path, obj):
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False), encoding="utf-8")


class Wiki:
    def __init__(self, data: dict):
        self.built_at: str = data.get("built_at", "unknown")
        self.generated_by: str = data.get("generated_by", "extractive")
        self.blocks: List[Block] = [Block(**b) for b in data["blocks"]]
        self.blocks_by_id: Dict[str, Block] = {b.id: b for b in self.blocks}
        self.concepts: List[dict] = data["concepts"]
        self.pages: Dict[str, dict] = data["pages"]
        self.stats: dict = data.get("stats", {})
        self.index = BM25Index(self.blocks)

        self.answers: Dict[str, dict] = _read_json(ANSWERS_FILE, {})
        self.gaps: Dict[str, dict] = _read_json(GAPS_FILE, {})
        self._by_question: Dict[str, str] = {
            a.get("normalised", ""): slug for slug, a in self.answers.items()
        }

    @classmethod
    def load(cls) -> "Wiki":
        if not WIKI_FILE.exists():
            raise SystemExit(
                f"{WIKI_FILE} not found. Build the wiki first:\n\n"
                f"    py build_wiki.py\n"
            )
        return cls(_read_json(WIKI_FILE, {}))

    # -- reads ------------------------------------------------------------
    def page(self, slug: str) -> Optional[dict]:
        return self.pages.get(slug)

    def answer_page(self, slug: str) -> Optional[dict]:
        return self.answers.get(slug)

    def concept_index(self) -> List[dict]:
        return sorted(self.concepts, key=lambda c: c["name"].lower())

    def sorted_answers(self) -> List[dict]:
        return sorted(self.answers.values(),
                      key=lambda a: (a.get("asked", 1), a.get("created", "")),
                      reverse=True)

    def sorted_gaps(self) -> List[dict]:
        return sorted(self.gaps.values(),
                      key=lambda g: (g.get("count", 1), g.get("last_seen", "")),
                      reverse=True)

    def source_files(self) -> List[dict]:
        seen: Dict[str, dict] = {}
        for b in self.blocks:
            e = seen.setdefault(b.source, {
                "source": b.source, "topic": b.topic, "owner": b.owner,
                "updated": b.updated, "blocks": 0, "qa": 0,
            })
            e["blocks"] += 1
            e["qa"] += 1 if b.kind == "qa" else 0
        return sorted(seen.values(), key=lambda e: e["topic"])

    # -- the ask path -----------------------------------------------------
    def ask(self, question: str, llm: Optional[LLM] = None) -> Tuple[dict, bool]:
        question = question.strip()
        key = normalise_question(question)
        if not key:
            raise ValueError("empty question")

        with _LOCK:
            slug = self._by_question.get(key)
            if slug and slug in self.answers:
                page = self.answers[slug]
                page["asked"] = page.get("asked", 1) + 1
                page["last_asked"] = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
                _write_json(ANSWERS_FILE, self.answers)
                if page.get("kind") == "gap":
                    self._record_gap(question, key, page)
                return page, True

        page = build_answer(question, self.index, self.concepts, llm or get_llm())
        page["normalised"] = key

        with _LOCK:
            self.answers[page["slug"]] = page
            self._by_question[key] = page["slug"]
            _write_json(ANSWERS_FILE, self.answers)
            if page["kind"] == "gap":
                self._record_gap(question, key, page)
        return page, False

    def _record_gap(self, question: str, key: str, page: dict) -> None:
        now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
        entry = self.gaps.get(key)
        if entry:
            entry["count"] += 1
            entry["last_seen"] = now
        else:
            self.gaps[key] = {
                "question": question, "slug": page["slug"], "count": 1,
                "first_seen": now, "last_seen": now,
                "best_score": page.get("score", 0.0),
                "coverage": page.get("coverage", 0.0),
                "missing": page.get("missing", []),
                "nearest": [r["name"] for r in page.get("related", [])],
            }
        _write_json(GAPS_FILE, self.gaps)
