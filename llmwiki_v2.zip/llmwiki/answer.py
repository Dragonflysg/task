"""Answering a question - as a wiki page, not as a chat message.

Three things happen here that a normal RAG endpoint does not do:

1. A weak retrieval becomes an honest "not covered" page and is logged as a
   knowledge gap, instead of being handed to a model that will cheerfully
   invent a policy.
2. A good answer is written to disk under a stable slug, so it has a URL a
   person can send to a colleague, and so the second person to ask gets the
   identical answer for free.
3. The answer links out to the concept pages it touched, which is how a reader
   discovers the thing they should have asked about instead.
"""
from __future__ import annotations

import hashlib
import re
from datetime import datetime, timezone
from typing import Dict, List, Tuple

from .concepts import slugify
from .config import MIN_COVERAGE, MIN_SCORE, TOP_K
from .corpus import Block
from .llm import LLM
from .retrieval import BM25Index

_SENTENCE = re.compile(r"(?<=[.!?])\s+")


def normalise_question(q: str) -> str:
    return re.sub(r"[^a-z0-9 ]+", " ", q.lower()).strip()


def question_slug(q: str) -> str:
    base = slugify(q)[:64].strip("-") or "question"
    digest = hashlib.sha1(normalise_question(q).encode("utf-8")).hexdigest()[:6]
    return f"{base}-{digest}"


def confidence_label(score: float, coverage: float) -> str:
    """Coverage leads, score confirms. A high score on a half-understood
    question is exactly the case that should not read as confident."""
    if coverage >= 0.85 and score >= MIN_SCORE * 2:
        return "high"
    if coverage >= 0.72:
        return "medium"
    return "low"


def _first_sentences(text: str, n: int = 2) -> str:
    parts = _SENTENCE.split(text)
    return " ".join(parts[:n]).strip()


def _sources_for(hits: List[Tuple[Block, float]]) -> List[dict]:
    return [{
        "n": i, "block_id": b.id, "source": b.source, "line": b.line,
        "topic": b.topic, "title": b.title, "kind": b.kind,
        "question": b.question, "text": b.text, "score": s,
    } for i, (b, s) in enumerate(hits, start=1)]


def _extractive_answer(question: str, hits: List[Tuple[Block, float]]) -> str:
    best, _ = hits[0]
    parts: List[str] = []

    if best.kind == "qa":
        parts.append(f"{best.text} [1]")
    else:
        parts.append(f"{_first_sentences(best.text, 3)} [1]")

    rest = hits[1:]
    if rest:
        parts.append("### Supporting detail")
        for i, (b, _s) in enumerate(rest, start=2):
            label = b.question or f"{b.topic} overview"
            parts.append(f"- **{label}** {_first_sentences(b.text, 2)} [{i}]")

    parts.append("### How this answer was assembled")
    parts.append(
        f"Retrieved {len(hits)} passages from "
        f"{len({b.source for b, _ in hits})} source files by BM25 ranking, then "
        "quoted the best match verbatim and summarised the rest. No model was "
        "involved, so nothing here has been paraphrased away from the source "
        "wording. Re-ask with --gateway and this section is replaced by a written answer."
    )
    return "\n\n".join(parts)


_SYSTEM = (
    "You answer questions from an internal IT knowledge base. You use only the "
    "numbered excerpts provided. You never invent a policy, a timescale, a "
    "naming convention, or a process step. Every factual sentence carries a [n] "
    "citation. If the excerpts do not answer the question, you say so directly "
    "and name what is missing."
)

_PROMPT = """Question from a colleague:

{question}

Numbered excerpts retrieved from the knowledge base:

{excerpts}

Write the answer as a short wiki page:
- Lead with the direct answer in two to four sentences, cited.
- "### In practice" with the concrete steps or caveats, if the excerpts support any.
- "### Watch out for" only if the excerpts contain a genuine trap or common mistake.
- If the excerpts only partly answer the question, state exactly which part is
  not covered. Do not fill the gap from general knowledge.

British spelling. Markdown only. No sources section - it is added automatically.
"""


def _llm_answer(question: str, hits: List[Tuple[Block, float]], llm: LLM) -> str | None:
    excerpts = []
    for i, (b, _s) in enumerate(hits, start=1):
        head = f"[{i}] ({b.source}, topic: {b.topic})"
        body = f"Q: {b.question}\nA: {b.text}" if b.kind == "qa" else b.text
        excerpts.append(f"{head}\n{body}")
    return llm.complete(
        _SYSTEM,
        _PROMPT.format(question=question.strip(), excerpts="\n\n".join(excerpts)),
        max_tokens=1200, task="answer", label=question.strip()[:60],
    )


def related_from_hits(hits: List[Tuple[Block, float]], concepts: List[dict]) -> List[dict]:
    hit_ids = {b.id for b, _ in hits}
    scored = []
    for c in concepts:
        overlap = len(hit_ids & set(c["block_ids"]))
        if overlap:
            scored.append((overlap, c))
    scored.sort(key=lambda t: t[0], reverse=True)
    return [{"slug": c["slug"], "name": c["name"], "shared": n} for n, c in scored[:6]]


def build_answer(question: str, index: BM25Index, concepts: List[dict],
                 llm: LLM) -> dict:
    hits = index.search(question, k=TOP_K)
    now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    top = hits[0][1] if hits else 0.0
    cov, missing = index.coverage(question, hits)
    absent = index.absent_terms(question)

    if not hits or top < MIN_SCORE or cov < MIN_COVERAGE:
        near = [{
            "slug": c["slug"], "name": c["name"],
        } for c in related_from_hits(hits, concepts)[:4]] if hits else []
        return {
            "slug": question_slug(question),
            "title": question.strip().rstrip("?") + "?",
            "kind": "gap",
            "question": question.strip(),
            "body": "",
            "sources": _sources_for(hits[:3]),
            "related": near,
            "generated_by": "retrieval only",
            "score": round(top, 2),
            "coverage": round(cov, 2),
            "missing": missing,
            "absent": absent,
            "confidence": "none",
            "created": now,
            "asked": 1,
        }

    body, generated_by = None, "extractive"
    if llm.handles("answer"):
        body = _llm_answer(question, hits, llm)
        if body:
            generated_by = llm.describe()
    if not body:
        body = _extractive_answer(question, hits)

    return {
        "slug": question_slug(question),
        "title": question.strip().rstrip("?") + "?",
        "kind": "answer",
        "question": question.strip(),
        "body": body,
        "sources": _sources_for(hits),
        "related": related_from_hits(hits, concepts),
        "generated_by": generated_by,
        "score": round(top, 2),
        "coverage": round(cov, 2),
        "missing": missing,
        "absent": absent,
        "confidence": confidence_label(top, cov),
        "created": now,
        "asked": 1,
    }
