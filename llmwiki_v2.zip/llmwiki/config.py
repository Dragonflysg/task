"""Central configuration. Everything tunable lives here."""
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
CORPUS_DIR = ROOT / "corpus"
DATA_DIR = ROOT / "data"

WIKI_FILE = DATA_DIR / "wiki.json"
ANSWERS_FILE = DATA_DIR / "answers.json"
GAPS_FILE = DATA_DIR / "gaps.json"
LLM_CACHE_FILE = DATA_DIR / "llm_cache.json"
LEDGER_FILE = DATA_DIR / "ledger.json"

# --- Retrieval -------------------------------------------------------------
BM25_K1 = 1.5
BM25_B = 0.75
TOP_K = 6

# Gate for answering at all. A question that fails either test becomes a "red
# link" knowledge gap instead of a confidently wrong answer. These two numbers
# are the most important in the project: raise them and the wiki gets cautious,
# lower them and it starts bluffing.
#
# MIN_SCORE alone is not enough. BM25 is unbounded and rewards long questions,
# so "how do I enrol an iPhone in mobile device management" scores well against
# an IT corpus that has never heard of iPhones - every other word matches
# something. MIN_COVERAGE is what actually catches those: it measures how much
# of the question's information weight the retrieved passages account for.
MIN_SCORE = 3.0
MIN_COVERAGE = 0.62

# --- Wiki construction -----------------------------------------------------
# Cap on concepts MINED from the text - the cross-cutting ones like "Send As"
# or "DFS namespace" that no single file owns. Those are what make this a wiki
# rather than a file listing.
#
# It deliberately does NOT count the per-file topic pages. Every source file is
# guaranteed its own page, so a 300-file corpus starts with 300 concepts before
# any mining happens; a cap on the total would mean zero mined concepts on any
# corpus larger than the cap, and the failure is silent - you get a page per
# file, the build succeeds, and the cross-file links you actually wanted are
# simply absent.
MAX_MINED_CONCEPTS = 60
MIN_CONCEPT_DOC_FREQ = 2   # a concept must appear in at least this many blocks
MAX_RELATED = 6
LINKS_PER_ALIAS_PER_PAGE = 1

# --- Gateway ---------------------------------------------------------------
# Only used in --gateway mode. The endpoint itself lives in gateway.py, which
# is the file you replace with your department's real POST code.
#
# Temperature is low on purpose. These prompts ask the model to rewrite
# supplied passages, not to invent; the failure mode you care about is the
# model straying past its excerpts, and temperature is the cheapest brake.
GATEWAY_TEMPERATURE = 0.2
GATEWAY_DOMAIN = "it-support"
GATEWAY_MAX_RETRIES = 3
GATEWAY_BACKOFF_SECONDS = 1.0

# Which build stages are allowed to call the gateway. The default is answers
# only, which is the setting that matters most for a 100-500 file corpus:
#
#   "concepts"  one call per source FILE, at build time. Sends whole files.
#   "page"      one call per concept page, at build time. Sends passages.
#   "answer"    one call per new question, at ask time. Sends 3 passages.
#
# With {"answer"} the build is completely offline and free no matter how large
# the corpus grows, the corpus is never bulk-transmitted anywhere, and the only
# calls made are for questions a real person actually asked and that passed the
# coverage gate. Pages stay extractive - quoted straight from the source files,
# which for reference material is arguably what you want anyway.
#
# Add "page" if you want prose-written pages and have measured the cost:
# roughly one call per page, per cold build. See README.
GATEWAY_TASKS = {"answer"}

# Minimum seconds between two gateway calls. The gateway is sequential and
# shared, so this is the throttle that keeps a build from being the reason
# someone else gets rate limited. 0.0 disables it.
GATEWAY_MIN_INTERVAL_SECONDS = 0.0

SITE_NAME = "IT Knowledge Wiki"
SITE_TAGLINE = "Generated from the source files in /corpus"
