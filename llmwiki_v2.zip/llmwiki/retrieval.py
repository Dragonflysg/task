"""BM25 retrieval in pure Python - no vector database, no embeddings, no deps.

For a corpus of a few hundred short blocks, lexical BM25 is genuinely
competitive with embeddings and it has two properties that matter for a demo:
it is deterministic, and you can read the score and understand why something
matched. Swap this module for pgvector or Chroma later; the interface is just
search(query, k) -> [(block, score)].
"""
from __future__ import annotations

import math
import re
from collections import Counter
from typing import Dict, List, Tuple

from .config import BM25_B, BM25_K1
from .corpus import Block

STOPWORDS = {
    "a", "an", "the", "and", "or", "but", "if", "then", "than", "that", "this",
    "these", "those", "is", "are", "was", "were", "be", "been", "being", "am",
    "do", "does", "did", "doing", "have", "has", "had", "having", "i", "you",
    "he", "she", "it", "we", "they", "me", "him", "her", "us", "them", "my",
    "your", "his", "its", "our", "their", "to", "of", "in", "on", "at", "by",
    "for", "with", "from", "as", "into", "about", "up", "down", "out", "off",
    "over", "under", "again", "there", "here", "when", "where", "why", "how",
    "what", "which", "who", "whom", "all", "any", "both", "each", "more",
    "most", "other", "some", "such", "no", "not", "only", "own", "same", "so",
    "too", "very", "can", "will", "just", "should", "now", "get", "got",
}

_WORD = re.compile(r"[a-z0-9][a-z0-9'\-]*")


def _stem(tok: str) -> str:
    """Deliberately crude. Enough to unify plurals without a stemmer dependency."""
    for suf in ("ies", "es", "s"):
        if tok.endswith(suf) and len(tok) - len(suf) >= 3:
            return tok[: -len(suf)] + ("y" if suf == "ies" else "")
    return tok


def tokenize(text: str) -> List[str]:
    toks = _WORD.findall(text.lower())
    return [_stem(t) for t in toks if t not in STOPWORDS and len(t) > 1]


def tokenize_pairs(text: str) -> List[Tuple[str, str]]:
    """(surface form, stem) - so we can report missing terms as the user typed them."""
    toks = _WORD.findall(text.lower())
    return [(t, _stem(t)) for t in toks if t not in STOPWORDS and len(t) > 1]


class BM25Index:
    def __init__(self, blocks: List[Block]):
        self.blocks = blocks
        self.docs: List[Counter] = []
        self.lengths: List[int] = []
        self.df: Counter = Counter()

        for b in blocks:
            toks = tokenize(b.search_text)
            tf = Counter(toks)
            self.docs.append(tf)
            self.lengths.append(len(toks))
            self.df.update(tf.keys())

        self.n = len(blocks)
        self.avgdl = (sum(self.lengths) / self.n) if self.n else 0.0
        self.idf: Dict[str, float] = {
            term: math.log(1 + (self.n - freq + 0.5) / (freq + 0.5))
            for term, freq in self.df.items()
        }

    def score(self, query_tokens: List[str], i: int) -> float:
        tf, dl = self.docs[i], self.lengths[i]
        if not dl:
            return 0.0
        total = 0.0
        for term in query_tokens:
            f = tf.get(term, 0)
            if not f:
                continue
            idf = self.idf.get(term, 0.0)
            denom = f + BM25_K1 * (1 - BM25_B + BM25_B * dl / self.avgdl)
            total += idf * (f * (BM25_K1 + 1)) / denom
        return total

    def coverage(self, query: str, hits: List[Tuple[Block, float]],
                 depth: int = 3) -> Tuple[float, List[str]]:
        """How much of the question did we actually retrieve an answer for?

        A raw BM25 score cannot be thresholded: a seven-word question about
        something the corpus has never heard of still scores well, because
        every ordinary word in it matches somewhere. What distinguishes a real
        answer is *coverage* - the share of the question's information weight
        that appears in the retrieved passages. Terms absent from the corpus
        entirely are weighted as maximally rare and can never be covered, so a
        question containing them is pushed toward the gap path.

        Returns (coverage 0..1, the query terms nothing matched).
        """
        pairs = list(dict.fromkeys(tokenize_pairs(query)))
        if not pairs:
            return 0.0, []

        max_idf = max(self.idf.values()) if self.idf else 1.0
        seen = set()
        for b, _ in hits[:depth]:
            seen.update(tokenize(b.search_text))

        ideal = covered = 0.0
        missing: List[str] = []
        for surface, stem in pairs:
            weight = self.idf.get(stem, max_idf)
            ideal += weight
            if stem in seen:
                covered += weight
            else:
                missing.append(surface)

        return (covered / ideal if ideal else 0.0), missing

    def absent_terms(self, query: str) -> List[str]:
        """Query words that appear nowhere in the entire corpus.

        Stronger and more actionable than 'we did not retrieve this': it is a
        direct statement that the knowledge base has never heard of the thing
        being asked about, which is exactly what a documentation owner needs.
        """
        return [surface for surface, stem in dict.fromkeys(tokenize_pairs(query))
                if stem not in self.df]

    def search(self, query: str, k: int = 6) -> List[Tuple[Block, float]]:
        qt = tokenize(query)
        if not qt:
            return []
        scored = [(i, self.score(qt, i)) for i in range(self.n)]
        scored = [(i, s) for i, s in scored if s > 0]
        scored.sort(key=lambda x: x[1], reverse=True)
        return [(self.blocks[i], round(s, 3)) for i, s in scored[:k]]
