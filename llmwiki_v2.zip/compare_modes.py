"""Offline vs gateway, question by question. Not part of the app.

    py compare_modes.py
    py compare_modes.py --full     # print both answer bodies in full

This is the script that answers "is the LLM actually earning its calls?".

For each question it builds the answer twice - once with pure extraction, once
through QueryLLM - and checks the things that must NOT change between them:

  * the gate decision (answer vs gap) - it is computed from retrieval alone,
    so the model can never argue the wiki into answering something it should
    have refused
  * the retrieved passages and their citation numbers

and then reports the thing that should change: the prose.

It also runs a GROUNDING check on the model's output. Every [n] marker in a
generated body must point at a passage that was actually supplied. A marker
past the end of the source list means the model invented a citation, which is
the single most damaging failure mode for a knowledge base - it looks exactly
like a well-sourced answer. Run this against your own corpus before you trust
the gateway output.
"""
from __future__ import annotations

import re
import sys

from llmwiki.answer import build_answer
from llmwiki.cache import PromptCache
from llmwiki.config import LLM_CACHE_FILE
from llmwiki.ledger import LEDGER
from llmwiki.llm import GatewayLLM, NullLLM
from llmwiki.wiki import Wiki

QUESTIONS = [
    "Why can I read the shared mailbox but not send from it?",
    "How do I give a contractor access to a confidential finance share?",
    "What happens to a leaver's access?",
    "How do I enrol a new iPhone in the mobile device management system?",
    "What is the guest wi-fi password?",
]

MARKER = re.compile(r"\[(\d+)\]")


def grounded(body: str, n_sources: int):
    """Every citation marker must point at a supplied passage."""
    bad = sorted({int(m) for m in MARKER.findall(body) if int(m) > n_sources or int(m) < 1})
    return (not bad), bad


def main() -> int:
    full = "--full" in sys.argv
    w = Wiki.load()
    offline = NullLLM()
    gateway = GatewayLLM(cache=PromptCache(LLM_CACHE_FILE, enabled=True))
    LEDGER.reset()

    problems = []
    for q in QUESTIONS:
        a = build_answer(q, w.index, w.concepts, offline)
        b = build_answer(q, w.index, w.concepts, gateway)

        print("=" * 74)
        print(f"Q: {q}")
        print("-" * 74)

        same_gate = a["kind"] == b["kind"]
        same_src = [s["block_id"] for s in a["sources"]] == [s["block_id"] for s in b["sources"]]
        print(f"  gate decision : {a['kind']:6} / {b['kind']:6}   "
              f"{'same' if same_gate else 'DIFFERENT - the model changed the gate!'}")
        print(f"  score/coverage: {a['score']:.2f} / {a['coverage']:.0%}   "
              f"(identical by construction - retrieval is shared)")
        print(f"  citations     : {len(a['sources'])} passages, "
              f"{'identical' if same_src else 'DIFFERENT'}")

        if not same_gate:
            problems.append((q, "gate decision differs between modes"))
        if not same_src:
            problems.append((q, "citation set differs between modes"))

        if b["kind"] == "answer":
            ok, bad = grounded(b["body"], len(b["sources"]))
            print(f"  grounding     : {'ok' if ok else f'INVENTED CITATIONS {bad}'}")
            if not ok:
                problems.append((q, f"gateway invented citations {bad}"))

        alen, blen = len(a["body"]), len(b["body"])
        print(f"  body length   : extractive {alen} chars, gateway {blen} chars "
              f"({blen - alen:+d})")

        if full and b["kind"] == "answer":
            print()
            print("  --- extractive " + "-" * 57)
            for line in a["body"].splitlines():
                print(f"  {line}")
            print()
            print(f"  --- gateway " + "-" * 60)
            for line in b["body"].splitlines():
                print(f"  {line}")
        print()

    print("=" * 74)
    if LEDGER.calls:
        print(LEDGER.report())
        print()
    if problems:
        print(f"{len(problems)} PROBLEM(S):")
        for q, p in problems:
            print(f"  - {p}\n      {q}")
        return 1
    print("No divergence: the gateway changed the prose and nothing else.")
    print("Read a few bodies with --full and decide if the prose is worth the calls.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
