"""How does the build behave at your corpus size? Not part of the app.

    py scale_test.py            # 100, 300 files
    py scale_test.py 500        # a specific size

Generates a synthetic corpus of N topic files shaped like the real ones, then
times each stage of the build separately. Nothing here touches ./corpus or
./data - the synthetic files go to a temp directory and are deleted after.

Read the per-stage timings, not just the total. They scale differently:
retrieval is linear in blocks, but concept attachment is concepts x blocks, so
it is the stage that bites first as the corpus grows.
"""
from __future__ import annotations

import random
import shutil
import sys
import tempfile
import time
from pathlib import Path

from llmwiki.concepts import attach_blocks, dedupe_slugs, extract_heuristic
from llmwiki.corpus import all_blocks, load_corpus
from llmwiki.llm import NullLLM
from llmwiki.pages import build_concept_page
from llmwiki.retrieval import BM25Index

# A vocabulary with deliberate overlap between files, because a corpus where
# no file shares terms with any other would make cross-file pages and concept
# mining look artificially cheap.
SUBJECTS = ["Access Request", "Security Group", "Service Account", "Data Owner",
            "Change Record", "Distribution List", "Licence Pool", "Site Link",
            "Backup Policy", "Retention Rule", "Certificate Store", "Print Queue"]
AREAS = ["Finance", "Payroll", "Logistics", "Clinical", "Retail", "Legal",
         "Field Services", "Procurement", "Facilities", "Research"]
THINGS = ["share", "mailbox", "group", "queue", "token", "profile", "licence",
          "certificate", "folder", "endpoint", "rule", "record"]
VERBS = ["request", "approve", "revoke", "extend", "migrate", "audit",
         "delegate", "restore", "archive", "reconcile"]

# Cross-cutting terms: named in title case, belonging to no single file, used
# by many. These are what concept mining is supposed to find, and the pages
# they produce are the difference between a wiki and a folder of text files.
# Without them in the synthetic corpus this script measures speed but proves
# nothing about whether mining still works at scale.
CROSS = ["Joiner Mover Leaver", "Access Review", "Named Approver",
         "Break Glass Account", "Standing Access", "Least Privilege",
         "Service Catalogue", "Change Freeze"]
ACRONYMS = ["JML", "RBAC", "SLA", "MFA", "DFS", "PIM"]


def sentence(rng: random.Random) -> str:
    return (f"The {rng.choice(THINGS)} must be {rng.choice(VERBS)}d by the "
            f"{rng.choice(SUBJECTS).lower()} owner before the "
            f"{rng.choice(AREAS).lower()} team can use it.")


def cross_sentence(rng: random.Random) -> str:
    return (f"{rng.choice(CROSS)} applies here, so check {rng.choice(ACRONYMS)} "
            f"before you {rng.choice(VERBS)} the {rng.choice(THINGS)}.")


def make_corpus(n: int, dest: Path, seed: int = 7) -> None:
    rng = random.Random(seed)
    dest.mkdir(parents=True, exist_ok=True)
    for i in range(n):
        topic = f"{rng.choice(AREAS)} {rng.choice(SUBJECTS)} {i}"
        lines = [f"# Topic: {topic}", "# Owner: IT", "# Updated: 2026-08-01", "",
                 "## About", ""]
        for _ in range(3):
            lines.append(" ".join(sentence(rng) for _ in range(3))
                         + " " + cross_sentence(rng))
            lines.append("")
        lines += ["## Questions", ""]
        for q in range(6):
            lines.append(f"Q: How do I {rng.choice(VERBS)} a "
                         f"{rng.choice(THINGS)} for {rng.choice(AREAS)}?")
            lines.append(f"A: {sentence(rng)} {cross_sentence(rng)}")
            lines.append("")
        (dest / f"topic_{i:04d}.txt").write_text("\n".join(lines), encoding="utf-8")


def run(n: int) -> None:
    tmp = Path(tempfile.mkdtemp(prefix=f"llmwiki_scale_{n}_"))
    try:
        make_corpus(n, tmp)
        t = {}

        t0 = time.time(); docs = load_corpus(tmp); blocks = all_blocks(docs)
        t["parse"] = time.time() - t0

        t0 = time.time(); index = BM25Index(blocks)
        t["index"] = time.time() - t0

        t0 = time.time(); concepts = extract_heuristic(docs, blocks)
        t["mine concepts"] = time.time() - t0

        t0 = time.time()
        dedupe_slugs(concepts)
        attach_blocks(concepts, blocks)
        concepts = [c for c in concepts if c.block_ids]
        t["attach blocks"] = time.time() - t0

        t0 = time.time()
        blocks_by_id = {b.id: b for b in blocks}
        llm = NullLLM()
        pages = {c.slug: build_concept_page(c, blocks_by_id, index, concepts, llm)
                 for c in concepts}
        t["build pages"] = time.time() - t0

        t0 = time.time()
        for q in ["how do I request a share for Finance?",
                  "who approves a licence for Payroll?",
                  "what is the guest wi-fi password?"]:
            index.search(q, k=6)
        t["3 questions"] = time.time() - t0

        total = sum(t.values())
        mined = [c for c in concepts if c.home_source is None]
        print(f"  {n} files -> {len(blocks)} blocks, {len(index.idf)} terms, "
              f"{len(concepts)} concepts ({len(mined)} mined cross-file), "
              f"{len(pages)} pages")
        if not mined:
            print("    ** NO MINED CONCEPTS - every page belongs to one file. "
                  "Raise MAX_MINED_CONCEPTS. **")
        for stage, secs in t.items():
            bar = "#" * int(40 * secs / total) if total else ""
            print(f"    {stage:<16} {secs:7.2f}s  {bar}")
        print(f"    {'TOTAL':<16} {total:7.2f}s")

        biggest = max(pages.values(), key=lambda p: len(p["body"]))
        print(f"    largest page: {biggest['title'][:34]!r} "
              f"{biggest['block_count']} blocks, {len(biggest['body']):,} chars")
        print()
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    sizes = [int(a) for a in sys.argv[1:] if a.isdigit()] or [100, 300]
    print("Build cost by corpus size")
    print("=" * 62)
    for n in sizes:
        run(n)
