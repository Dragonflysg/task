"""Ask the wiki a question from the command line.

    py ask.py "why can I read the shared mailbox but not send from it?"
    py ask.py --gateway "how do I request a shared mailbox?"
    py ask.py --json "what happens to a leaver's access?"

Offline by default. --gateway routes the answer through QueryLLM; retrieval,
the coverage gate and the citations are identical either way, because the
gateway only ever writes the prose.
"""
from __future__ import annotations

import json
import sys
import textwrap

from llmwiki.cache import PromptCache
from llmwiki.config import LLM_CACHE_FILE, MIN_COVERAGE
from llmwiki.ledger import LEDGER
from llmwiki.llm import get_llm
from llmwiki.wiki import Wiki


def main() -> int:
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    flags = {a for a in sys.argv[1:] if a.startswith("--")}
    if not args:
        print(__doc__)
        return 1

    question = " ".join(args)
    gateway = "--gateway" in flags
    llm = get_llm(use_gateway=gateway,
                  cache=PromptCache(LLM_CACHE_FILE, enabled=gateway))

    wiki = Wiki.load()
    page, cached = wiki.ask(question, llm=llm)

    if "--json" in flags:
        print(json.dumps(page, indent=2, ensure_ascii=False))
        return 0

    print()
    print(f"  Q: {question}")
    print("  " + "=" * 68)

    if page["kind"] == "gap":
        print("  NO ANSWER - this is a knowledge gap, not a failure to retrieve.")
        print(f"  score {page['score']:.2f}, coverage {page['coverage']:.0%} "
              f"(needs {MIN_COVERAGE:.0%})")
        if page.get("absent"):
            print(f"  absent from the corpus entirely: {', '.join(page['absent'])}")
        if page.get("missing"):
            print(f"  not covered by the retrieved passages: "
                  f"{', '.join(page['missing'])}")
        print()
        print("  Closest passages, for context only:")
        for s in page["sources"][:3]:
            print(f"    [{s['n']}] {s['source']}:{s['line']}  {s['title'][:56]}")
        print()
        print("  Recorded in the gap report. Write a corpus file covering it and")
        print("  rebuild; the question answers itself on the next build.")
        return 0

    for para in page["body"].split("\n"):
        if not para.strip():
            print()
            continue
        for line in textwrap.wrap(para, width=74):
            print(f"  {line}")

    print()
    print(f"  confidence: {page['confidence']}   score {page['score']:.2f}   "
          f"coverage {page['coverage']:.0%}   written by {page['generated_by']}"
          f"{'   [cached answer]' if cached else ''}")
    print("  sources:")
    for s in page["sources"]:
        print(f"    [{s['n']}] {s['source']}:{s['line']:<4} {s['title'][:58]}")
    if page.get("related"):
        print(f"  related pages: {', '.join(r['name'] for r in page['related'])}")

    if LEDGER.calls:
        print()
        print(LEDGER.report())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
