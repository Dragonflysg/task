"""End-to-end check of the ask pipeline. Not part of the app.

    py smoke_test.py              # offline
    py smoke_test.py --gateway    # answers written by QueryLLM

The question set is chosen to exercise every branch, and each one carries the
result it is SUPPOSED to produce. If an expectation fails the script says so
and exits non-zero, so this doubles as a regression test you can point at your
own corpus once you have swapped the files in.
"""
from __future__ import annotations

import sys

from llmwiki.cache import PromptCache
from llmwiki.config import LLM_CACHE_FILE, MIN_COVERAGE, MIN_SCORE
from llmwiki.ledger import LEDGER
from llmwiki.llm import get_llm
from llmwiki.wiki import Wiki

# (question, expected kind, why it is in the set)
QUESTIONS = [
    ("Why can I read the shared mailbox but not send from it?", "answer",
     "squarely covered by one file"),
    ("How do I give a contractor access to a confidential finance share?", "answer",
     "answer lives in a different file from the obvious one"),
    ("What happens to a leaver's access?", "answer",
     "spans three files - no single source has the whole answer"),
    ("granted access but still denied", "answer",
     "covered, but phrased nothing like the source text"),
    ("How do I enrol a new iPhone in the mobile device management system?", "answer",
     "was a gap until corpus/mobile_devices.txt was added"),
    ("What is the guest wi-fi password?", "gap",
     "genuinely absent - must refuse rather than bluff"),
    ("How do I request a refund for a train ticket?", "gap",
     "entirely off-domain - must refuse"),
]


def main() -> int:
    gateway = "--gateway" in sys.argv
    llm = get_llm(use_gateway=gateway,
                  cache=PromptCache(LLM_CACHE_FILE, enabled=gateway))
    LEDGER.reset()

    w = Wiki.load()
    print(f"mode  : {llm.describe()}")
    print(f"loaded: {w.stats}")
    print(f"gate  : score >= {MIN_SCORE}, coverage >= {MIN_COVERAGE:.0%}")
    print()

    failures = []
    for question, expected, why in QUESTIONS:
        page, _cached = w.ask(question, llm=llm)
        actual = page["kind"]
        ok = actual == expected
        if not ok:
            failures.append((question, expected, actual))

        mark = "ok  " if ok else "FAIL"
        tag = "GAP " if actual == "gap" else "ans "
        print(f"[{mark}] {tag} score={page['score']:6.2f}  "
              f"cov={page['coverage']:.2f}  {page['confidence']:6}  {question}")
        print(f"        why in the set: {why}")
        if not ok:
            print(f"        EXPECTED {expected}, GOT {actual}")
        if page.get("absent"):
            print(f"        absent from corpus entirely: {', '.join(page['absent'])}")
        if page.get("missing"):
            print(f"        not covered by retrieved passages: "
                  f"{', '.join(page['missing'])}")
        for s in page["sources"][:3]:
            print(f"        [{s['n']}] {s['source']}:{s['line']:<4} {s['title'][:56]}")
        print(f"        written by: {page['generated_by']}")
        print(f"        related: {', '.join(r['name'] for r in page['related']) or '-'}")
        print()

    page, cached = w.ask(QUESTIONS[0][0], llm=llm)
    print(f"re-asked the first question -> cached={cached}, asked={page['asked']}x")
    if not cached:
        failures.append((QUESTIONS[0][0], "cached on re-ask", "not cached"))
    print(f"gaps recorded: {len(w.gaps)}")

    if LEDGER.calls:
        print()
        print("Gateway usage")
        print("-" * 60)
        print(LEDGER.report())

    print()
    if failures:
        print(f"{len(failures)} EXPECTATION(S) FAILED:")
        for q, exp, act in failures:
            print(f"  - {q}\n      expected {exp}, got {act}")
        return 1
    print(f"all {len(QUESTIONS)} expectations met.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
