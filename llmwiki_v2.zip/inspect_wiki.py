"""Quick look at what the build produced. Not part of the app.

    py inspect_wiki.py            # concept list
    py inspect_wiki.py <slug>     # dump one page's markdown
    py inspect_wiki.py --links    # the auto-link graph between pages
"""
import json
import re
import sys

from llmwiki.config import WIKI_FILE
from llmwiki.render import Linker, render_markdown

data = json.loads(WIKI_FILE.read_text(encoding="utf-8"))

if "--links" in sys.argv:
    # Auto-linking is what turns a pile of pages into something you can wander.
    # A page that links to nothing is an island: readers land on it and stop.
    href = re.compile(r'class="wikilink" href="/wiki/([^"]+)"')
    concepts, pages = data["concepts"], data["pages"]
    inbound = {slug: 0 for slug in pages}
    print(f"link graph over {len(pages)} pages")
    print("-" * 66)
    islands = []
    for slug, page in pages.items():
        html = render_markdown(page["body"], Linker(concepts, current_slug=slug))
        targets = sorted(set(href.findall(html)))
        for t in targets:
            if t in inbound:
                inbound[t] += 1
        if not targets:
            islands.append(slug)
        print(f"  {slug:26} -> {', '.join(targets) if targets else '(nothing)'}")
    print("-" * 66)
    orphaned = [s for s, n in inbound.items() if n == 0]
    print(f"  pages linking out to nothing : {len(islands)} {islands or ''}")
    print(f"  pages nothing links to       : {len(orphaned)} {orphaned or ''}")
    raise SystemExit(0)

if len(sys.argv) > 1:
    page = data["pages"].get(sys.argv[1])
    if not page:
        print("No such page. Slugs:")
        for s in sorted(data["pages"]):
            print("  " + s)
        raise SystemExit(1)
    print(f"# {page['title']}   ({page['generated_by']})")
    print(f"  {page['block_count']} passages / {page['file_count']} files\n")
    print(page["body"])
    print("\n--- sources ---")
    for s in page["sources"]:
        print(f"  [{s['n']}] {s['source']}:{s['line']}  {s['title'][:60]}")
    print("\n--- related ---")
    for r in page["related"]:
        print(f"  {r['name']}  ({r['shared']} shared)")
    raise SystemExit(0)

print(f"built {data['built_at']} by {data['generated_by']}")
print(f"{data['stats']}\n")
for c in data["concepts"]:
    home = c["home_source"] or "-"
    print(f"  {c['slug']:34} {len(c['block_ids']):3} blocks   home={home}")
