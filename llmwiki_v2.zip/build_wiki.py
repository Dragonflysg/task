"""Build the wiki from ./corpus into ./data/wiki.json.

    py build_wiki.py                 # offline: no network calls at all
    py build_wiki.py --gateway       # enable the stages in GATEWAY_TASKS
    py build_wiki.py --stages concepts,page   # author the wiki with the model
    py build_wiki.py --gateway --no-cache     # ignore the prompt cache
    py build_wiki.py --gateway --prune-cache  # drop entries this build did not use

Offline is the default. The gateway is opt-in, so nothing reaches the network
unless you ask for it on the command line or set LLMWIKI_GATEWAY=1.

Note that with the shipped default of GATEWAY_TASKS = {"answer"}, even
--gateway makes zero calls HERE. The build stays offline and free at any corpus
size; the gateway is used at ask time, on questions that passed the coverage
gate. Pass --stages to author pages with the model and watch the cost in the
usage table at the bottom.

Re-run this whenever the corpus changes.
"""
from __future__ import annotations

import json
import sys
from collections import Counter
from datetime import datetime, timezone

from llmwiki.cache import PromptCache
from llmwiki.concepts import attach_blocks, dedupe_slugs, extract_heuristic, extract_with_llm
from llmwiki.config import ANSWERS_FILE, DATA_DIR, LEDGER_FILE, LLM_CACHE_FILE, WIKI_FILE
from llmwiki.corpus import all_blocks, load_corpus
from llmwiki.ledger import LEDGER
from llmwiki.llm import ALL_TASKS, get_llm
from llmwiki.pages import build_concept_page
from llmwiki.retrieval import BM25Index


def main() -> None:
    offline = "--offline" in sys.argv
    gateway = "--gateway" in sys.argv
    use_cache = "--no-cache" not in sys.argv
    prune = "--prune-cache" in sys.argv

    # --stages concepts,page[,answer] overrides config.GATEWAY_TASKS for this
    # build and implies --gateway.
    tasks = None
    for i, a in enumerate(sys.argv):
        if a == "--stages" and i + 1 < len(sys.argv):
            tasks = {t.strip() for t in sys.argv[i + 1].split(",") if t.strip()}
            gateway = True
        elif a.startswith("--stages="):
            tasks = {t.strip() for t in a.split("=", 1)[1].split(",") if t.strip()}
            gateway = True
    if tasks is not None:
        unknown = tasks - ALL_TASKS
        if unknown:
            raise SystemExit(f"unknown stage(s): {', '.join(sorted(unknown))}. "
                             f"Valid: {', '.join(sorted(ALL_TASKS))}")

    cache = PromptCache(LLM_CACHE_FILE, enabled=use_cache and not offline)
    llm = get_llm(force_offline=offline, use_gateway=gateway, cache=cache,
                  tasks=tasks)
    LEDGER.reset()

    print("LLM Wiki build")
    print("=" * 62)
    print(f"  mode      : {llm.describe()}")
    if llm.available:
        print(f"  stages    : "
              + (", ".join(sorted(llm.tasks)) if llm.tasks else "none (offline build)"))
        print(f"  cache     : {'on' if cache.enabled else 'OFF'} "
              f"({cache.size} entries on disk)")

    docs = load_corpus()
    blocks = all_blocks(docs)
    kinds = Counter(b.kind for b in blocks)
    print(f"  corpus    : {len(docs)} files -> {len(blocks)} blocks "
          f"({kinds['qa']} Q&A, {kinds['prose']} discussion)")

    index = BM25Index(blocks)
    print(f"  index     : {len(index.idf)} unique terms, "
          f"avg block {index.avgdl:.0f} tokens")

    if llm.handles("concepts"):
        print(f"  concepts  : asking the gateway about {len(docs)} files...")
        concepts = extract_with_llm(docs, blocks, llm)
    else:
        concepts = extract_heuristic(docs, blocks)

    dedupe_slugs(concepts)
    attach_blocks(concepts, blocks)
    concepts = [c for c in concepts if c.block_ids]
    concepts.sort(key=lambda c: (c.home_source is None, c.name.lower()))
    print(f"  concepts  : {len(concepts)} pages")

    blocks_by_id = {b.id: b for b in blocks}
    pages = {}
    for c in concepts:
        page = build_concept_page(c, blocks_by_id, index, concepts, llm)
        pages[c.slug] = page

    covered = {s["block_id"] for p in pages.values() for s in p["sources"]}
    orphans = [b for b in blocks if b.id not in covered]
    cross = [p for p in pages.values() if p["file_count"] > 1]
    from_model = [p for p in pages.values() if p["generated_by"] != "extractive"]

    data = {
        "built_at": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC"),
        "generated_by": llm.describe(),
        "concepts": [c.to_dict() for c in concepts],
        "pages": pages,
        "blocks": [b.to_dict() for b in blocks],
        "stats": {
            "files": len(docs), "blocks": len(blocks), "concepts": len(concepts),
            "orphan_blocks": len(orphans),
            "cross_file_pages": len(cross),
        },
    }

    DATA_DIR.mkdir(parents=True, exist_ok=True)
    WIKI_FILE.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")

    # Pages change on every rebuild, so a cached answer written against the old
    # pages would cite passages that may no longer be numbered the same way.
    if ANSWERS_FILE.exists():
        ANSWERS_FILE.write_text("{}", encoding="utf-8")

    dropped = cache.prune() if (prune and llm.available) else 0
    cache.save()

    print("-" * 62)
    print(f"  wrote     : data/wiki.json")
    print(f"  cross-file: {len(cross)} of {len(pages)} pages pull from more "
          f"than one source file")
    if llm.handles("page"):
        print(f"  authored  : {len(from_model)} of {len(pages)} pages written by "
              f"the gateway, {len(pages) - len(from_model)} fell back to extraction")
    if orphans:
        print(f"  orphans   : {len(orphans)} blocks appear on no page:")
        for b in orphans[:5]:
            print(f"              - {b.source}:{b.line}  {b.title[:58]}")

    if LEDGER.calls:
        print()
        print("  Gateway usage")
        print("  " + "-" * 58)
        print(LEDGER.report())
        LEDGER.save(LEDGER_FILE)
        if dropped:
            print(f"  pruned {dropped} stale cache entries")

    print()
    print("  Next:  py ask.py \"how do I request a shared mailbox?\"")
    print("         py smoke_test.py")


if __name__ == "__main__":
    main()
