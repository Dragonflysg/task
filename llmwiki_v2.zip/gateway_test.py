"""Resilience of the gateway integration. Not part of the app.

    py gateway_test.py

A build is dozens of sequential HTTP calls against a shared corporate endpoint.
Over a long enough run every one of these WILL happen, so each is provoked
deliberately here rather than discovered in production:

  1. happy path                      pages are authored by the gateway
  2. token expires mid-build (401)   refresh and retry, do not back off
  3. rate limit / 503                back off, retry, succeed
  4. gateway down entirely           degrade to extraction, never raise
  5. malformed JSON from the model   drop that file's concepts, keep building
  6. cache hit                       zero calls on an unchanged rebuild
  7. a disabled stage                 costs nothing, silently falls back
  8. the sequential throttle          calls are spaced, never concurrent

The one that matters most is 4. A knowledge base that answers slightly worse
is still working; one that returns a traceback is not.
"""
from __future__ import annotations

import llmwiki.gateway as gw
import llmwiki.llm as llm_mod
from llmwiki.cache import PromptCache
from llmwiki.concepts import attach_blocks, dedupe_slugs, extract_with_llm
from llmwiki.config import LLM_CACHE_FILE
from llmwiki.corpus import all_blocks, load_corpus
from llmwiki.ledger import LEDGER
from llmwiki.llm import ALL_TASKS, GatewayLLM
from llmwiki.pages import build_concept_page
from llmwiki.retrieval import BM25Index

llm_mod.GATEWAY_BACKOFF_SECONDS = 0.001   # keep the test fast

PAGE_PROMPT = ("Write the wiki page for this concept: Test\n\n"
               "[1] (a.txt, Test)\nSome body text for the page.")

PASS, FAIL = [], []
REAL_QUERY = gw.QueryLLM


def check(name: str, ok: bool, detail: str = "") -> None:
    (PASS if ok else FAIL).append(name)
    print(f"  [{'ok  ' if ok else 'FAIL'}] {name}" + (f"  -> {detail}" if detail else ""))


def reset(**sim) -> None:
    gw.SIMULATE.update({"latency": (0.0, 0.0), "fail_rate": 0.0,
                        "expire_token": False})
    gw.SIMULATE.update(sim)
    gw._token, gw._token_issued_at = None, 0.0
    llm_mod.QueryLLM = REAL_QUERY
    LEDGER.reset()


docs = load_corpus()
blocks = all_blocks(docs)
index = BM25Index(blocks)
blocks_by_id = {b.id: b for b in blocks}


def fresh_concepts(llm):
    cs = extract_with_llm(docs[:2], blocks, llm)
    dedupe_slugs(cs)
    attach_blocks(cs, blocks)
    return [c for c in cs if c.block_ids]


print("Gateway resilience")
print("=" * 62)

# -- 1. happy path ---------------------------------------------------------
reset()
llm = GatewayLLM(cache=None, tasks=ALL_TASKS)
concepts = fresh_concepts(llm)
page = build_concept_page(concepts[0], blocks_by_id, index, concepts, llm)
check("1. happy path: page authored by the gateway",
      page["generated_by"] == llm.describe(), page["generated_by"])
check("1. happy path: citation markers survive the round trip",
      "[1]" in page["body"], f"{len(page['sources'])} sources cited")

# -- 2. token expiry -------------------------------------------------------
# Fails 401 exactly once, the way a token lapsing mid-build does. The retry
# must refresh the token rather than back off and try the dead one again.
reset()
seen = {"n": 0}


def expires_once(**kw):
    seen["n"] += 1
    if seen["n"] == 1:
        raise gw.GatewayError("token expired", status=401)
    return REAL_QUERY(**kw)


llm_mod.QueryLLM = expires_once
llm = GatewayLLM(cache=None, tasks=ALL_TASKS)
before = gw.GetToken()
out = llm.complete("sys", PAGE_PROMPT, task="page", label="token-test")
check("2. expired token is refreshed and the call retried",
      out is not None and seen["n"] == 2, f"{seen['n']} attempts")
check("2. the token actually changed", gw._token != before)

# -- 3. transient rate limit ----------------------------------------------
reset(fail_rate=0.4)
llm = GatewayLLM(cache=None, max_retries=10, tasks=ALL_TASKS)
ok = sum(1 for _ in range(6)
         if llm.complete("sys", PAGE_PROMPT, task="page", label="retry-test") is not None)
check("3. transient 429/503 are retried through to success", ok == 6,
      f"{ok}/6 succeeded after {sum(c.retries for c in LEDGER.calls)} retries")

# -- 4. gateway down entirely ---------------------------------------------
reset()


def dead(**kw):
    raise gw.GatewayError("connection refused", status=503)


llm_mod.QueryLLM = dead
llm = GatewayLLM(cache=None, max_retries=2, tasks=ALL_TASKS)
concepts = fresh_concepts(llm)
page = build_concept_page(concepts[0], blocks_by_id, index, concepts, llm)
check("4. gateway down: the build still completes",
      bool(page["body"]), f"{len(page['body'])} chars of page body")
check("4. gateway down: page falls back to extraction",
      page["generated_by"] == "extractive", page["generated_by"])
check("4. gateway down: every failure is recorded, none raised",
      len(LEDGER.calls) > 0 and all(c.error for c in LEDGER.calls),
      f"{len(LEDGER.calls)} calls, all logged as failed")

# -- 5. malformed model output --------------------------------------------
reset()


def garbage(**kw):
    return "Sure! Here are the concepts you asked for: <not json at all>"


llm_mod.QueryLLM = garbage
llm = GatewayLLM(cache=None, tasks=ALL_TASKS)
cs = extract_with_llm(docs[:2], blocks, llm)
check("5. unparseable JSON does not crash the build", len(cs) >= 2,
      f"{len(cs)} concepts kept (the per-file topic pages survive)")

# -- 6. cache --------------------------------------------------------------
reset()
tmp = LLM_CACHE_FILE.parent / "cache_test.json"
tmp.unlink(missing_ok=True)
cache = PromptCache(tmp, enabled=True)
llm = GatewayLLM(cache=cache, tasks=ALL_TASKS)
first = llm.complete("sys", PAGE_PROMPT, task="page", label="cache-test")
second = llm.complete("sys", PAGE_PROMPT, task="page", label="cache-test")
check("6. an identical prompt is served from cache",
      second == first and LEDGER.calls[-1].cached,
      f"{len(LEDGER.billable)} of 2 calls actually sent")
tmp.unlink(missing_ok=True)

# -- 7. stage scoping ------------------------------------------------------
# The shipped default is GATEWAY_TASKS = {"answer"}: the build never calls out,
# only live questions do. A disabled stage must cost nothing - no call, no
# ledger entry, no error - and quietly take the extractive path.
reset()
counted = {"n": 0}


def counting(**kw):
    counted["n"] += 1
    return REAL_QUERY(**kw)


llm_mod.QueryLLM = counting
llm = GatewayLLM(cache=None, tasks={"answer"})
out = llm.complete("sys", PAGE_PROMPT, task="page", label="scope-test")
check("7. a disabled stage makes no call and returns None",
      out is None and counted["n"] == 0 and not LEDGER.calls,
      f"{counted['n']} calls, {len(LEDGER.calls)} ledger entries")
concepts = fresh_concepts(llm)
page = build_concept_page(concepts[0], blocks_by_id, index, concepts, llm)
check("7. answers-only build still produces complete pages",
      bool(page["body"]) and page["generated_by"] == "extractive"
      and counted["n"] == 0,
      f"{len(page['body'])} chars, {counted['n']} gateway calls for the whole build")
ans = llm.complete("sys", PAGE_PROMPT, task="answer", label="scope-test")
check("7. the enabled stage still goes through",
      ans is not None and counted["n"] == 1, f"{counted['n']} call")

# -- 8. sequential throttle ------------------------------------------------
# The gateway is shared and takes one request at a time. min_interval is the
# knob that stops a build being the reason a colleague gets rate limited.
reset()
import time as _t
llm = GatewayLLM(cache=None, tasks=ALL_TASKS, min_interval=0.05)
t0 = _t.time()
for _ in range(4):
    llm.complete("sys", PAGE_PROMPT, task="page", label="throttle-test")
elapsed = _t.time() - t0
check("8. calls are spaced by min_interval", elapsed >= 0.15,
      f"4 calls took {elapsed:.2f}s at 0.05s spacing")

reset()
print("-" * 62)
print(f"  {len(PASS)} passed, {len(FAIL)} failed")
raise SystemExit(1 if FAIL else 0)
