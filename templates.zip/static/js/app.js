/* DHCP scope table: client-side sort, filter and duplicate hiding. */
$(function () {
  var $table = $('#scopeTable');
  var $body = $table.find('tbody');
  var $rows = $body.find('tr');

  // Cache each row's searchable text once.
  $rows.each(function () {
    $(this).data('search', $(this).text().replace(/\s+/g, ' ').toLowerCase());
  });

  function ipToNumber(text) {
    var parts = text.trim().split('.');
    if (parts.length !== 4) return -1;
    return parts.reduce(function (acc, part) {
      return acc * 256 + (parseInt(part, 10) || 0);
    }, 0);
  }

  function cellValue($row, index, type) {
    var $cell = $row.children().eq(index);
    if (type === 'ip') return ipToNumber($cell.text());
    var raw = $cell.data('value');
    if (raw === undefined) raw = $cell.text().trim();
    if (raw === '') return -1; // empty Exclsn / Rsrvn sort below zero
    return parseFloat(raw);
  }

  $table.find('th.sortable').on('click', function () {
    var $th = $(this);
    var index = $th.index();
    var type = $th.data('type');
    var asc = !$th.hasClass('asc');

    $table.find('th').removeClass('asc desc');
    $th.addClass(asc ? 'asc' : 'desc');

    var sorted = $body.find('tr').get().sort(function (a, b) {
      var av = cellValue($(a), index, type);
      var bv = cellValue($(b), index, type);
      if (av === bv) return 0;
      return (av < bv ? -1 : 1) * (asc ? 1 : -1);
    });

    $body.append(sorted);
  });

  function applyFilters() {
    var term = $('#filter').val().trim().toLowerCase();
    var dedupe = $('#dedupe').is(':checked');
    var seen = {};
    var visible = 0;

    $body.find('tr').each(function () {
      var $row = $(this);
      var match = !term || $row.data('search').indexOf(term) !== -1;

      if (match && dedupe) {
        var key = $row.data('key');
        if (seen[key]) {
          match = false;
        } else {
          seen[key] = true;
        }
      }

      $row.toggle(match);
      if (match) visible++;
    });

    $('#rowCount').text(visible + ' of ' + $rows.length + ' rows');
    $('#emptyMsg').prop('hidden', visible !== 0);
  }

  $('#filter').on('input', applyFilters);
  $('#dedupe').on('change', applyFilters);
  applyFilters();

  /* ---------- Scope detail modal ---------- */

  function numberToIp(n) {
    return [(n >>> 24) & 255, (n >>> 16) & 255, (n >>> 8) & 255, n & 255].join('.');
  }

  function fmt(n) {
    return n.toLocaleString('en-US');
  }

  // Builds one <div class="seg"> sized as a share of `total`.
  function segment(cls, count, total, label) {
    if (count <= 0) return null;
    var pct = (count / total) * 100;
    return $('<div class="seg"></div>')
      .addClass(cls)
      .css('width', pct.toFixed(4) + '%')
      .attr('title', label + ': ' + fmt(count) + ' addresses (' + pct.toFixed(1) + '%)')
      .append($('<span class="seg-text"></span>').text(fmt(count)));
  }

  function legendItem(cls, label, count, note) {
    var $li = $('<li></li>');
    $li.append($('<i></i>').addClass(cls));
    $li.append($('<b></b>').text(label));
    $li.append($('<span></span>').text(count === null ? note : fmt(count) + (note ? ' — ' + note : '')));
    return $li;
  }

  function statRow($dl, term, value) {
    $dl.append($('<dt></dt>').text(term));
    $dl.append($('<dd></dd>').text(value));
  }

  function openModal($row) {
    var d = $row.data();

    var cidr = Number(d.cidr);
    var netNum = ipToNumber(String(d.scope));
    var subnetSize = Math.pow(2, 32 - cidr);
    var bcastNum = netNum + subnetSize - 1;

    var startNum = ipToNumber(String(d.start));
    var endNum = ipToNumber(String(d.end));
    var poolSize = endNum - startNum + 1;

    var free = Number(d.free);
    var excl = Number(d.excl);
    var rsrvn = Number(d.rsrvn);
    var inUse = Number(d.inuse);
    var pct = Number(d.pct);

    var leadGap = startNum - netNum;          // addresses below the pool
    var tailGap = bcastNum - endNum;          // addresses above the pool

    $('#modalTitle').text(d.scope + '/' + cidr);
    $('#modalSub').text(
      fmt(subnetSize) + ' addresses in the subnet · ' +
      fmt(poolSize) + ' handed to DHCP · ' +
      pct.toFixed(1) + '% of usable space in use'
    );

    // --- Bar 1: the whole subnet, with the DHCP pool marked inside it ---
    var $subnet = $('#subnetBar').empty();
    $subnet.append(segment('s-outside', leadGap, subnetSize, 'Below the pool (gateway / static)'));
    $subnet.append(
      $('<div class="seg s-pool"></div>')
        .css('width', ((poolSize / subnetSize) * 100).toFixed(4) + '%')
        .attr('title', 'DHCP pool: ' + fmt(poolSize) + ' addresses')
        .append($('<span class="seg-text"></span>').text('DHCP pool · ' + fmt(poolSize)))
    );
    $subnet.append(segment('s-outside', tailGap, subnetSize, 'Above the pool (gateway / static)'));

    // Boundary callouts for the configured start/end, positioned along the bar.
    var startPct = (leadGap / subnetSize) * 100;
    var endPct = ((endNum - netNum + 1) / subnetSize) * 100;
    $('#subnetMarkers').empty()
      .append($('<span class="marker start"></span>')
        .css('left', startPct.toFixed(4) + '%')
        .append($('<i></i>'))
        .append($('<em></em>').text('start ' + d.start)))
      .append($('<span class="marker end"></span>')
        .css('left', endPct.toFixed(4) + '%')
        .append($('<i></i>'))
        .append($('<em></em>').text('end ' + d.end)));

    $('#netAddr').text('network ' + numberToIp(netNum));
    $('#bcastAddr').text('broadcast ' + numberToIp(bcastNum));

    // --- Bar 2: what the pool is made of ---
    // In Use + Exclusion + Free accounts for the pool exactly in this data set.
    var accounted = inUse + excl + free;
    var unaccounted = poolSize - accounted;

    var $pool = $('#poolBar').empty();
    $pool.append(segment('s-inuse', inUse, poolSize, 'In use'));
    $pool.append(segment('s-excl', excl, poolSize, 'Excluded'));
    $pool.append(segment('s-free', free, poolSize, 'Free'));
    if (unaccounted > 0) {
      $pool.append(segment('s-unknown', unaccounted, poolSize, 'Unaccounted'));
    }

    // Reservations are a subset of the pool, not an extra slice — show as an overlay.
    var $res = $('#rsrvnRow').empty();
    if (rsrvn > 0) {
      $res.append($('<div class="rsrvn-bar"></div>')
        .append($('<div class="rsrvn-fill"></div>')
          .css('width', ((rsrvn / poolSize) * 100).toFixed(4) + '%')));
      $res.append($('<p></p>').text(
        fmt(rsrvn) + ' reserved address' + (rsrvn === 1 ? '' : 'es') +
        ' — fixed leases held inside the pool above, not a separate block.'
      ));
    } else {
      $res.append($('<p class="muted-line"></p>').text('No reservations reported for this scope.'));
    }

    // --- Legend ---
    var $legend = $('#legend').empty();
    $legend.append(legendItem('s-inuse', 'In Use', inUse, 'leased right now'));
    if (excl > 0) $legend.append(legendItem('s-excl', 'Exclusion', excl, 'carved out, never leased'));
    $legend.append(legendItem('s-free', 'Free', free, 'available to hand out'));
    if (rsrvn > 0) $legend.append(legendItem('s-rsrvn', 'Reservation', rsrvn, 'pinned to a MAC'));
    $legend.append(legendItem('s-outside', 'Outside pool', leadGap + tailGap, 'static / gateway space'));
    if (unaccounted > 0) {
      $legend.append(legendItem('s-unknown', 'Unaccounted', unaccounted, 'not explained by the source row'));
    }

    // --- Numbers ---
    var $stats = $('#modalStats').empty();
    statRow($stats, 'Subnet', d.scope + '/' + cidr + ' (' + fmt(subnetSize) + ' addresses)');
    statRow($stats, 'Configured range', d.start + ' → ' + d.end + ' (' + fmt(poolSize) + ')');
    statRow($stats, 'Usable (In Use + Free)', fmt(inUse + free));
    statRow($stats, 'Utilization', inUse + ' of ' + (inUse + free) + ' usable = ' + pct.toFixed(1) + '%');
    statRow($stats, 'Headroom', fmt(free) + ' address' + (free === 1 ? '' : 'es') + ' left');

    $('#backdrop').prop('hidden', false);
    $('#modalClose').trigger('focus');
  }

  function closeModal() {
    $('#backdrop').prop('hidden', true);
  }

  $body.on('click', '.scope-link', function (e) {
    e.preventDefault();
    openModal($(this).closest('tr'));
  });

  $('#modalClose').on('click', closeModal);
  $('#backdrop').on('click', function (e) {
    if (e.target === this) closeModal();
  });
  $(document).on('keydown', function (e) {
    if (e.key === 'Escape') closeModal();
  });
});
