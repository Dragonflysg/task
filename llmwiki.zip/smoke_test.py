"""End-to-end check of the ask pipeline. Not part of the app.

    py smoke_test.py
"""
from llmwiki.wiki import Wiki

QUESTIONS = [
    # squarely covered
    "Why can I read the shared mailbox but not send from it?",
    # answer lives in a different file from the obvious one
    "How do I give a contractor access to a confidential finance share?",
    # spans three files
    "What happens to a leaver's access?",
    # covered, awkwardly phrased
    "granted access but still denied",
    # was a gap until corpus/mobile_devices.txt was added, then closed itself
    "How do I enrol a new iPhone in the mobile device management system?",
    # genuinely not in the corpus - must still become a gap
    "What is the guest wi-fi password?",
]

w = Wiki.load()
print(f"loaded: {w.stats}\n")

for q in QUESTIONS:
    page, cached = w.ask(q)
    tag = "GAP " if page["kind"] == "gap" else "ans "
    print(f"{tag} score={page['score']:6.2f}  cov={page['coverage']:.2f}  "
          f"{page['confidence']:6}  {q}")
    if page.get("absent"):
        print(f"        absent from corpus entirely: {', '.join(page['absent'])}")
    if page.get("missing"):
        print(f"        not covered by retrieved passages: {', '.join(page['missing'])}")
    for s in page["sources"][:3]:
        print(f"        [{s['n']}] {s['source']}:{s['line']:<4} {s['title'][:56]}")
    print(f"        related: {', '.join(r['name'] for r in page['related']) or '-'}")
    print(f"        url: /answer/{page['slug']}")
    print()

# cache check
page, cached = w.ask(QUESTIONS[0])
print(f"re-asked first question -> cached={cached}, asked={page['asked']}x")
print(f"gaps recorded: {len(w.gaps)}")
