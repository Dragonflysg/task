"""Check the rendered HTML actually contains the wiki features. Not part of the app.

    py html_check.py
"""
import re
import urllib.parse
import urllib.request

BASE = "http://127.0.0.1:8000"


def get(path: str) -> str:
    with urllib.request.urlopen(BASE + path, timeout=20) as r:
        return r.read().decode("utf-8")


def check(label: str, ok: bool, detail: str = "") -> None:
    print(f"  [{'ok ' if ok else 'FAIL'}] {label}{('  ' + detail) if detail else ''}")


page = get("/wiki/security-groups")
links = re.findall(r'<a class="wikilink" href="/wiki/([a-z0-9-]+)"', page)
cites = re.findall(r'<sup class="cite"><a href="#src-(\d+)"', page)
anchors = re.findall(r'<div class="src" id="src-(\d+)">', page)

check("concept page renders auto-links", len(links) >= 3, f"-> {sorted(set(links))}")
check("citation markers rendered", len(cites) >= 5, f"{len(cites)} markers")
check("every citation has a matching source anchor",
      set(cites) <= set(anchors), f"cites={len(set(cites))} anchors={len(set(anchors))}")
check("page does not link to itself", "security-groups" not in links)
check("source lines are linkable",
      '/source/accounts.txt#L' in page or '/source/printers.txt#L' in page)
check("no unrendered markdown left", "**" not in page)
check("no raw jinja left", "{{" not in page and "{%" not in page)

ans = get("/ask?q=" + urllib.parse.quote("Why can I read the shared mailbox but not send from it?"))
check("answer page shows confidence chip", 'class="chip high"' in ans or 'class="chip medium"' in ans)
check("answer page shows coverage", "question coverage" in ans)
check("answer page shows permalink", "/answer/" in ans)

# Must be a question the corpus genuinely cannot answer. The iPhone question
# used to live here, until corpus/mobile_devices.txt closed that gap.
gap = get("/ask?q=" + urllib.parse.quote("What is the guest wi-fi password?"))
check("gap page uses the red-link treatment", 'class="redlink"' in gap)
check("gap page names absent vocabulary", 'class="term absent"' in gap)
check("gap page generated no answer body", "In practice" not in gap)

gaps = get("/gaps")
check("gap report lists the question", "guest" in gaps.lower())

idx = get("/")
cards = idx.count('class="card"')
check("index lists every concept page", cards >= 10, f"{cards} cards")

src = get("/source/network_shares.txt")
check("source view has line anchors", 'id="L30"' in src)
