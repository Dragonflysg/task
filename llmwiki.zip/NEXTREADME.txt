
1. Yes, it's fully portable

The folder is self-contained. Copy it, pip install -r requirements.txt, delete my corpus\*.txt, drop yours in, run py build_wiki.py. Nothing is hardcoded to this machine — paths are all derived from ROOT in config.py, relative to the folder itself.

(Small thing: it's build_wiki.py, not .pyw. The .pyw extension on Windows suppresses the console window, which would hide the build output you actually want to read.)

2. No, it will not connect to an LLM

Two independent locks, and both are off by default:

Lock 1 — the environment variable. get_llm() at llmwiki/llm.py:66 only builds an Anthropic client if os.environ.get("ANTHROPIC_API_KEY") returns something. No key → NullLLM, whose complete() returns None unconditionally. There's no fallback key, no config file entry, no default endpoint. Nothing else in the codebase can reach a network.

Lock 2 — the package. anthropic is commented out in requirements.txt, so pip install -r requirements.txt doesn't install it. The import at llm.py:39 is deliberately lazy — inside __init__, not at module top. So even if a key were somehow set in that server's environment, without the package you get:

[llm] ANTHROPIC_API_KEY is set but the 'anthropic' package is not installed.

…and it silently falls back to offline. It cannot accidentally start calling out.

How to confirm on the server: the first line of build output is the answer.

mode      : offline (extractive)     <- no network, ever
mode      : Anthropic claude-opus-5  <- calling out

There's also LLMWIKI_OFFLINE=1 or py build_wiki.py --offline as a hard override if you want to pin it off regardless of environment.

3. Three things that will bite you on that server

Not changes I'm suggesting — just what to expect when you swap the corpus.

data\gaps.json survives a rebuild. The build overwrites wiki.json and clears answers.json (build_wiki.py:86), but deliberately leaves gaps alone — they're the record of what people asked and didn't get. Carry the folder over as-is and your new wiki starts with my demo's gaps ("guest wi-fi") already in the report. Delete the whole data\ folder after swapping the corpus; the build recreates it.

The tunables are calibrated to a small corpus. llmwiki/config.py:

- MAX_CONCEPTS = 26 — a sidebar cap. With substantially more topic files you'll hit it and pages will be silently dropped.
- MIN_CONCEPT_DOC_FREQ = 2 — a concept must appear in ≥2 blocks. On a bigger corpus, raise it or you'll mine noise.
- MIN_SCORE = 3.0 / MIN_COVERAGE = 0.62 — the answer/gap gate. These are the ones to watch. Different vocabulary shifts the IDF distribution, so check a handful of known-answerable and known-unanswerable questions after your first real build and move MIN_COVERAGE until it splits them correctly.

The file format has to match. # Topic: header, ## About paragraphs, Q: / A: pairs. The parser is tolerant of multi-line Q&A and missing section headers, but a file with no recognisable structure yields zero blocks and just vanishes from the build without an error.

The honest summary: nothing in this reaches the network unless you deliberately install a package and set a key. The offline path isn't a degraded fallback mode — it's what I built and verified everything against.
