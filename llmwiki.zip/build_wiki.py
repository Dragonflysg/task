"""Build the wiki from ./corpus into ./data/wiki.json.

    py build_wiki.py              # heuristic concepts, extractive pages
    py build_wiki.py --offline    # force offline even if a key is present

With ANTHROPIC_API_KEY set, concept extraction and page writing are done by the
model instead. Re-run this whenever the corpus changes.
"""
from __future__ import annotations

import json
import sys
from collections import Counter
from datetime import datetime, timezone

from llmwiki.concepts import attach_blocks, dedupe_slugs, extract_heuristic, extract_with_llm
from llmwiki.config import ANSWERS_FILE, DATA_DIR, WIKI_FILE
from llmwiki.corpus import all_blocks, load_corpus
from llmwiki.llm import get_llm
from llmwiki.pages import build_concept_page
from llmwiki.retrieval import BM25Index


def main() -> None:
    offline = "--offline" in sys.argv
    llm = get_llm(force_offline=offline)

    print("LLM Wiki build")
    print("=" * 62)
    print(f"  mode      : {llm.describe()}")

    docs = load_corpus()
    blocks = all_blocks(docs)
    kinds = Counter(b.kind for b in blocks)
    print(f"  corpus    : {len(docs)} files -> {len(blocks)} blocks "
          f"({kinds['qa']} Q&A, {kinds['prose']} discussion)")

    index = BM25Index(blocks)
    print(f"  index     : {len(index.idf)} unique terms, "
          f"avg block {index.avgdl:.0f} tokens")

    if llm.available:
        print("  concepts  : asking the model...")
        concepts = extract_with_llm(docs, blocks, llm)
    else:
        concepts = extract_heuristic(docs, blocks)

    dedupe_slugs(concepts)
    attach_blocks(concepts, blocks)
    concepts = [c for c in concepts if c.block_ids]
    concepts.sort(key=lambda c: (c.home_source is None, c.name.lower()))
    print(f"  concepts  : {len(concepts)} pages")

    blocks_by_id = {b.id: b for b in blocks}
    pages = {}
    for c in concepts:
        if llm.available:
            print(f"    writing {c.name}...")
        page = build_concept_page(c, blocks_by_id, index, concepts, llm)
        pages[c.slug] = page

    covered = {s["block_id"] for p in pages.values() for s in p["sources"]}
    orphans = [b for b in blocks if b.id not in covered]

    cross = [p for p in pages.values() if p["file_count"] > 1]

    data = {
        "built_at": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC"),
        "generated_by": llm.describe(),
        "concepts": [c.to_dict() for c in concepts],
        "pages": pages,
        "blocks": [b.to_dict() for b in blocks],
        "stats": {
            "files": len(docs), "blocks": len(blocks), "concepts": len(concepts),
            "orphan_blocks": len(orphans),
            "cross_file_pages": len(cross),
        },
    }

    DATA_DIR.mkdir(parents=True, exist_ok=True)
    WIKI_FILE.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")

    # Pages change on every rebuild, so a cached answer written against the old
    # pages would cite passages that may no longer be numbered the same way.
    if ANSWERS_FILE.exists():
        ANSWERS_FILE.write_text("{}", encoding="utf-8")

    print("-" * 62)
    print(f"  wrote     : {WIKI_FILE.relative_to(WIKI_FILE.parent.parent)}")
    print(f"  cross-file: {len(cross)} of {len(pages)} pages pull from more "
          f"than one source file")
    if orphans:
        print(f"  orphans   : {len(orphans)} blocks appear on no page:")
        for b in orphans[:5]:
            print(f"              - {b.source}:{b.line}  {b.title[:58]}")
    print()
    print("  Next:  py -m uvicorn app:app --reload   ->  http://127.0.0.1:8000")


if __name__ == "__main__":
    main()
