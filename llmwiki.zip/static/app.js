// Clicking a [n] citation scrolls to the source and flashes it, so the reader
// can check a claim against the exact passage without losing their place.
document.addEventListener('click', function (e) {
  var a = e.target.closest('sup.cite a');
  if (!a) return;
  e.preventDefault();
  var el = document.getElementById('src-' + a.dataset.cite);
  if (!el) return;
  el.scrollIntoView({ behavior: 'smooth', block: 'center' });
  document.querySelectorAll('.src.flash').forEach(function (s) { s.classList.remove('flash'); });
  el.classList.add('flash');
  setTimeout(function () { el.classList.remove('flash'); }, 2200);
});
