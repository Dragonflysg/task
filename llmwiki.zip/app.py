"""FastAPI front end for the LLM Wiki.

    py -m uvicorn app:app --reload

Routes
    /                  index: search + every concept page
    /wiki/{slug}       a concept page, synthesised from the whole corpus
    /ask?q=...         answer a question, then redirect to its permanent URL
    /answer/{slug}     a previously answered question, cached and shareable
    /gaps              questions the corpus could not answer
    /answers           every question answered so far, most asked first
    /sources           the raw source files behind everything
    /api/ask?q=...     the same answer as JSON
"""
from __future__ import annotations

from typing import Optional

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from llmwiki.config import ROOT, SITE_NAME, SITE_TAGLINE, WIKI_FILE
from llmwiki.llm import get_llm
from llmwiki.render import Linker, render_markdown
from llmwiki.wiki import Wiki

app = FastAPI(title=SITE_NAME)
app.mount("/static", StaticFiles(directory=ROOT / "static"), name="static")
templates = Jinja2Templates(directory=str(ROOT / "templates"))

_wiki: Optional[Wiki] = None
_wiki_mtime: float = 0.0


def get_wiki() -> Wiki:
    """Load the built wiki, and pick up a rebuild without a server restart.

    build_wiki.py rewrites data/wiki.json. Watching its mtime means the workflow
    for adding a topic file is 'rebuild, refresh the browser' rather than
    'rebuild, remember to restart the server, refresh the browser'.
    """
    global _wiki, _wiki_mtime
    try:
        mtime = WIKI_FILE.stat().st_mtime
    except OSError:
        mtime = 0.0

    if _wiki is None or mtime != _wiki_mtime:
        try:
            _wiki = Wiki.load()
            _wiki_mtime = mtime
        except SystemExit as exc:
            raise HTTPException(status_code=503, detail=str(exc))
    return _wiki


def ctx(request: Request, **kw) -> dict:
    w = get_wiki()
    base = {
        "request": request,
        "site_name": SITE_NAME,
        "tagline": SITE_TAGLINE,
        "nav_pages": w.concept_index(),
        "wiki": w,
        "llm_mode": get_llm().describe(),
    }
    base.update(kw)
    return base


def render_body(body: str, slug: Optional[str] = None) -> str:
    w = get_wiki()
    return render_markdown(body, Linker(w.concepts, current_slug=slug))


# --------------------------------------------------------------------------
@app.get("/", response_class=HTMLResponse)
def index(request: Request):
    w = get_wiki()
    examples = [
        "How do I request a shared mailbox?",
        "I was granted access to a share but still get access denied",
        "How do I give a contractor access to a confidential finance share?",
        "What is the difference between a resource mailbox and a shared mailbox?",
        "I lost my phone and cannot pass MFA",
        "How do I enrol a new iPhone in the mobile device management system?",
        "What is the guest wi-fi password?",   # deliberately unanswerable: shows a gap page
    ]
    return templates.TemplateResponse(request, "index.html", ctx(
        request, examples=examples, stats=w.stats,
        recent=w.sorted_answers()[:6], gap_count=len(w.gaps),
    ))


@app.get("/wiki/{slug}", response_class=HTMLResponse)
def wiki_page(request: Request, slug: str):
    w = get_wiki()
    page = w.page(slug)
    if not page:
        raise HTTPException(status_code=404, detail=f"No wiki page '{slug}'")
    return templates.TemplateResponse(request, "page.html", ctx(
        request, page=page, body_html=render_body(page["body"], slug),
    ))


@app.get("/ask")
def ask(request: Request, q: str = ""):
    if not q.strip():
        return RedirectResponse("/", status_code=303)
    page, _cached = get_wiki().ask(q)
    return RedirectResponse(f"/answer/{page['slug']}", status_code=303)


@app.get("/answer/{slug}", response_class=HTMLResponse)
def answer_page(request: Request, slug: str):
    w = get_wiki()
    page = w.answer_page(slug)
    if not page:
        raise HTTPException(status_code=404, detail="That answer has expired; ask again.")
    if page["kind"] == "gap":
        return templates.TemplateResponse(request, "gap.html", ctx(
        request, page=page))
    return templates.TemplateResponse(request, "answer.html", ctx(
        request, page=page, body_html=render_body(page["body"]),
    ))


@app.get("/gaps", response_class=HTMLResponse)
def gaps(request: Request):
    w = get_wiki()
    return templates.TemplateResponse(request, "gaps.html", ctx(
        request, gaps=w.sorted_gaps()))


@app.get("/answers", response_class=HTMLResponse)
def answers(request: Request):
    w = get_wiki()
    return templates.TemplateResponse(request, "answers.html", ctx(
        request, answers=[a for a in w.sorted_answers() if a["kind"] == "answer"],
    ))


@app.get("/sources", response_class=HTMLResponse)
def sources(request: Request):
    w = get_wiki()
    return templates.TemplateResponse(request, "sources.html", ctx(
        request, files=w.source_files()))


@app.get("/source/{name}", response_class=HTMLResponse)
def source_file(request: Request, name: str):
    from llmwiki.config import CORPUS_DIR

    path = (CORPUS_DIR / name).resolve()
    if not path.is_file() or CORPUS_DIR.resolve() not in path.parents:
        raise HTTPException(status_code=404, detail="No such source file")
    lines = path.read_text(encoding="utf-8").splitlines()
    return templates.TemplateResponse(request, "source.html", ctx(
        request, name=name, lines=list(enumerate(lines, start=1)),
    ))


@app.get("/api/ask")
def api_ask(q: str = ""):
    if not q.strip():
        return JSONResponse({"error": "pass ?q=your+question"}, status_code=400)
    page, cached = get_wiki().ask(q)
    return JSONResponse({
        "question": page.get("question", q),
        "kind": page["kind"],
        "url": f"/answer/{page['slug']}",
        "confidence": page.get("confidence"),
        "score": page.get("score"),
        "coverage": page.get("coverage"),
        "missing_terms": page.get("missing", []),
        "absent_from_corpus": page.get("absent", []),
        "generated_by": page.get("generated_by"),
        "cached": cached,
        "answer": page.get("body", ""),
        "citations": [
            {"n": s["n"], "source": s["source"], "line": s["line"],
             "topic": s["topic"], "title": s["title"]}
            for s in page.get("sources", [])
        ],
        "related_pages": page.get("related", []),
    })
