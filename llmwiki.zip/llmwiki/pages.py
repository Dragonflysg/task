"""Synthesise one wiki page per concept.

This is where the LLM Wiki earns its keep over plain RAG. A concept page is not
a copy of the file that happens to share its name - it is assembled from every
block anywhere in the corpus that mentions the concept. So the "Security Group"
page absorbs the group material buried inside network_shares.txt, accounts.txt
and shared_mailboxes.txt, which is knowledge no single source file contains.
"""
from __future__ import annotations

import math
from typing import Dict, List

from .concepts import Concept
from .config import MAX_RELATED
from .corpus import Block
from .llm import LLM
from .retrieval import BM25Index

MAX_BLOCKS_PER_PAGE = 12


def _order_blocks(concept: Concept, blocks: List[Block], index: BM25Index) -> List[Block]:
    scores = {b.id: s for b, s in index.search(concept.name, k=index.n)}

    def rank(b: Block):
        home = 0 if (concept.home_source and b.source == concept.home_source) else 1
        prose = 0 if b.kind == "prose" else 1
        return (home, prose, -scores.get(b.id, 0.0))

    ordered = sorted(blocks, key=rank)
    return ordered[:MAX_BLOCKS_PER_PAGE]


def _sources_for(blocks: List[Block]) -> List[dict]:
    out = []
    for i, b in enumerate(blocks, start=1):
        out.append({
            "n": i, "block_id": b.id, "source": b.source, "line": b.line,
            "topic": b.topic, "title": b.title, "kind": b.kind,
            "question": b.question, "text": b.text,
        })
    return out


def _extractive_body(concept: Concept, blocks: List[Block]) -> str:
    cite = {b.id: i for i, b in enumerate(blocks, start=1)}
    home = concept.home_source
    parts: List[str] = []

    prose = [b for b in blocks if b.kind == "prose"]
    qa_home = [b for b in blocks if b.kind == "qa" and (not home or b.source == home)]
    qa_other = [b for b in blocks if b.kind == "qa" and home and b.source != home]

    if prose:
        parts.append(f"{prose[0].text} [{cite[prose[0].id]}]")
        if len(prose) > 1:
            parts.append("### In detail")
            for b in prose[1:]:
                parts.append(f"{b.text} [{cite[b.id]}]")
    elif qa_home:
        b = qa_home[0]
        parts.append(f"{b.text} [{cite[b.id]}]")

    if qa_home:
        parts.append("### Common questions")
        for b in qa_home:
            parts.append(f"**{b.question}**")
            parts.append(f"{b.text} [{cite[b.id]}]")

    if qa_other:
        parts.append("### Covered elsewhere in the knowledge base")
        for b in qa_other:
            parts.append(f"**{b.question}** *({b.topic})*")
            parts.append(f"{b.text} [{cite[b.id]}]")

    return "\n\n".join(parts)


_SYSTEM = (
    "You write internal IT wiki pages. You use only the numbered excerpts you "
    "are given, you never invent a policy, a number, or a process step, and you "
    "cite every factual sentence with the bracketed number of the excerpt it "
    "came from."
)

_PROMPT = """Write the wiki page for the concept: {name}

Use only the excerpts below. Cite with [n] matching the excerpt numbers. If the
excerpts disagree or leave something open, say so plainly rather than smoothing
it over.

Structure:
- Open with a two or three sentence definition. No heading above it.
- "### In detail" - how it actually works here, in prose.
- "### Common questions" - the recurring questions, each as a bold line
  followed by the answer.
- Do not write a sources section; it is added automatically.

Write for a colleague who is competent but new. British spelling. Markdown only.

{excerpts}
"""


def _llm_body(concept: Concept, blocks: List[Block], llm: LLM) -> str | None:
    excerpts = []
    for i, b in enumerate(blocks, start=1):
        head = f"[{i}] ({b.source}, {b.topic})"
        body = f"Q: {b.question}\nA: {b.text}" if b.kind == "qa" else b.text
        excerpts.append(f"{head}\n{body}")
    return llm.complete(
        _SYSTEM,
        _PROMPT.format(name=concept.name, excerpts="\n\n".join(excerpts)),
        max_tokens=1600,
    )


def related_concepts(concept: Concept, all_concepts: List[Concept]) -> List[dict]:
    mine = set(concept.block_ids)
    if not mine:
        return []
    scored = []
    for other in all_concepts:
        if other.slug == concept.slug:
            continue
        theirs = set(other.block_ids)
        if not theirs:
            continue
        overlap = len(mine & theirs)
        if not overlap:
            continue
        # Cosine-style normalisation. Dividing by min() instead would rank a
        # three-block concept above the page it actually belongs next to,
        # because two shared blocks is most of a tiny concept.
        score = overlap / math.sqrt(len(mine) * len(theirs))
        scored.append((score, overlap, other))
    scored.sort(key=lambda t: (t[0], t[1]), reverse=True)
    return [{"slug": c.slug, "name": c.name, "shared": n}
            for _, n, c in scored[:MAX_RELATED]]


def build_concept_page(concept: Concept, blocks_by_id: Dict[str, Block],
                       index: BM25Index, all_concepts: List[Concept],
                       llm: LLM) -> dict:
    members = [blocks_by_id[i] for i in concept.block_ids if i in blocks_by_id]
    chosen = _order_blocks(concept, members, index)

    body, generated_by = None, "extractive"
    if llm.available and chosen:
        body = _llm_body(concept, chosen, llm)
        if body:
            generated_by = llm.describe()
    if not body:
        body = _extractive_body(concept, chosen)

    updated = max((b.updated for b in chosen), default="unknown")

    return {
        "slug": concept.slug,
        "title": concept.name,
        "kind": "concept",
        "body": body,
        "sources": _sources_for(chosen),
        "related": related_concepts(concept, all_concepts),
        "generated_by": generated_by,
        "updated": updated,
        "home_source": concept.home_source,
        "block_count": len(members),
        "file_count": len({b.source for b in chosen}),
    }
