"""Pluggable LLM adapter.

The whole point of this module is that nothing else in the codebase knows
whether a model is present. Every caller does:

    llm = get_llm()
    out = llm.complete(system=..., user=...)
    if out is None:
        ...fall back to the deterministic extractive path...

With no API key the app runs fully offline on BM25 + extraction. Set
ANTHROPIC_API_KEY and the same code paths start producing synthesised prose.
That is the switch you flip when you port this into your own platform.
"""
from __future__ import annotations

import os
from typing import Optional


class LLM:
    name = "none"
    available = False

    def complete(self, system: str, user: str, max_tokens: int = 1200) -> Optional[str]:
        return None

    def describe(self) -> str:
        return "offline (extractive)"


class NullLLM(LLM):
    """No model. Callers fall back to deterministic extraction."""


class AnthropicLLM(LLM):
    name = "anthropic"
    available = True

    def __init__(self, model: str, api_key: str):
        from anthropic import Anthropic  # imported lazily so the dep is optional

        self.model = model
        self.client = Anthropic(api_key=api_key)

    def complete(self, system: str, user: str, max_tokens: int = 1200) -> Optional[str]:
        try:
            msg = self.client.messages.create(
                model=self.model,
                max_tokens=max_tokens,
                system=system,
                messages=[{"role": "user", "content": user}],
            )
            return "".join(b.text for b in msg.content if b.type == "text").strip()
        except Exception as exc:  # never let a model outage break the wiki
            print(f"  [llm] call failed, falling back to extractive: {exc}")
            return None

    def describe(self) -> str:
        return f"Anthropic {self.model}"


_cached: Optional[LLM] = None


def get_llm(force_offline: bool = False) -> LLM:
    global _cached
    if _cached is not None and not force_offline:
        return _cached
    if force_offline or os.environ.get("LLMWIKI_OFFLINE") == "1":
        _cached = NullLLM()
        return _cached

    key = os.environ.get("ANTHROPIC_API_KEY")
    if key:
        model = os.environ.get("LLMWIKI_MODEL", "claude-opus-5")
        try:
            _cached = AnthropicLLM(model, key)
            return _cached
        except ImportError:
            print("  [llm] ANTHROPIC_API_KEY is set but the 'anthropic' package "
                  "is not installed. Run: pip install anthropic")
        except Exception as exc:
            print(f"  [llm] could not initialise Anthropic client: {exc}")

    _cached = NullLLM()
    return _cached
