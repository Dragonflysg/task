"""Central configuration. Everything tunable lives here."""
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
CORPUS_DIR = ROOT / "corpus"
DATA_DIR = ROOT / "data"

WIKI_FILE = DATA_DIR / "wiki.json"
ANSWERS_FILE = DATA_DIR / "answers.json"
GAPS_FILE = DATA_DIR / "gaps.json"

# --- Retrieval -------------------------------------------------------------
BM25_K1 = 1.5
BM25_B = 0.75
TOP_K = 6

# Gate for answering at all. A question that fails either test becomes a "red
# link" knowledge gap instead of a confidently wrong answer. These two numbers
# are the most important in the project: raise them and the wiki gets cautious,
# lower them and it starts bluffing.
#
# MIN_SCORE alone is not enough. BM25 is unbounded and rewards long questions,
# so "how do I enrol an iPhone in mobile device management" scores well against
# an IT corpus that has never heard of iPhones - every other word matches
# something. MIN_COVERAGE is what actually catches those: it measures how much
# of the question's information weight the retrieved passages account for.
MIN_SCORE = 3.0
MIN_COVERAGE = 0.62

# --- Wiki construction -----------------------------------------------------
MAX_CONCEPTS = 26          # keeps the sidebar readable
MIN_CONCEPT_DOC_FREQ = 2   # a concept must appear in at least this many blocks
MAX_RELATED = 6
LINKS_PER_ALIAS_PER_PAGE = 1

SITE_NAME = "IT Knowledge Wiki"
SITE_TAGLINE = "Generated from the source files in /corpus"
