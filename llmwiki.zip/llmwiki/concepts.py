"""Concept extraction - the step that turns a pile of files into a wiki.

A plain RAG pipeline stops after chunking. This is the extra step: work out
what *things* the corpus is about, so that each one can get its own page and
so that mentions of them can be turned into hyperlinks.

Two implementations behind one interface:
  * heuristic  - capitalised phrases + acronyms, filtered by document frequency
  * llm        - ask a model to name the canonical concepts and their aliases

The heuristic is surprisingly good on IT documentation, because the things that
matter ("Resource Mailbox", "Security Group", "MFA") are almost always written
in title case or as acronyms. It is also free and deterministic, which makes it
the right default for a demo.
"""
from __future__ import annotations

import json
import re
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from typing import Dict, List, Optional

from .config import MAX_CONCEPTS, MIN_CONCEPT_DOC_FREQ
from .corpus import Block, Document
from .llm import LLM

BLACKLIST = {
    "it", "hr", "pdf", "ok", "sms", "wi", "fi", "ctrl", "alt", "delete",
    "january", "february", "march", "april", "may", "june", "july", "august",
    "september", "october", "november", "december", "monday", "friday",
    "the", "this", "that", "there", "these", "those", "each", "every", "any",
    "how", "what", "why", "who", "when", "where", "which", "yes", "not",
    "raise", "supply", "check", "confirm", "use", "ask", "note", "select",
    "expect", "after", "before", "most", "some", "only", "both", "either",
    "your", "their", "our", "you", "they", "we", "if", "do", "does", "can",
}

_TITLE_PHRASE = re.compile(r"\b([A-Z][a-z]{2,}(?:\s+(?:[A-Z][a-z]{1,}|On|As|Of|And)){1,3})\b")
# An acronym must stand alone. Without the hyphen guards, a naming convention
# like GRP-SHARE-FINANCE-RW donates four bogus "concepts" to the wiki.
_ACRONYM = re.compile(r"(?<![A-Za-z-])([A-Z]{3,6})(?![\w-])")
_SENTENCE_SPLIT = re.compile(r"(?<=[.!?])\s+")

# Connectors that may sit inside a concept name but never end one.
_BAD_TAIL = {"of", "and", "on", "the", "a", "to", "in", "for", "with"}


@dataclass
class Concept:
    slug: str
    name: str
    aliases: List[str] = field(default_factory=list)
    home_source: Optional[str] = None   # the file whose Topic: header is this concept
    block_ids: List[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "slug": self.slug, "name": self.name, "aliases": self.aliases,
            "home_source": self.home_source, "block_ids": self.block_ids,
        }


def slugify(name: str) -> str:
    s = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")
    return s or "page"


def _singular(word: str) -> str:
    lw = word.lower()
    if lw.endswith("ies") and len(lw) > 4:
        return lw[:-3] + "y"
    if lw.endswith("sses") or lw.endswith("shes") or lw.endswith("ches"):
        return lw[:-2]
    if lw.endswith("s") and not lw.endswith("ss") and len(lw) > 3:
        return lw[:-1]
    return lw


def _key(name: str) -> str:
    """Normalised identity for a concept, so 'Resource Mailboxes' == 'resource mailbox'."""
    parts = [_singular(p) for p in re.split(r"[\s\-]+", name.lower()) if p]
    return " ".join(parts)


def _aliases_for(name: str) -> List[str]:
    out = {name}
    words = name.split()
    if words:
        last = words[-1]
        sing = _singular(last)
        stem = " ".join(words[:-1])
        for variant in {sing, sing + "s", sing + "es", last}:
            v = (stem + " " + variant).strip()
            if len(v) > 2:
                out.add(v)
    return sorted(out, key=len, reverse=True)


# --------------------------------------------------------------------------
# Heuristic extraction
# --------------------------------------------------------------------------
def _acceptable(phrase: str) -> bool:
    """Reject phrases that are grammar rather than subject matter.

    Single title-case words are deliberately not mined. On documentation like
    this they are almost always sentence openers ("Access is granted by...",
    "Groups are named for...") and they produce catch-all pages that match
    every block in the corpus, which is worse than having no page at all.
    """
    words = phrase.split()
    if len(words) < 2:
        return phrase.isupper() and len(phrase) >= 3   # acronyms only
    low = [w.lower() for w in words]
    if low[0] in BLACKLIST or low[-1] in BLACKLIST:
        return False
    if low[-1] in _BAD_TAIL:
        return False
    return not all(w in BLACKLIST for w in low)


def _candidates(blocks: List[Block]) -> Counter:
    """Count how many distinct blocks each candidate phrase appears in."""
    df: Dict[str, set] = defaultdict(set)

    for b in blocks:
        found = set()
        for line in b.concept_text.split("\n"):
            for m in _TITLE_PHRASE.finditer(line):
                phrase = " ".join(m.group(1).split())
                if len(phrase.split()) <= 4:
                    found.add(phrase)
            for m in _ACRONYM.finditer(line):
                found.add(m.group(1))

        for phrase in found:
            if not _acceptable(phrase):
                continue
            key = _key(phrase)
            if key in BLACKLIST:
                continue
            df[key].add(b.id)

    return Counter({k: len(v) for k, v in df.items()})


def _display_name(key: str, blocks: List[Block]) -> str:
    """Recover the most common surface form of a normalised key."""
    pattern = re.compile(
        r"\b" + r"\w*\s+".join(re.escape(p) for p in key.split()) + r"\w*\b", re.I
    )
    forms = Counter()
    for b in blocks:
        for m in pattern.finditer(b.concept_text):
            forms[" ".join(m.group(0).split())] += 1
    if not forms:
        return key.title()
    # Prefer the most frequent form, tie-broken toward title case.
    best = max(forms.items(), key=lambda kv: (kv[1], kv[0][:1].isupper()))
    return best[0]


def _absorb_into_topic(concepts: Dict[str, Concept], key: str, name: str) -> bool:
    """Fold a mined concept into a topic page when it is a proper subset of it.

    'MFA' inside 'Passwords and MFA', or 'VPN' inside 'VPN and Remote Access',
    should be an alias that links to the topic page, not a second near-identical
    page sitting next to it in the sidebar.
    """
    tokens = set(key.split())
    for k, c in concepts.items():
        if not c.home_source:
            continue
        if tokens and tokens < set(k.split()):
            c.aliases = sorted(set(c.aliases) | set(_aliases_for(name)),
                               key=len, reverse=True)
            return True
    return False


def extract_heuristic(docs: List[Document], blocks: List[Block]) -> List[Concept]:
    concepts: Dict[str, Concept] = {}

    # 1. Every source file's Topic: header is guaranteed a page.
    for d in docs:
        k = _key(d.topic)
        concepts[k] = Concept(
            slug=slugify(d.topic), name=d.topic,
            aliases=_aliases_for(d.topic), home_source=d.source,
        )

    # 2. Mine the rest, ranked by how many blocks mention them.
    counts = _candidates(blocks)
    for key, freq in counts.most_common():
        if len(concepts) >= MAX_CONCEPTS:
            break
        if freq < MIN_CONCEPT_DOC_FREQ or key in concepts:
            continue
        name = _display_name(key, blocks)
        if len(name) < 3 or len(name.split()) > 4:
            continue
        if _absorb_into_topic(concepts, key, name):
            continue
        concepts[key] = Concept(slug=slugify(name), name=name, aliases=_aliases_for(name))

    return list(concepts.values())


# --------------------------------------------------------------------------
# LLM extraction
# --------------------------------------------------------------------------
_SYSTEM = (
    "You extract the canonical concepts from internal IT documentation so they "
    "can each become a wiki page. Return JSON only."
)

_PROMPT = """Below is one file from an internal IT knowledge base.

List the distinct concepts a reader would expect to find as their own wiki page.
A concept is a thing, system, artefact, or policy that the documentation is
*about* - not an action, not a symptom, not a whole sentence.

Return a JSON array, at most 8 entries, each of the form:
  {{"name": "Resource Mailbox", "aliases": ["resource mailboxes", "room mailbox"]}}

Use the singular form for the name. Aliases are other surface forms that appear
in the text and should link to the same page. JSON array only, no commentary.

--- FILE: {source} ---
{body}
"""


def extract_with_llm(docs: List[Document], blocks: List[Block], llm: LLM) -> List[Concept]:
    concepts: Dict[str, Concept] = {}

    for d in docs:
        k = _key(d.topic)
        concepts[k] = Concept(
            slug=slugify(d.topic), name=d.topic,
            aliases=_aliases_for(d.topic), home_source=d.source,
        )

    for d in docs:
        body = "\n\n".join(
            (f"Q: {b.question}\nA: {b.text}" if b.kind == "qa" else b.text)
            for b in d.blocks
        )[:12000]
        out = llm.complete(_SYSTEM, _PROMPT.format(source=d.source, body=body), max_tokens=900)
        if not out:
            continue
        try:
            start, end = out.find("["), out.rfind("]")
            items = json.loads(out[start:end + 1])
        except Exception:
            print(f"  [concepts] could not parse model output for {d.source}")
            continue

        for item in items:
            name = str(item.get("name", "")).strip()
            if not name:
                continue
            key = _key(name)
            if key in BLACKLIST:
                continue
            aliases = set(_aliases_for(name))
            aliases.update(str(a).strip() for a in item.get("aliases", []) if str(a).strip())
            if key in concepts:
                merged = set(concepts[key].aliases) | aliases
                concepts[key].aliases = sorted(merged, key=len, reverse=True)
            elif _absorb_into_topic(concepts, key, name):
                continue
            elif len(concepts) < MAX_CONCEPTS:
                concepts[key] = Concept(
                    slug=slugify(name), name=name,
                    aliases=sorted(aliases, key=len, reverse=True),
                )

    return list(concepts.values())


# --------------------------------------------------------------------------
def attach_blocks(concepts: List[Concept], blocks: List[Block]) -> None:
    """Record which blocks mention each concept. This is the wiki's edge list."""
    for c in concepts:
        pattern = re.compile(
            "|".join(r"\b" + re.escape(a) + r"\b" for a in c.aliases), re.I
        )
        ids = [b.id for b in blocks if pattern.search(b.search_text)]
        # A concept's home file always contributes its blocks, even if the exact
        # phrase never appears in a given paragraph.
        if c.home_source:
            home = [b.id for b in blocks if b.source == c.home_source]
            ids = list(dict.fromkeys(home + ids))
        c.block_ids = ids


def dedupe_slugs(concepts: List[Concept]) -> None:
    seen: Dict[str, int] = {}
    for c in concepts:
        if c.slug in seen:
            seen[c.slug] += 1
            c.slug = f"{c.slug}-{seen[c.slug]}"
        else:
            seen[c.slug] = 1
