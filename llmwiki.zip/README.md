# LLM Wiki

Turns a folder of plain-text Q&A files into a browsable, hyperlinked, cited wiki —
and answers questions *as wiki pages* rather than as chat messages.

Runs with no API key. Add one and the same code paths start using a real model.

## Run it

```
py -m pip install -r requirements.txt
py build_wiki.py
py -m uvicorn app:app --reload
```

Then open <http://127.0.0.1:8000>.

To switch on real generation:

```
$env:ANTHROPIC_API_KEY = "sk-ant-..."
py -m pip install anthropic
py build_wiki.py          # concepts and pages are now written by the model
```

`LLMWIKI_MODEL` overrides the model (default `claude-opus-5`). `LLMWIKI_OFFLINE=1`
or `py build_wiki.py --offline` forces the offline path even when a key is set.

## Why this is not just RAG with a nicer skin

Classic RAG: question → retrieve → generate → display → discard. Every question is
a cold start, the user has to already know what to ask, and a weak retrieval still
produces a confident answer.

This adds four things:

**1. Concepts, not just chunks.** The build works out what the corpus is *about*
(`Security Group`, `Send As`, `MFA`) and gives each one a page assembled from every
passage that mentions it, anywhere. The Security Groups page here pulls its best
paragraph out of `accounts.txt` and another out of `printers.txt` — knowledge that
exists in no single source file. 7 of 14 pages draw on more than one file.

**2. Auto-linking.** Mentions of other concepts become links, so a reader can wander
the knowledge base instead of having to invent the next question.

**3. Answers are durable artefacts.** Every answer gets a permanent URL, citations
to the exact `file:line`, and links to the pages it touched. Ask the same question
again and you get the identical cached page — which matters when the answer is
policy, not opinion.

**4. Honest failure, recorded.** A question the corpus cannot answer produces a
red-link gap page naming the vocabulary that is missing, and joins a ranked gap
report. That report is a documentation backlog written by the people who needed
the answers.

### The gap detection is the interesting part

A BM25 score cannot be thresholded on its own. Before `corpus/mobile_devices.txt`
existed, *"How do I enrol a new iPhone in the mobile device management system?"*
scored **8.27** against this corpus — comfortably above any sane floor, because
`enrol`, `new`, `device`, `management` and `system` all matched something. A naive
pipeline hands those passages to a model and gets back a fluent, well-cited,
entirely invented MDM policy.

So answering is gated on **coverage** as well: the share of the question's IDF
weight that the retrieved passages actually account for, with terms absent from
the corpus weighted as maximally rare so they can never be covered. `iphone` and
`mobile` appeared nowhere in the corpus, so coverage capped at 56% and the
question became a gap page instead of a fabrication.

| Question | Score | Coverage | Result |
|---|---|---|---|
| Why can I read the shared mailbox but not send from it? | 12.55 | 100% | answered |
| Give a contractor access to a confidential finance share | 11.21 | 100% | answered |
| Enrol a new iPhone in mobile device management | 8.27 | 56% | **gap** — *iphone, mobile* |
| ...the same question, after adding `mobile_devices.txt` | 19.43 | 100% | answered, high |
| What is the guest wi-fi password? | 3.69 | 59% | **gap** — *guest* |

That fourth row is the loop the whole thing exists for: the gap report says what
the knowledge base is missing, someone writes the file, and the question answers
itself on the next build. Nothing was tuned to make it happen.

Both knobs are in `llmwiki/config.py` (`MIN_SCORE`, `MIN_COVERAGE`). They are the
most important numbers in the project: raise them and the wiki gets cautious,
lower them and it starts bluffing.

## Layout

```
corpus/              9 sample IT topic files - the input
llmwiki/
  config.py          every tunable number
  corpus.py          parse .txt -> Blocks (one Q&A pair or paragraph each)
  retrieval.py       BM25 + the coverage metric. Pure Python, no deps
  concepts.py        concept extraction (heuristic or model)
  pages.py           assemble one wiki page per concept
  answer.py          the ask pipeline, gap detection, citations
  render.py          markdown -> HTML, and the auto-linker
  llm.py             the pluggable model adapter
  wiki.py            runtime: load, ask, cache, record gaps
build_wiki.py        the build
app.py               FastAPI routes
data/                generated: wiki.json, answers.json, gaps.json
```

Checking scripts, not part of the app: `inspect_wiki.py` (dump a built page),
`smoke_test.py` (the ask pipeline), `route_check.py` (every route),
`html_check.py` (rendered HTML features), `llm_path_test.py` (LLM paths, using a
stub model).

## Adding your own content

Drop a `.txt` file in `corpus/` shaped like the existing ones:

```
# Topic: Resource Mailboxes
# Owner: Messaging Team
# Updated: 2026-01-19

## About
Free paragraphs of discussion. Each paragraph becomes one retrievable block.

## Questions
Q: How do I request a new resource mailbox?
A: Raise a request specifying whether it is a room or equipment...
```

Then `py build_wiki.py` and refresh the browser. The server watches the mtime of
`data/wiki.json`, so a rebuild is picked up without restarting it. New concepts,
pages and cross-links appear automatically. The parser is forgiving: multi-line
questions and answers are fine, and the `## About` / `## Questions` split is a
convention rather than a requirement.

**The build makes no network calls unless a key is set.** Parsing, indexing,
concept mining and page assembly are all local Python. With `ANTHROPIC_API_KEY`
set, a full build costs one model call per source file (concept extraction) plus
one per concept page — about 23 calls for this corpus — and it rebuilds
everything each time rather than only what changed.

## Porting into an existing Python RAG platform

The pieces are deliberately separable:

- **Keep your retriever.** Everything downstream needs only
  `search(query, k) -> [(block, score)]`. Swap `retrieval.py` for your pgvector or
  Chroma call. Keep `coverage()` though, or reimplement it — with embeddings you
  lose the lexical signal that makes gap detection work, so run a cheap lexical
  pass alongside the vector search purely to compute it.
- **`concepts.py` + `pages.py` are the actual product.** They are the offline
  build step you do not currently have. Run it on a schedule against your existing
  chunk store.
- **`llm.py` is the seam.** Replace `AnthropicLLM` with whatever you already call.
- **`answer.py`** shows the gate: retrieve, measure coverage, refuse or answer,
  cite, persist, link.

## Things worth knowing

- Rebuilding clears `data/answers.json`, because citation numbers are assigned per
  build and a cached answer would point at the wrong passage. Gaps in
  `data/gaps.json` survive — they are the valuable record.
- Concept extraction deliberately does not mine single title-case words. On
  documentation like this they are almost always sentence openers ("Access is
  granted…"), and they produce catch-all pages that match everything.
- If a model call fails, the page or answer silently falls back to the extractive
  path rather than erroring. A model outage should not take the wiki down.
