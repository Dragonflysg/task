"""Hit every route and report status + size. Not part of the app.

    py route_check.py
"""
import urllib.parse
import urllib.request

BASE = "http://127.0.0.1:8000"

ROUTES = [
    "/",
    "/wiki/security-groups",
    "/wiki/shared-mailboxes",
    "/wiki/send-as",
    "/wiki/accounts",
    "/answers",
    "/gaps",
    "/sources",
    "/source/network_shares.txt",
    "/ask?q=" + urllib.parse.quote("Why can I read the shared mailbox but not send from it?"),
    "/ask?q=" + urllib.parse.quote("How do I enrol a new iPhone in mobile device management?"),
    "/api/ask?q=" + urllib.parse.quote("How do I map a network drive?"),
    "/wiki/does-not-exist",
]

for route in ROUTES:
    try:
        with urllib.request.urlopen(BASE + route, timeout=20) as r:
            body = r.read()
            print(f"  {r.status}  {len(body):>7,}b  {route[:78]}")
    except urllib.error.HTTPError as e:
        print(f"  {e.code}  {'-':>8}  {route[:78]}")
    except Exception as e:
        print(f"  ERR       -       {route[:78]}  {e}")
