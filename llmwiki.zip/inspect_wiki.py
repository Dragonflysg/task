"""Quick look at what the build produced. Not part of the app.

    py inspect_wiki.py            # concept list
    py inspect_wiki.py <slug>     # dump one page's markdown
"""
import json
import sys

from llmwiki.config import WIKI_FILE

data = json.loads(WIKI_FILE.read_text(encoding="utf-8"))

if len(sys.argv) > 1:
    page = data["pages"].get(sys.argv[1])
    if not page:
        print("No such page. Slugs:")
        for s in sorted(data["pages"]):
            print("  " + s)
        raise SystemExit(1)
    print(f"# {page['title']}   ({page['generated_by']})")
    print(f"  {page['block_count']} passages / {page['file_count']} files\n")
    print(page["body"])
    print("\n--- sources ---")
    for s in page["sources"]:
        print(f"  [{s['n']}] {s['source']}:{s['line']}  {s['title'][:60]}")
    print("\n--- related ---")
    for r in page["related"]:
        print(f"  {r['name']}  ({r['shared']} shared)")
    raise SystemExit(0)

print(f"built {data['built_at']} by {data['generated_by']}")
print(f"{data['stats']}\n")
for c in data["concepts"]:
    home = c["home_source"] or "-"
    print(f"  {c['slug']:34} {len(c['block_ids']):3} blocks   home={home}")
