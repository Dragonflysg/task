"""Exercise the LLM code paths with a stub model, so that switching a real key
on does not fail on first run. Not part of the app.

    py llm_path_test.py
"""
from llmwiki.answer import build_answer
from llmwiki.concepts import attach_blocks, dedupe_slugs, extract_with_llm
from llmwiki.corpus import all_blocks, load_corpus
from llmwiki.llm import LLM
from llmwiki.pages import build_concept_page
from llmwiki.retrieval import BM25Index


class FakeLLM(LLM):
    """Returns plausibly-shaped output for each of the three prompt types."""
    name = "fake"
    available = True
    calls = 0

    def describe(self):
        return "stub model"

    def complete(self, system, user, max_tokens=1200):
        FakeLLM.calls += 1
        if "JSON array" in user:
            return ('Here you go:\n[{"name": "Access Request", '
                    '"aliases": ["access requests"]}, '
                    '{"name": "Data Owner", "aliases": ["data owners"]}]')
        if user.startswith("Write the wiki page"):
            name = user.split("concept:", 1)[1].splitlines()[0].strip()
            return (f"{name} is a thing this corpus documents [1]. It has rules [2].\n\n"
                    f"### In detail\n\nMore about {name} [1].\n\n"
                    f"### Common questions\n\n**Does it work?**\n\nYes [2].")
        return ("Short direct answer to the question [1].\n\n"
                "### In practice\n\n- A concrete step [2]\n- Another [1]")


llm = FakeLLM()
docs = load_corpus()
blocks = all_blocks(docs)
index = BM25Index(blocks)

concepts = extract_with_llm(docs, blocks, llm)
dedupe_slugs(concepts)
attach_blocks(concepts, blocks)
concepts = [c for c in concepts if c.block_ids]
mined = [c.name for c in concepts if not c.home_source]
print(f"  concepts via model : {len(concepts)}  (mined: {mined})")

blocks_by_id = {b.id: b for b in blocks}
page = build_concept_page(concepts[0], blocks_by_id, index, concepts, llm)
print(f"  page               : {page['title']!r} by {page['generated_by']}, "
      f"{len(page['sources'])} sources, {len(page['related'])} related")
assert page["generated_by"] == "stub model", "page should have come from the model"

ans = build_answer("How do I map a network drive?", index,
                   [c.to_dict() for c in concepts], llm)
print(f"  answer             : {ans['kind']}, {ans['confidence']}, "
      f"by {ans['generated_by']}, coverage {ans['coverage']}")
assert ans["generated_by"] == "stub model"

# A model outage must degrade to extraction, not to an error page.
class BrokenLLM(FakeLLM):
    def complete(self, system, user, max_tokens=1200):
        return None

fallback = build_answer("How do I map a network drive?", index,
                        [c.to_dict() for c in concepts], BrokenLLM())
print(f"  model returns None : falls back to {fallback['generated_by']!r}")
assert fallback["generated_by"] == "extractive" and fallback["body"]

print(f"\n  {FakeLLM.calls} model calls made. All LLM paths OK.")
