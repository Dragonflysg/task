/* dependencies.js — Dependencies view for dependencies.html
 *
 * Two views (Flow diagram, Directory cards) share ONE computed model. The
 * model answers, for every top-level task:
 *   - what top-level tasks it WAITS ON  (its dependencies / "up")
 *   - what top-level tasks WAIT ON IT   (its dependents  / "down")
 *   - whether it STANDS ALONE           (no links either way)
 *
 * An edge A -> B ("A waits on B") exists when any task anywhere in A's subtree
 * lists, as a predecessor, any task anywhere in B's subtree. The edge WEIGHT
 * is the count of such crossing predecessor links — that's the line thickness.
 *
 * Data load mirrors timeline.js (/api/load-group). For offline preview a page
 * may pre-seed window.RELATIONSHIP_DATA = {project, tasks}; when present it is
 * used verbatim and no request is made.
 */
$(document).ready(function () {

    var DEFAULT_PROJECT = 'INTL_to_ITServices_Execution';

    // ---------- scope ----------
    function resolveScope() {
        var params = new URLSearchParams(window.location.search);
        var project = params.get('project');
        if (project) return { project: project };
        try {
            var raw = sessionStorage.getItem('relationships') || sessionStorage.getItem('timeline');
            if (raw) {
                var obj = JSON.parse(raw);
                if (obj && obj.project) return { project: obj.project };
            }
        } catch (e) { /* malformed — fall through */ }
        return { project: DEFAULT_PROJECT };
    }
    function displayName(name) { return String(name).replace(/_/g, ' '); }

    // ---------- helpers ----------
    function esc(s) {
        return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    }
    function escAttr(s) { return esc(s).replace(/"/g, '&quot;'); }
    function clamp(s, n) { s = String(s); return s.length > n ? s.slice(0, n - 1) + '…' : s; }
    var SVGNS = 'http://www.w3.org/2000/svg';
    function svg(tag, attrs) {
        var el = document.createElementNS(SVGNS, tag);
        if (attrs) for (var k in attrs) el.setAttribute(k, attrs[k]);
        return el;
    }

    // ---------- model ----------
    // Walk the whole tree; map every task id to the id of its top-level root.
    function buildModel(tasks) {
        var rootOf = {}, topById = {};
        (function walk(list, root) {
            for (var i = 0; i < list.length; i++) {
                var t = list[i];
                var r = root == null ? String(t.id) : root;
                rootOf[String(t.id)] = r;
                if (root == null) topById[String(t.id)] = t;
                walk(t.subtasks || [], r);
            }
        })(tasks, null);

        // accumulate crossing predecessor links into a weighted edge map
        var wmap = {};                 // "src|dst" -> weight
        var missing = 0;
        (function walk(list) {
            for (var i = 0; i < list.length; i++) {
                var t = list[i];
                var preds = t.predecessor || [];
                for (var j = 0; j < preds.length; j++) {
                    var dstRoot = rootOf[String(preds[j])];
                    if (dstRoot === undefined) { missing++; continue; }
                    var srcRoot = rootOf[String(t.id)];
                    if (!srcRoot || srcRoot === dstRoot) continue;   // internal link
                    var key = srcRoot + '|' + dstRoot;
                    wmap[key] = (wmap[key] || 0) + 1;
                }
                walk(t.subtasks || [], null);
            }
        })(tasks);

        var nodes = {};
        Object.keys(topById).forEach(function (id) {
            nodes[id] = { id: id, name: topById[id].name || ('task ' + id),
                          deps: [], dependents: [], out: 0, inw: 0 };
        });
        var edges = [], maxWeight = 0;
        Object.keys(wmap).forEach(function (key) {
            var p = key.split('|'), src = p[0], dst = p[1], w = wmap[key];
            if (!nodes[src] || !nodes[dst]) return;
            edges.push({ from: src, to: dst, weight: w });
            nodes[src].deps.push({ id: dst, weight: w });
            nodes[dst].dependents.push({ id: src, weight: w });
            nodes[src].out += w; nodes[dst].inw += w;
            if (w > maxWeight) maxWeight = w;
        });

        var list = Object.keys(nodes).map(function (id) { return nodes[id]; });
        var maxLinks = 0;
        list.forEach(function (n) {
            n.links = n.out + n.inw;
            n.degree = n.deps.length + n.dependents.length;
            n.iso = n.degree === 0;
            n.deps.sort(function (a, b) { return b.weight - a.weight; });
            n.dependents.sort(function (a, b) { return b.weight - a.weight; });
            if (n.links > maxLinks) maxLinks = n.links;
        });
        var isolated = list.filter(function (n) { return n.iso; });
        var connected = list.filter(function (n) { return !n.iso; });

        return {
            nodes: nodes, list: list, connected: connected, isolated: isolated,
            edges: edges, maxWeight: maxWeight || 1, maxLinks: maxLinks || 1,
            missing: missing
        };
    }

    // ---------- scales ----------
    function strokeFor(w, M) { return 1.3 + Math.sqrt(w / M.maxWeight) * 7.2; }
    function roleClass(n) {
        if (n.iso) return 'role-iso';
        if (n.inw > n.out) return 'role-sink';       // depended-on heavy = bottleneck (blue)
        if (n.out > n.inw) return 'role-source';      // waits-on heavy (amber)
        return 'role-mixed';
    }

    // ---------- neighbours (for focus) ----------
    function neighborIds(M, id) {
        var set = {}; set[id] = true;
        var n = M.nodes[id];
        if (n) {
            n.deps.forEach(function (d) { set[d.id] = true; });
            n.dependents.forEach(function (d) { set[d.id] = true; });
        }
        return set;
    }

    // ========================================================================
    //  SHARED CHROME: tooltip, rail, focus, click-through
    // ========================================================================
    var stage = document.getElementById('dp-stage');
    var $tip = $('#dp-tip');
    var MODEL = null, currentDesign = 1, PROJECT = '';

    function edgeTip(e) {
        return '<span class="t">' + esc(MODEL.nodes[e.from].name) + '</span>' +
               '<span class="m">waits on ' + esc(MODEL.nodes[e.to].name) + '</span>' +
               '<span class="m">' + e.weight + ' predecessor link' + (e.weight === 1 ? '' : 's') + '</span>';
    }
    function showTip(html, x, y) {
        $tip.html(html).prop('hidden', false);
        var w = $tip.outerWidth(), h = $tip.outerHeight();
        var left = Math.min(x + 14, window.innerWidth - w - 12);
        var top = y + 16;
        if (top + h > window.innerHeight - 12) top = Math.max(12, y - 16 - h);
        $tip.css({ left: left + 'px', top: top + 'px' });
    }
    function hideTip() { $tip.prop('hidden', true); }
    $(document).on('mousemove', '#dp-stage [data-tip]', function (e) {
        showTip($(this).attr('data-tip'), e.clientX, e.clientY);
    });
    $(document).on('mouseleave', '#dp-stage [data-tip]', hideTip);

    // ----- detail rail -----
    function railNodeLine(entry, dir) {
        var n = MODEL.nodes[entry.id];
        return '<li data-goto="' + escAttr(entry.id) + '"><span class="nm">' + esc(n.name) +
               '</span><span class="wt">' + entry.weight + '</span></li>';
    }
    function showRail(id) {
        var n = MODEL.nodes[id];
        if (!n) return;
        $('#dp-rail-empty').prop('hidden', true);
        $('#dp-rail-card').prop('hidden', false);

        var $tag = $('#dp-rail-tag').removeClass('is-bottleneck is-iso');
        if (n.iso) { $tag.text('stands alone').addClass('is-iso'); }
        else if (n.dependents.length >= 6 && n.dependents.length >= n.deps.length) {
            $tag.text('bottleneck · ' + n.dependents.length + ' waiting').addClass('is-bottleneck');
        } else if (n.deps.length && !n.dependents.length) { $tag.text('leaf · waits only'); }
        else if (n.dependents.length && !n.deps.length) { $tag.text('root · blocks others'); }
        else { $tag.text('linked'); }

        $('#dp-rail-name').text(n.name);
        $('#dp-rail-open').attr('href', 'timeline.html?project=' + encodeURIComponent(PROJECT) +
                                        '&taskId=' + encodeURIComponent(id));

        $('#dp-up-count').text(n.deps.length);
        $('#dp-down-count').text(n.dependents.length);
        var up = n.deps.map(function (d) { return railNodeLine(d, 'up'); }).join('');
        var down = n.dependents.map(function (d) { return railNodeLine(d, 'down'); }).join('');
        $('#dp-up-list').html(up); $('#dp-up-none').prop('hidden', n.deps.length > 0);
        $('#dp-down-list').html(down); $('#dp-down-none').prop('hidden', n.dependents.length > 0);
    }
    $(document).on('click', '#dp-rail [data-goto]', function () {
        var id = $(this).attr('data-goto');
        showRail(id); focusNode(id);
    });

    // ----- focus (dim all but the hovered ego-network) — SVG designs -----
    function focusNode(id) {
        if (!stage) return;
        stage.classList.add('is-focusing');
        var hot = neighborIds(MODEL, id);
        stage.querySelectorAll('[data-node]').forEach(function (el) {
            el.classList.toggle('is-hot', !!hot[el.getAttribute('data-node')]);
        });
        stage.querySelectorAll('[data-edge]').forEach(function (el) {
            var f = el.getAttribute('data-from'), t = el.getAttribute('data-to');
            var on = (f === id || t === id);
            el.classList.toggle('is-hot', on);
            el.classList.toggle('is-up', on && f === id);     // hovered waits on -> amber
            el.classList.toggle('is-down', on && t === id);   // waits on hovered -> blue
        });
    }
    function clearFocus() {
        if (!stage) return;
        stage.classList.remove('is-focusing');
        stage.querySelectorAll('.is-hot').forEach(function (el) { el.classList.remove('is-hot', 'is-up', 'is-down'); });
    }
    function clickThrough(id) {
        window.open('timeline.html?project=' + encodeURIComponent(PROJECT) +
                    '&taskId=' + encodeURIComponent(id), '_blank', 'noopener');
    }

    // Generic SVG node interaction wiring (designs that use data-node groups)
    function wireNodes() {
        stage.querySelectorAll('[data-node]').forEach(function (el) {
            var id = el.getAttribute('data-node');
            el.addEventListener('mouseenter', function () { showRail(id); focusNode(id); });
            el.addEventListener('click', function () { clickThrough(id); });
        });
        stage.addEventListener('mouseleave', clearFocus);
    }

    // ========================================================================
    //  FLOW COLUMNS (layered ribbons)
    // ========================================================================
    function designFlow(M) {
        var layers = layerOrder(M);         // array of arrays, left(prereq) -> right(dependent)
        var box = stage.getBoundingClientRect();
        var W = Math.max(box.width, layers.length * 210 + 80, 640);
        var H = Math.max(box.height, 520);
        var padX = 60, padY = 46;
        var colGap = (W - padX * 2) / Math.max(layers.length - 1, 1);
        var pos = {}, barW = 15;

        layers.forEach(function (col, ci) {
            var x = padX + colGap * ci;
            var n = col.length;
            var slot = (H - padY * 2 - (M.isolated.length ? 60 : 0)) / Math.max(n, 1);
            col.forEach(function (node, ri) {
                var h = 16 + Math.sqrt(node.links / M.maxLinks) * 46;
                var y = padY + slot * ri + slot / 2;
                pos[node.id] = { x: x, y: y, h: h };
            });
        });

        var el = svg('svg', { viewBox: '0 0 ' + W + ' ' + H, width: W, height: H });
        el.appendChild(arrowDefs());

        // ribbons drawn from dependent (e.from) to dependency (e.to) so the
        // arrowhead always lands on the dependency — consistent with the other
        // designs. The left->right "flow" reading comes from the column layers,
        // not the arrow direction.
        var gE = svg('g', {});
        M.edges.forEach(function (e) {
            var A = pos[e.from], B = pos[e.to];          // A waits on B
            if (!A || !B) return;
            var dir = B.x >= A.x ? 1 : -1;
            var x1 = A.x + dir * barW / 2, y1 = A.y;
            var x2 = B.x - dir * (barW / 2 + 6), y2 = B.y;   // gap for the arrowhead
            var mx = (x1 + x2) / 2;
            var p = svg('path', {
                'class': 'dp-edge dp-arrowed', 'data-edge': '1', 'data-from': e.from, 'data-to': e.to,
                d: 'M' + x1 + ',' + y1 + ' C' + mx + ',' + y1 + ' ' + mx + ',' + y2 + ' ' + x2 + ',' + y2,
                fill: 'none', 'stroke-width': strokeFor(e.weight, M), 'stroke-linecap': 'round',
                'data-tip': edgeTip(e)
            });
            gE.appendChild(p);
        });
        el.appendChild(gE);

        // column captions
        layers.forEach(function (col, ci) {
            if (!col.length) return;
            var x = padX + colGap * ci;
            var cap = svg('text', { 'class': 'dp-flowcap', x: x, y: 22, 'text-anchor': 'middle' });
            cap.textContent = ci === 0 ? 'starts first' : (ci === layers.length - 1 ? 'starts last' : 'stage ' + (ci + 1));
            el.appendChild(cap);
        });

        // node bars
        M.connected.forEach(function (n) {
            var p = pos[n.id]; if (!p) return;
            // no data-tip on nodes — hovering drives the detail rail instead
            var g = svg('g', { 'class': 'dp-flownode ' + roleClass(n), 'data-node': n.id });
            g.appendChild(svg('rect', { 'class': 'dp-nodedot', x: p.x - barW / 2, y: p.y - p.h / 2,
                                        width: barW, height: p.h, rx: 4 }));
            var t = svg('text', { 'class': 'dp-nodelabel', x: p.x, y: p.y - p.h / 2 - 6, 'text-anchor': 'middle' });
            t.textContent = clamp(n.name, 18);
            g.appendChild(t);
            el.appendChild(g);
        });

        if (M.isolated.length) {
            var y0 = H - 26;
            var cap2 = svg('text', { 'class': 'dp-isocap', x: padX, y: y0 - 20 });
            cap2.textContent = 'stands alone';
            el.appendChild(cap2);
            var step = Math.min((W - padX * 2) / M.isolated.length, 190);
            M.isolated.forEach(function (n, i) {
                var x = padX + step * i + 10;
                var g = svg('g', { 'class': 'dp-flownode role-iso', 'data-node': n.id });
                g.appendChild(svg('rect', { 'class': 'dp-nodedot', x: x - 6, y: y0 - 8, width: 12, height: 16, rx: 3 }));
                var t = svg('text', { 'class': 'dp-nodelabel', x: x + 12, y: y0 + 4, 'text-anchor': 'start' });
                t.textContent = clamp(n.name, 18);
                g.appendChild(t);
                el.appendChild(g);
            });
        }

        stage.appendChild(el);
        wireNodes();
    }

    // ========================================================================
    //  DIRECTORY CARDS
    // ========================================================================
    function designDirectory(M) {
        var order = M.list.slice().sort(function (a, b) {
            if (a.iso !== b.iso) return a.iso ? 1 : -1;
            return (b.dependents.length - a.dependents.length) ||
                   (b.links - a.links) || a.name.localeCompare(b.name);
        });
        var wrap = document.createElement('div');
        wrap.className = 'dp-cards';
        var html = '';
        order.forEach(function (n) {
            var rank = '', rankCls = '';
            if (n.iso) { rank = 'stands alone'; rankCls = ' is-iso'; }
            else if (n.dependents.length >= 6 && n.dependents.length >= n.deps.length) {
                rank = 'bottleneck'; rankCls = ' is-bottleneck';
            } else if (n.dependents.length && !n.deps.length) { rank = 'blocks others'; }
            else if (n.deps.length && !n.dependents.length) { rank = 'waits only'; }
            else { rank = 'linked'; }

            var cardCls = 'dp-card' + (n.iso ? ' is-iso' : (n.dependents.length ? ' has-down' : ''));
            html += '<div class="' + cardCls + '" data-goto2="' + escAttr(n.id) + '">';
            html += '<div class="dp-card-head"><h3>' + esc(n.name) + '</h3>' +
                    '<span class="dp-card-rank' + rankCls + '">' + rank + '</span></div>';

            html += '<div class="dp-card-row"><h4><span class="dp-dot dp-dot-up"></span> waits on ' +
                    n.deps.length + '</h4>';
            if (n.deps.length) {
                html += '<div class="dp-chips">' + n.deps.map(function (d) {
                    return '<span class="dp-chip dp-chip-up"><span class="nm">' + esc(MODEL.nodes[d.id].name) +
                           '</span><span class="wt">' + d.weight + '</span></span>';
                }).join('') + '</div>';
            } else { html += '<span class="dp-card-none">nothing</span>'; }
            html += '</div>';

            html += '<div class="dp-card-row"><h4><span class="dp-dot dp-dot-down"></span> depended on by ' +
                    n.dependents.length + '</h4>';
            if (n.dependents.length) {
                html += '<div class="dp-chips">' + n.dependents.map(function (d) {
                    return '<span class="dp-chip dp-chip-down"><span class="nm">' + esc(MODEL.nodes[d.id].name) +
                           '</span><span class="wt">' + d.weight + '</span></span>';
                }).join('') + '</div>';
            } else { html += '<span class="dp-card-none">nothing</span>'; }
            html += '</div></div>';
        });
        wrap.innerHTML = html;
        stage.appendChild(wrap);

        wrap.querySelectorAll('[data-goto2]').forEach(function (card) {
            var id = card.getAttribute('data-goto2');
            card.addEventListener('mouseenter', function () { showRail(id); });
            card.addEventListener('click', function () { clickThrough(id); });
        });
    }

    // ---------- layering (longest dependency chain) — used by Flow ----------
    // layer(X) = 0 if X waits on nothing, else 1 + max(layer over its deps).
    // Cycle-guarded. Isolated nodes are excluded (they get their own tray).
    function layerOrder(M) {
        var memo = {}, stack = {};
        function depth(id) {
            if (memo[id] !== undefined) return memo[id];
            if (stack[id]) return 0;             // cycle: treat as base
            stack[id] = true;
            var n = M.nodes[id], d = 0;
            n.deps.forEach(function (e) { d = Math.max(d, depth(e.id) + 1); });
            stack[id] = false;
            return (memo[id] = d);
        }
        var maxD = 0;
        M.connected.forEach(function (n) { maxD = Math.max(maxD, depth(n.id)); });
        var cols = [];
        for (var i = 0; i <= maxD; i++) cols.push([]);
        M.connected.forEach(function (n) { cols[depth(n.id)].push(n); });
        cols.forEach(function (c) {
            c.sort(function (a, b) { return (b.links - a.links) || a.name.localeCompare(b.name); });
        });
        return cols.filter(function (c) { return c.length; });
    }

    // ---------- arrow markers ----------
    function arrowDefs() {
        var defs = svg('defs', {});
        [['arrow-neutral', 'var(--edge)'], ['arrow-up', 'var(--up)'], ['arrow-down', 'var(--down)']].forEach(function (m) {
            var mk = svg('marker', { id: m[0], markerWidth: 9, markerHeight: 9, refX: 7, refY: 4,
                orient: 'auto', markerUnits: 'userSpaceOnUse' });
            var p = svg('path', { d: 'M0,0 L8,4 L0,8 z', fill: m[1] });
            mk.appendChild(p); defs.appendChild(mk);
        });
        return defs;
    }

    // ========================================================================
    //  SWITCHER + RENDER
    // ========================================================================
    var RENDERERS = { 1: designFlow, 2: designDirectory };

    function renderDesign(d) {
        if (!MODEL) return;
        currentDesign = d;
        clearFocus();
        stage.className = 'dp-stage';
        stage.innerHTML = '';
        $('#dp-rail-empty').prop('hidden', false);
        $('#dp-rail-card').prop('hidden', true);
        try { RENDERERS[d](MODEL); }
        catch (err) {
            stage.innerHTML = '<div class="dp-loading">This sample could not be drawn.</div>';
            if (window.console) console.error('[dependencies] design ' + d + ' failed', err);
        }
    }

    $('.dp-seg').on('click', function () {
        $('.dp-seg').attr('aria-selected', 'false');
        $(this).attr('aria-selected', 'true');
        renderDesign(Number($(this).data('design')));
    });
    $(window).on('resize', function () {
        // Flow (1) is an SVG that must be re-laid out; Directory (2) is a CSS
        // grid that reflows on its own.
        if (MODEL && RENDERERS[currentDesign] && currentDesign !== 2) {
            clearTimeout(window.__dpRz);
            window.__dpRz = setTimeout(function () { renderDesign(currentDesign); }, 180);
        }
    });

    // ========================================================================
    //  BOOT
    // ========================================================================
    function boot(project, tasks) {
        PROJECT = project;
        document.title = displayName(project) + ' · Dependencies';
        $('#dp-project-name').text(displayName(project));
        $('#dp-timeline-link').attr('href', 'timeline.html?project=' + encodeURIComponent(project));
        MODEL = buildModel(tasks || []);

        $('#dp-loading').hide();
        $('#dp-legend').prop('hidden', false);
        var iso = MODEL.isolated.length;
        $('#dp-stats').text(MODEL.connected.length + ' linked · ' + iso + ' alone · ' +
                            MODEL.edges.length + ' relationship' + (MODEL.edges.length === 1 ? '' : 's'));
        stage.hidden = false;
        renderDesign(1);
    }

    function load() {
        var scope = resolveScope();
        if (window.RELATIONSHIP_DATA && window.RELATIONSHIP_DATA.tasks) {
            boot(window.RELATIONSHIP_DATA.project || scope.project, window.RELATIONSHIP_DATA.tasks);
            return;
        }
        $('#dp-loading').show();
        $('#dp-error').prop('hidden', true);
        stage.hidden = true;
        $.ajax({
            url: '/api/load-group', method: 'GET', data: { project: scope.project },
            dataType: 'json', timeout: 10000,
            success: function (resp) {
                if (!(resp && resp.ok && resp.data && resp.data._taskData)) {
                    return showError('The project "' + displayName(scope.project) + '" could not be loaded from the server.');
                }
                boot(scope.project, resp.data._taskData.tasks || []);
            },
            error: function () {
                showError('The project "' + displayName(scope.project) + '" could not be loaded. Check that the server is running.');
            }
        });
    }
    function showError(msg) {
        $('#dp-loading').hide();
        $('#dp-error-msg').text(msg);
        $('#dp-error').prop('hidden', false);
    }
    $('#dp-retry').on('click', load);

    load();
});
