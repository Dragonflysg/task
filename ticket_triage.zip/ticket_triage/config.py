"""Configuration for the ticket triage classifier.

All tunables live here so the service desk workflow can be adjusted
without touching classifier logic.
"""

import os
from dataclasses import dataclass, field


@dataclass
class Settings:
    # --- Anthropic API ---
    # Haiku is ideal for classification: fast, cheap, and with a good
    # glossary + few-shot examples it matches larger models on this task.
    model: str = "claude-haiku-4-5-20251001"
    max_tokens: int = 500
    api_key: str = field(default_factory=lambda: os.environ.get("ANTHROPIC_API_KEY", ""))

    # --- Self-consistency voting ---
    n_votes: int = 3          # number of parallel classification calls
    vote_temperature: float = 0.7

    # --- Routing thresholds ---
    # Auto-assign only when ALL votes agree AND blended confidence >= this.
    auto_assign_confidence: int = 80
    # Below this (or any disagreement / UNKNOWN), route to human review.

    # --- Prompt building ---
    max_fewshot_examples: int = 25   # recent corrections injected as examples

    # --- MySQL ---
    db_host: str = os.environ.get("TRIAGE_DB_HOST", "127.0.0.1")
    db_port: int = int(os.environ.get("TRIAGE_DB_PORT", "3306"))
    db_user: str = os.environ.get("TRIAGE_DB_USER", "triage")
    db_password: str = os.environ.get("TRIAGE_DB_PASS", "")
    db_name: str = os.environ.get("TRIAGE_DB_NAME", "ticket_triage")


settings = Settings()
