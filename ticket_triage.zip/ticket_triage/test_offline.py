"""Offline tests — run with `python test_offline.py`. No API key or DB needed.

Covers: JSON parsing robustness, voting/decision logic, and prompt building.
"""

import json
from classifier import parse_vote, TicketClassifier, Vote
from prompt_builder import build_system_prompt, build_user_message
from store import FileStore

VALID = {"LOCAL_SUPPORT", "MOBILE_TEAM", "NETWORK_TEAM", "APPS_TEAM",
         "SERVICE_DESK", "UNKNOWN"}


def test_parse_clean_json():
    v = parse_vote(json.dumps({
        "team": "LOCAL_SUPPORT", "confidence": 92,
        "reasoning": "hardware", "unfamiliar_terms": []
    }), VALID)
    assert v.team == "LOCAL_SUPPORT" and v.confidence == 92


def test_parse_markdown_fenced():
    raw = '```json\n{"team": "mobile_team", "confidence": 88, "reasoning": "phone", "unfamiliar_terms": ["XYZ-tag"]}\n```'
    v = parse_vote(raw, VALID)
    assert v.team == "MOBILE_TEAM" and v.unfamiliar_terms == ["XYZ-tag"]


def test_parse_with_preamble_prose():
    raw = 'Here is my classification:\n{"team": "APPS_TEAM", "confidence": 70, "reasoning": "x", "unfamiliar_terms": []}'
    v = parse_vote(raw, VALID)
    assert v.team == "APPS_TEAM"


def test_parse_garbage_falls_back_to_unknown():
    v = parse_vote("I think this goes to the hardware people.", VALID)
    assert v.team == "UNKNOWN" and v.confidence == 0


def test_parse_invalid_team_becomes_unknown():
    v = parse_vote('{"team": "HARDWARE_SQUAD", "confidence": 95, "reasoning": "", "unfamiliar_terms": []}', VALID)
    assert v.team == "UNKNOWN"


def test_parse_confidence_clamped():
    v = parse_vote('{"team": "APPS_TEAM", "confidence": 150, "reasoning": "", "unfamiliar_terms": []}', VALID)
    assert v.confidence == 100


def _votes(*specs):
    return [Vote(team, conf, "", []) for team, conf in specs]


def test_decide_unanimous_high_conf_auto_assigns():
    team, conf, auto = TicketClassifier._decide(
        _votes(("LOCAL_SUPPORT", 95), ("LOCAL_SUPPORT", 90), ("LOCAL_SUPPORT", 92)))
    assert team == "LOCAL_SUPPORT" and auto and conf == 92


def test_decide_majority_capped_and_no_auto():
    team, conf, auto = TicketClassifier._decide(
        _votes(("LOCAL_SUPPORT", 95), ("LOCAL_SUPPORT", 95), ("NETWORK_TEAM", 90)))
    assert team == "LOCAL_SUPPORT" and conf <= 70 and not auto


def test_decide_split_goes_to_human():
    team, conf, auto = TicketClassifier._decide(
        _votes(("LOCAL_SUPPORT", 95), ("NETWORK_TEAM", 95), ("APPS_TEAM", 95)))
    assert team == "UNKNOWN" and not auto


def test_decide_unanimous_but_low_conf_no_auto():
    team, conf, auto = TicketClassifier._decide(
        _votes(("APPS_TEAM", 60), ("APPS_TEAM", 55), ("APPS_TEAM", 65)))
    assert team == "APPS_TEAM" and not auto


def test_decide_unknown_majority():
    team, conf, auto = TicketClassifier._decide(
        _votes(("UNKNOWN", 30), ("UNKNOWN", 20), ("LOCAL_SUPPORT", 80)))
    assert team == "UNKNOWN" and not auto


def test_prompt_builder_includes_everything():
    store = FileStore("sample_data/knowledge.json")
    prompt = build_system_prompt(store.load_teams(), store.load_glossary(),
                                 store.load_examples(25))
    for needle in ("LOCAL_SUPPORT", "EOS request", "slow laptop",
                   "unfamiliar_terms", "UNKNOWN"):
        assert needle in prompt, f"missing: {needle}"
    msg = build_user_message("slow laptop", "fan loud")
    assert "SHORT DESCRIPTION" in msg and "LONG DESCRIPTION" in msg


if __name__ == "__main__":
    passed = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            fn()
            print(f"PASS {name}")
            passed += 1
    print(f"\n{passed} tests passed.")
