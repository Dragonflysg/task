"""Builds the classification system prompt dynamically from the database.

The prompt has four sections:
  1. Team labels + descriptions (the allowed output space)
  2. Company glossary (authoritative term -> team mappings)
  3. Few-shot examples (recent human corrections — the "learning" loop)
  4. Output contract (strict JSON) + safety rules (escape hatch to UNKNOWN)
"""

from __future__ import annotations

from store import Team, GlossaryEntry, Example


def build_system_prompt(teams: list[Team],
                        glossary: list[GlossaryEntry],
                        examples: list[Example]) -> str:
    team_lines = "\n".join(
        f"- {t.code}: {t.description}" for t in teams
    )
    valid_codes = ", ".join(t.code for t in teams) + ", UNKNOWN"

    if glossary:
        gloss_lines = "\n".join(
            f'- "{g.term}" = {g.meaning}'
            + (f" -> route to {g.team_code}" if g.team_code else "")
            for g in glossary
        )
        glossary_block = (
            "Company-specific glossary (authoritative — these mappings ALWAYS "
            f"override your general knowledge):\n{gloss_lines}\n"
        )
    else:
        glossary_block = ""

    if examples:
        ex_lines = []
        for e in examples:
            long_part = f' | Long: "{e.long_desc}"' if e.long_desc else ""
            ex_lines.append(f'Short: "{e.short_desc}"{long_part} -> {e.team_code}')
        examples_block = (
            "Examples of correctly routed past tickets (follow these patterns):\n"
            + "\n".join(ex_lines) + "\n"
        )
    else:
        examples_block = ""

    return f"""You are a ticket classification assistant for an IT service desk.

Classify each ticket into exactly ONE of these teams:
{team_lines}
- UNKNOWN: use this when the ticket does not clearly fit any team, uses \
unfamiliar terminology not covered by the glossary, or you would be guessing.

{glossary_block}
{examples_block}
Rules:
- The user message contains a SHORT description and a LONG description. \
If they conflict, trust the LONG description.
- If you encounter jargon, acronyms, or internal terms NOT in the glossary, \
lower your confidence and list them in unfamiliar_terms. NEVER invent a \
mapping for a term you do not recognize — prefer UNKNOWN.
- confidence is 0-100: 90+ means the routing is obvious; 60-89 means \
plausible but with some ambiguity; below 60 means you are unsure.

Respond ONLY with a single JSON object, no markdown fences, no extra text:
{{
  "team": "<one of: {valid_codes}>",
  "confidence": <integer 0-100>,
  "reasoning": "<one short sentence>",
  "unfamiliar_terms": ["<terms you did not recognize, if any>"]
}}"""


def build_user_message(short_desc: str, long_desc: str) -> str:
    return (
        f"SHORT DESCRIPTION: {short_desc}\n\n"
        f"LONG DESCRIPTION: {long_desc or '(empty)'}"
    )
