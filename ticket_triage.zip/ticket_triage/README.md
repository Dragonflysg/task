# Ticket Triage Classifier

LLM-powered service desk ticket routing with confidence scoring,
self-consistency voting, a maintainable company glossary, and a
human-in-the-loop feedback cycle. No model training required — the system
"learns" through the glossary and corrections tables.

## Files

| File | Purpose |
|---|---|
| `schema.sql` | MySQL tables: teams, glossary, classification_log, corrections, unfamiliar_terms |
| `config.py` | Model choice, voting count, auto-assign threshold, DB creds (env vars) |
| `store.py` | Data access — `MySQLStore` for production, `FileStore` (JSON) for dev/testing |
| `prompt_builder.py` | Assembles the system prompt from teams + glossary + few-shot corrections |
| `classifier.py` | API calls, robust JSON parsing, 3-vote self-consistency, routing decision |
| `evaluate.py` | Accuracy eval against historical tickets (CSV in, metrics + confusion matrix out) |
| `test_offline.py` | 12 unit tests for parsing/voting/prompt logic — no API key or DB needed |
| `sample_data/` | Example knowledge JSON + eval CSV showing expected formats |

## Quick start (no database)

```bash
pip install anthropic
export ANTHROPIC_API_KEY=sk-ant-...

python test_offline.py                      # sanity check, no API calls
python classifier.py "EOS request" ""       # one live classification
python evaluate.py sample_data/eval_sample.csv
```

## Production setup

1. `mysql < schema.sql` — creates tables and seeds example teams/glossary.
   Edit the seed team descriptions to match your real assignment groups —
   **the quality of these descriptions directly drives accuracy.**
2. Set env vars: `TRIAGE_DB_HOST/PORT/USER/PASS/NAME`, `ANTHROPIC_API_KEY`.
3. In your ticket-ingest script:

```python
from store import MySQLStore
from classifier import TicketClassifier

clf = TicketClassifier(MySQLStore())

result = clf.classify(ticket_id, short_desc, long_desc)
if result.auto_assign:
    itsm_assign(ticket_id, result.team)          # your ITSM API call
else:
    itsm_flag_for_review(ticket_id, result.team, result.confidence)
```

Call `clf.refresh_prompt()` on a schedule (e.g. hourly cron) so glossary
edits and new corrections take effect without a restart.

## How the confidence score actually works

Self-reported LLM confidence is directionally useful but not calibrated,
so the final score blends two signals:

1. **Self-report** — the model outputs 0–100 per call.
2. **Vote agreement** — the ticket is classified 3× at temperature 0.7:
   - 3/3 agree → use average self-reported confidence
   - 2/3 agree → confidence capped at 70, never auto-assigned
   - split / majority-UNKNOWN → routed to human review

Auto-assignment requires **unanimous votes AND confidence ≥ 80**
(tune in `config.py`). Everything else goes to a human, whose decision
should be written to `corrections` — which then feeds the prompt.

## The feedback loop (this replaces "training")

```
new ticket ──▶ classify ──▶ high confidence ──▶ auto-assign
                   │
                   └──▶ low confidence ──▶ human decides
                                              │
                                              ▼
                                     corrections table ──▶ few-shot examples
                                                             in next prompt

unfamiliar_terms table ──▶ weekly review ──▶ glossary table ──▶ next prompt
```

Weekly maintenance query — terms the model flagged most often:

```sql
SELECT term, seen_count FROM unfamiliar_terms
WHERE reviewed = 0 ORDER BY seen_count DESC LIMIT 20;
```

## Building the eval set from your ITSM data

Misrouted tickets get reassigned, so the *final* assignment group is free
ground truth. Rough shape (adapt to your schema):

```sql
SELECT ticket_id, short_description AS short_desc,
       long_description AS long_desc,
       final_assignment_group AS correct_team
FROM tickets
WHERE state = 'Closed'
  AND created_at >= NOW() - INTERVAL 6 MONTH
ORDER BY RAND() LIMIT 300;
```

Export to CSV (map assignment group names to your team codes), then:

```bash
python evaluate.py historical_tickets.csv --mysql
```

Watch two numbers: **auto-assign accuracy** (should be well above 95%
before you let it route tickets unattended) and **coverage** (what % of
tickets clear the bar — 60–80% is a realistic, valuable target; the rest
go to humans, which is fine).

## Rollout recommendation

1. **Week 0:** run `evaluate.py` on 200–300 historical tickets; tune team
   descriptions and glossary until auto-assign accuracy is solid.
2. **Weeks 1–3 (shadow mode):** classify live tickets but only *suggest* —
   the agent accepts or overrides. Log everything.
3. **Go-live:** enable auto-assign only for teams whose measured precision
   is high; keep the rest suggestion-only.

## Cost note

Haiku + ~1.5k-token prompt × 3 votes ≈ fractions of a cent per ticket.
Even at hundreds of tickets/day this is negligible. If you later want to
cut it 3×, drop `n_votes` to 1 for tickets whose short description exactly
matches a glossary term with an authoritative team mapping.
