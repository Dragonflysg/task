-- =====================================================================
-- Ticket Triage Classifier — MySQL schema
-- Service desk maintains `teams` and `glossary`; the app writes to
-- `classification_log`; humans write to `corrections` (the feedback loop).
-- =====================================================================

CREATE TABLE IF NOT EXISTS teams (
    team_code       VARCHAR(40)  PRIMARY KEY,          -- e.g. 'LOCAL_SUPPORT'
    display_name    VARCHAR(100) NOT NULL,             -- e.g. 'Local Support Team'
    description     TEXT NOT NULL,                     -- shown to the LLM; be specific
    is_active       TINYINT(1)   NOT NULL DEFAULT 1,
    updated_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS glossary (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    term            VARCHAR(120) NOT NULL,             -- e.g. 'EOS request'
    meaning         VARCHAR(500) NOT NULL,             -- e.g. 'End-Of-Support hardware replacement'
    team_code       VARCHAR(40)  NULL,                 -- authoritative routing, if any
    is_active       TINYINT(1)   NOT NULL DEFAULT 1,
    added_by        VARCHAR(80),
    updated_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_term (term),
    CONSTRAINT fk_glossary_team FOREIGN KEY (team_code) REFERENCES teams(team_code)
);

-- Every classification the system makes, whether auto-assigned or not.
CREATE TABLE IF NOT EXISTS classification_log (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    ticket_id       VARCHAR(60)  NOT NULL,
    short_desc      VARCHAR(500) NOT NULL,
    long_desc       TEXT,
    predicted_team  VARCHAR(40)  NOT NULL,             -- may be 'UNKNOWN'
    confidence      TINYINT UNSIGNED NOT NULL,         -- 0-100 (post-voting)
    vote_detail     JSON,                              -- per-call votes, reasoning, unfamiliar terms
    auto_assigned   TINYINT(1)   NOT NULL,             -- 1 = routed automatically, 0 = sent to human
    model_used      VARCHAR(60),
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    KEY idx_ticket (ticket_id)
);

-- Human decisions on tickets the system got wrong or flagged.
-- These rows become few-shot examples on the next prompt build.
CREATE TABLE IF NOT EXISTS corrections (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    ticket_id       VARCHAR(60)  NOT NULL,
    short_desc      VARCHAR(500) NOT NULL,
    long_desc       TEXT,
    correct_team    VARCHAR(40)  NOT NULL,
    corrected_by    VARCHAR(80),
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_corr_team FOREIGN KEY (correct_team) REFERENCES teams(team_code)
);

-- Terms the LLM reported as unfamiliar; weekly review feeds the glossary.
CREATE TABLE IF NOT EXISTS unfamiliar_terms (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    term            VARCHAR(200) NOT NULL,
    ticket_id       VARCHAR(60),
    seen_count      INT NOT NULL DEFAULT 1,
    reviewed        TINYINT(1) NOT NULL DEFAULT 0,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_unfamiliar (term)
);

-- ---------------------------------------------------------------------
-- Seed data (edit to match your org)
-- ---------------------------------------------------------------------
INSERT INTO teams (team_code, display_name, description) VALUES
('SERVICE_DESK',  'Service Desk (First Responder)',
 'Password resets, account unlocks, AD/Exchange account requests, general how-to questions, anything resolvable at first contact.'),
('LOCAL_SUPPORT', 'Local Support Team',
 'Physical hardware: laptops, desktops, monitors, docking stations, keyboards, printers at desk, hardware replacement, EOS replacements.'),
('MOBILE_TEAM',   'Mobile Team',
 'Handphones, tablets, SIM cards, mobile device enrollment (MDM/Intune), mobile app issues on phones.'),
('NETWORK_TEAM',  'Network Team',
 'VPN, WiFi, LAN ports, network drives unreachable due to connectivity, firewall requests.'),
('APPS_TEAM',     'Applications Team',
 'Business application errors, website login failures, application access requests, SharePoint issues.')
ON DUPLICATE KEY UPDATE display_name = VALUES(display_name);

INSERT INTO glossary (term, meaning, team_code) VALUES
('EOS request', 'End-Of-Support hardware replacement request for aging laptops/desktops', 'LOCAL_SUPPORT')
ON DUPLICATE KEY UPDATE meaning = VALUES(meaning);
