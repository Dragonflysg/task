"""Accuracy evaluation against historical tickets.

Input: a CSV with columns  ticket_id, short_desc, long_desc, correct_team
(pull this from your ITSM MySQL — the FINAL resolved assignment group is
your ground truth, since misrouted tickets get reassigned).

Outputs:
  - overall accuracy, and accuracy on auto-assigned tickets only
  - coverage (what % the system was confident enough to auto-assign)
  - per-team precision/recall
  - confusion matrix (where the mistakes go)
  - eval_results.csv with every prediction for manual inspection

Usage:
    export ANTHROPIC_API_KEY=sk-ant-...
    python evaluate.py historical_tickets.csv            # uses FileStore sample data
    python evaluate.py historical_tickets.csv --mysql    # uses MySQL store
"""

from __future__ import annotations

import csv
import sys
import time
from collections import Counter, defaultdict

from classifier import TicketClassifier
from store import FileStore, MySQLStore


def load_eval_set(path: str) -> list[dict]:
    with open(path, newline="", encoding="utf-8-sig") as f:
        rows = list(csv.DictReader(f))
    required = {"ticket_id", "short_desc", "long_desc", "correct_team"}
    if rows and not required.issubset(rows[0].keys()):
        sys.exit(f"CSV must have columns: {', '.join(sorted(required))}")
    return rows


def main() -> None:
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    eval_path = sys.argv[1]
    use_mysql = "--mysql" in sys.argv

    store = MySQLStore() if use_mysql else FileStore("sample_data/knowledge.json")
    clf = TicketClassifier(store)
    rows = load_eval_set(eval_path)
    from config import settings
    print(f"Evaluating {len(rows)} tickets with model {settings.model} "
          f"({settings.n_votes} votes each)...\n")

    results = []
    for i, row in enumerate(rows, 1):
        r = clf.classify(row["ticket_id"], row["short_desc"], row.get("long_desc", ""))
        results.append({
            "ticket_id": row["ticket_id"],
            "short_desc": row["short_desc"],
            "correct_team": row["correct_team"].strip().upper(),
            "predicted_team": r.team,
            "confidence": r.confidence,
            "auto_assign": r.auto_assign,
            "unfamiliar_terms": "; ".join(r.unfamiliar_terms),
        })
        if i % 10 == 0:
            print(f"  ... {i}/{len(rows)}")
        time.sleep(0.2)  # gentle pacing; remove if your rate limits allow

    # ------------------------------------------------------------------ metrics
    total = len(results)
    correct = sum(1 for r in results if r["predicted_team"] == r["correct_team"])

    auto = [r for r in results if r["auto_assign"]]
    auto_correct = sum(1 for r in auto if r["predicted_team"] == r["correct_team"])

    print("\n================ RESULTS ================")
    print(f"Overall accuracy:        {correct}/{total} = {correct/total:.1%}")
    if auto:
        print(f"Auto-assign coverage:    {len(auto)}/{total} = {len(auto)/total:.1%}")
        print(f"Auto-assign accuracy:    {auto_correct}/{len(auto)} = {auto_correct/len(auto):.1%}"
              "   <-- this is the number that matters for go-live")
    else:
        print("Auto-assign coverage:    0 tickets met the auto-assign bar")

    # per-team precision / recall
    print("\nPer-team (precision = of tickets we sent there, how many belonged;"
          " recall = of tickets that belonged there, how many we caught):")
    teams = sorted({r["correct_team"] for r in results} |
                   {r["predicted_team"] for r in results})
    for t in teams:
        tp = sum(1 for r in results if r["predicted_team"] == t and r["correct_team"] == t)
        fp = sum(1 for r in results if r["predicted_team"] == t and r["correct_team"] != t)
        fn = sum(1 for r in results if r["predicted_team"] != t and r["correct_team"] == t)
        prec = tp / (tp + fp) if tp + fp else 0.0
        rec = tp / (tp + fn) if tp + fn else 0.0
        print(f"  {t:<16} precision {prec:6.1%}   recall {rec:6.1%}   (n={tp+fn})")

    # confusion matrix — only the mistakes, most frequent first
    confusion = Counter(
        (r["correct_team"], r["predicted_team"])
        for r in results if r["correct_team"] != r["predicted_team"]
    )
    if confusion:
        print("\nTop confusions (actual -> predicted):")
        for (actual, pred), n in confusion.most_common(10):
            print(f"  {actual} -> {pred}: {n}")

    # unfamiliar terms surfaced during the run — glossary candidates
    term_counts = Counter()
    for r in results:
        for t in filter(None, r["unfamiliar_terms"].split("; ")):
            term_counts[t] += 1
    if term_counts:
        print("\nUnfamiliar terms encountered (glossary candidates):")
        for term, n in term_counts.most_common(15):
            print(f"  {term} (x{n})")

    out = "eval_results.csv"
    with open(out, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(results[0].keys()))
        w.writeheader()
        w.writerows(results)
    print(f"\nFull per-ticket results written to {out}")


if __name__ == "__main__":
    main()
