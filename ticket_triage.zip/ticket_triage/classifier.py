"""Ticket classifier with self-consistency voting.

Flow per ticket:
  1. Build the system prompt from DB (teams + glossary + few-shot corrections).
  2. Call the model N times at temperature ~0.7 ("self-consistency").
  3. Majority-vote the team label; blend confidence with vote agreement.
  4. Decide: auto-assign vs. human review.
  5. Log everything (including unfamiliar terms) for the feedback loop.

Confidence model:
  - Each call self-reports 0-100 (useful but not calibrated).
  - Vote agreement is the stronger signal: 3/3 agreement -> trust it,
    2/3 -> cap confidence, split or any UNKNOWN in majority -> human review.
"""

from __future__ import annotations

import json
import re
from concurrent.futures import ThreadPoolExecutor
from collections import Counter
from dataclasses import dataclass, asdict

import anthropic

from config import settings
from prompt_builder import build_system_prompt, build_user_message


@dataclass
class Vote:
    team: str
    confidence: int
    reasoning: str
    unfamiliar_terms: list


@dataclass
class Classification:
    ticket_id: str
    team: str                 # final decision (may be 'UNKNOWN')
    confidence: int           # blended 0-100
    auto_assign: bool         # True -> route automatically; False -> human review
    votes: list               # list[Vote] as dicts
    unfamiliar_terms: list    # union across votes


# ---------------------------------------------------------------------------
# Parsing — be defensive: models occasionally add fences or stray text.
# ---------------------------------------------------------------------------

def parse_vote(raw_text: str, valid_codes: set[str]) -> Vote:
    text = raw_text.strip()
    text = re.sub(r"^```(?:json)?\s*|\s*```$", "", text)  # strip md fences
    # If there's surrounding prose, grab the outermost {...} block.
    if not text.startswith("{"):
        m = re.search(r"\{.*\}", text, re.DOTALL)
        if m:
            text = m.group(0)
    try:
        obj = json.loads(text)
    except json.JSONDecodeError:
        return Vote("UNKNOWN", 0, "unparseable model output", [])

    team = str(obj.get("team", "UNKNOWN")).strip().upper()
    if team not in valid_codes:
        team = "UNKNOWN"
    try:
        confidence = max(0, min(100, int(obj.get("confidence", 0))))
    except (TypeError, ValueError):
        confidence = 0
    reasoning = str(obj.get("reasoning", ""))[:500]
    terms = obj.get("unfamiliar_terms") or []
    if not isinstance(terms, list):
        terms = [str(terms)]
    return Vote(team, confidence, reasoning, [str(t)[:200] for t in terms])


# ---------------------------------------------------------------------------
# Classifier
# ---------------------------------------------------------------------------

class TicketClassifier:
    def __init__(self, store):
        self.store = store
        self.client = anthropic.Anthropic(api_key=settings.api_key)
        self.refresh_prompt()

    def refresh_prompt(self) -> None:
        """Rebuild the system prompt from the DB. Call this periodically
        (e.g. hourly) or after glossary/correction updates."""
        teams = self.store.load_teams()
        glossary = self.store.load_glossary()
        examples = self.store.load_examples(settings.max_fewshot_examples)
        self.valid_codes = {t.code for t in teams} | {"UNKNOWN"}
        self.system_prompt = build_system_prompt(teams, glossary, examples)

    # --- single API call -> one Vote ---
    def _one_vote(self, user_msg: str) -> Vote:
        try:
            resp = self.client.messages.create(
                model=settings.model,
                max_tokens=settings.max_tokens,
                temperature=settings.vote_temperature,
                system=self.system_prompt,
                messages=[{"role": "user", "content": user_msg}],
            )
            raw = "".join(b.text for b in resp.content if b.type == "text")
            return parse_vote(raw, self.valid_codes)
        except anthropic.APIError as e:
            return Vote("UNKNOWN", 0, f"api error: {e.__class__.__name__}", [])

    # --- voting + decision ---
    def classify(self, ticket_id: str, short_desc: str, long_desc: str = "") -> Classification:
        user_msg = build_user_message(short_desc, long_desc)

        with ThreadPoolExecutor(max_workers=settings.n_votes) as pool:
            votes = list(pool.map(lambda _: self._one_vote(user_msg),
                                  range(settings.n_votes)))

        team, confidence, auto = self._decide(votes)

        unfamiliar = sorted({t for v in votes for t in v.unfamiliar_terms})
        result = Classification(
            ticket_id=ticket_id, team=team, confidence=confidence,
            auto_assign=auto, votes=[asdict(v) for v in votes],
            unfamiliar_terms=unfamiliar,
        )

        # --- feedback-loop logging ---
        self.store.log_classification(
            ticket_id=ticket_id, short_desc=short_desc, long_desc=long_desc,
            predicted_team=team, confidence=confidence,
            vote_detail=result.votes, auto_assigned=auto,
            model_used=settings.model,
        )
        if unfamiliar:
            self.store.log_unfamiliar_terms(unfamiliar, ticket_id)
        return result

    @staticmethod
    def _decide(votes: list[Vote]) -> tuple[str, int, bool]:
        """Majority vote + confidence blending + auto-assign decision."""
        counts = Counter(v.team for v in votes)
        top_team, top_count = counts.most_common(1)[0]
        agreeing = [v for v in votes if v.team == top_team]
        avg_conf = round(sum(v.confidence for v in agreeing) / len(agreeing))

        n = len(votes)
        if top_team == "UNKNOWN":
            return "UNKNOWN", min(avg_conf, 40), False
        if top_count == n:                      # unanimous
            confidence = avg_conf
        elif top_count > n / 2:                 # majority but not unanimous
            confidence = min(avg_conf, 70)      # cap: disagreement is a signal
        else:                                   # tie / no majority
            return "UNKNOWN", 30, False

        auto = confidence >= settings.auto_assign_confidence and top_count == n
        return top_team, confidence, auto


# ---------------------------------------------------------------------------
# CLI smoke test:  python classifier.py "slow laptop" "fan is loud, takes 10min to boot"
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    import sys
    from store import FileStore
    store = FileStore("sample_data/knowledge.json")
    clf = TicketClassifier(store)
    short = sys.argv[1] if len(sys.argv) > 1 else "EOS request"
    long_ = sys.argv[2] if len(sys.argv) > 2 else ""
    result = clf.classify("CLI-TEST", short, long_)
    print(json.dumps(asdict(result), indent=2))
