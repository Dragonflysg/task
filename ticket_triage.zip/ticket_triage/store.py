"""Data access for teams, glossary, corrections, and logging.

Uses mysql-connector-python. A JSON-file fallback (`FileStore`) is included
so you can develop and unit-test without a database.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from config import settings


@dataclass
class Team:
    code: str
    display_name: str
    description: str


@dataclass
class GlossaryEntry:
    term: str
    meaning: str
    team_code: Optional[str]


@dataclass
class Example:
    short_desc: str
    long_desc: str
    team_code: str


# ---------------------------------------------------------------------------
# MySQL store
# ---------------------------------------------------------------------------

class MySQLStore:
    def __init__(self):
        import mysql.connector  # lazy import so FileStore works without it
        self._conn = mysql.connector.connect(
            host=settings.db_host, port=settings.db_port,
            user=settings.db_user, password=settings.db_password,
            database=settings.db_name, autocommit=True,
        )

    def _query(self, sql: str, params: tuple = ()) -> list[dict]:
        cur = self._conn.cursor(dictionary=True)
        cur.execute(sql, params)
        rows = cur.fetchall()
        cur.close()
        return rows

    def _execute(self, sql: str, params: tuple = ()) -> None:
        cur = self._conn.cursor()
        cur.execute(sql, params)
        cur.close()

    # --- reads used by the prompt builder ---

    def load_teams(self) -> list[Team]:
        rows = self._query(
            "SELECT team_code, display_name, description FROM teams WHERE is_active = 1"
        )
        return [Team(r["team_code"], r["display_name"], r["description"]) for r in rows]

    def load_glossary(self) -> list[GlossaryEntry]:
        rows = self._query(
            "SELECT term, meaning, team_code FROM glossary WHERE is_active = 1 ORDER BY term"
        )
        return [GlossaryEntry(r["term"], r["meaning"], r["team_code"]) for r in rows]

    def load_examples(self, limit: int) -> list[Example]:
        """Most recent human corrections become few-shot examples."""
        rows = self._query(
            "SELECT short_desc, long_desc, correct_team FROM corrections "
            "ORDER BY created_at DESC LIMIT %s", (limit,)
        )
        return [Example(r["short_desc"], r["long_desc"] or "", r["correct_team"]) for r in rows]

    # --- writes from the classifier / feedback loop ---

    def log_classification(self, ticket_id, short_desc, long_desc,
                           predicted_team, confidence, vote_detail,
                           auto_assigned, model_used) -> None:
        self._execute(
            "INSERT INTO classification_log "
            "(ticket_id, short_desc, long_desc, predicted_team, confidence, "
            " vote_detail, auto_assigned, model_used) "
            "VALUES (%s,%s,%s,%s,%s,%s,%s,%s)",
            (ticket_id, short_desc, long_desc, predicted_team, confidence,
             json.dumps(vote_detail), int(auto_assigned), model_used),
        )

    def log_unfamiliar_terms(self, terms: list[str], ticket_id: str) -> None:
        for term in terms:
            self._execute(
                "INSERT INTO unfamiliar_terms (term, ticket_id) VALUES (%s,%s) "
                "ON DUPLICATE KEY UPDATE seen_count = seen_count + 1",
                (term[:200], ticket_id),
            )

    def add_correction(self, ticket_id, short_desc, long_desc,
                       correct_team, corrected_by) -> None:
        self._execute(
            "INSERT INTO corrections (ticket_id, short_desc, long_desc, correct_team, corrected_by) "
            "VALUES (%s,%s,%s,%s,%s)",
            (ticket_id, short_desc, long_desc, correct_team, corrected_by),
        )


# ---------------------------------------------------------------------------
# JSON file fallback (development / unit tests, no DB required)
# ---------------------------------------------------------------------------

class FileStore:
    """Reads teams/glossary/examples from a single JSON file.

    Format: {"teams": [...], "glossary": [...], "examples": [...]}
    Writes are appended to sibling .log.jsonl files.
    """

    def __init__(self, path: str | Path):
        self.path = Path(path)
        data = json.loads(self.path.read_text(encoding="utf-8"))
        self._teams = [Team(**t) for t in data.get("teams", [])]
        self._glossary = [GlossaryEntry(**g) for g in data.get("glossary", [])]
        self._examples = [Example(**e) for e in data.get("examples", [])]

    def load_teams(self): return self._teams
    def load_glossary(self): return self._glossary
    def load_examples(self, limit): return self._examples[:limit]

    def _append(self, suffix: str, record: dict) -> None:
        out = self.path.with_suffix(suffix)
        with out.open("a", encoding="utf-8") as f:
            f.write(json.dumps(record, ensure_ascii=False) + "\n")

    def log_classification(self, **kw): self._append(".classlog.jsonl", kw)
    def log_unfamiliar_terms(self, terms, ticket_id):
        self._append(".unfamiliar.jsonl", {"terms": terms, "ticket_id": ticket_id})
    def add_correction(self, **kw): self._append(".corrections.jsonl", kw)
